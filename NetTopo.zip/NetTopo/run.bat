@echo off
setlocal
cd /d "%~dp0"
if errorlevel 1 goto failed

if not exist ".venv\Scripts\python.exe" (
    echo The Windows .venv is missing. Run setup.bat first.
    goto failed
)
if not exist ".venv\Scripts\activate.bat" (
    echo The Windows .venv is incomplete. Run setup.bat first.
    goto failed
)

call ".venv\Scripts\activate.bat"
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -c "import sys; sys.exit(0 if sys.version_info[:2] == (3, 11) else 1)"
if errorlevel 1 (
    echo The .venv cannot run Python 3.11. Run setup.bat for instructions.
    goto failed
)

echo Starting NetTopo...
".venv\Scripts\python.exe" desktop_launcher.py %*
if errorlevel 1 goto failed
exit /b 0

:failed
echo.
echo NetTopo could not start. Review the message above.
pause
exit /b 1
