NetTopo — ชุดย้ายไปใช้เครื่องอื่น (Source package)
อัปเดต 11 พฤศจิกายน 2026

วิธีใช้บน Windows
1. ติดตั้ง Python 3.11 พร้อม Python Launcher หรือเลือก Add Python to PATH
2. แตก ZIP ทั้งหมด แล้วเปิดโฟลเดอร์ NetTopo
3. ดับเบิลคลิก setup.bat ครั้งแรก (ต้องมีอินเทอร์เน็ตเพื่อติดตั้ง Python packages)
4. เมื่อติดตั้งเสร็จ ดับเบิลคลิก run.bat หรือ start_windows.bat
5. เปิดหน้าต่าง console ค้างไว้ระหว่างใช้งาน ปิดระบบด้วย Ctrl+C

ติดตั้ง Nmap/Npcap แยกหากใช้การสแกนที่ต้องพึ่ง Nmap
ไฟล์นี้เป็น source package แบบเดิม ไม่ใช่ Windows EXE และไม่รวม Python
สร้าง .venv ใหม่บนเครื่องปลายทางผ่าน setup.bat ไม่ต้องคัดลอก .venv จากเครื่องอื่น
ไฟล์ JavaScript สำหรับหน้าเว็บรวมมาแล้วใน static/vendor

การแก้ไขที่รวมในชุดนี้
- Root node แสดงขอบเรืองแสง โดยใช้ขนาดและชื่อปกติ
- ปุ่มใช้ Default Gateway สำหรับกำหนด Root IP
- Auto Layout เรียง Cloud และอุปกรณ์ตามระยะ hop
- สร้าง Internet Cloud สมมติจากพอร์ต NAT outside หรือพอร์ตที่มีชื่อ/คำอธิบาย NAT
- อ่าน NAT role จาก Cisco SNMP NAT MIB เมื่ออุปกรณ์รองรับ และจาก SSH NAT statistics
- การสแกนใหม่จะค้นหาใหม่ทั้งหมด ไม่ใช้ผล topology เดิมแทนการตรวจอุปกรณ์

หากไฟล์ topology เดิมไม่มีข้อมูล NAT ต้องสแกนใหม่เพื่ออ่านข้อมูลเพิ่ม
Cloud เป็นการสันนิษฐาน ไม่ใช่ผลยืนยันว่าต่อ Internet สำเร็จ
