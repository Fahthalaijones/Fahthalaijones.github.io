import os
import sqlite3
from typing import Dict, Iterable, Optional

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
from runtime_paths import data_file

DATABASE = str(data_file("network.db"))


def connect():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


def create_tables():
    conn = connect()
    cur = conn.cursor()

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS devices(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hostname TEXT,
            ip TEXT UNIQUE,
            mac TEXT,
            vendor TEXT,
            model TEXT,
            sysdescr TEXT
        )
        """
    )

    # Persistent positions for vis-network. node_id is the stable ID produced by
    # the topology builder (normally management IP / device identity).
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS node_positions(
            node_id TEXT PRIMARY KEY,
            x REAL NOT NULL,
            y REAL NOT NULL,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
        """
    )

    # Lightweight migration for V4.15: labels have their own offset relative
    # to the device, so moving a node keeps its label arrangement.
    columns = {row[1] for row in cur.execute("PRAGMA table_info(node_positions)").fetchall()}
    if "label_x" not in columns:
        cur.execute("ALTER TABLE node_positions ADD COLUMN label_x REAL")
    if "label_y" not in columns:
        cur.execute("ALTER TABLE node_positions ADD COLUMN label_y REAL")

    conn.commit()
    conn.close()


def insert_device(device):
    conn = connect()
    cur = conn.cursor()
    cur.execute(
        """
        INSERT OR REPLACE INTO devices(hostname, ip, sysdescr)
        VALUES(?,?,?)
        """,
        (
            device["hostname"],
            device["ip"],
            device["description"],
        ),
    )
    conn.commit()
    conn.close()


def save_node_positions(positions: Dict[str, dict]) -> int:
    """Insert/update node coordinates and return the number of saved nodes."""
    if not positions:
        return 0

    create_tables()
    rows = []
    for node_id, pos in positions.items():
        if not isinstance(pos, dict) or "x" not in pos or "y" not in pos:
            continue
        try:
            label_x = pos.get("label_x")
            label_y = pos.get("label_y")
            rows.append((
                str(node_id), float(pos["x"]), float(pos["y"]),
                float(label_x) if label_x is not None else None,
                float(label_y) if label_y is not None else None,
            ))
        except (TypeError, ValueError):
            continue

    if not rows:
        return 0

    conn = connect()
    conn.executemany(
        """
        INSERT INTO node_positions(node_id, x, y, label_x, label_y, updated_at)
        VALUES(?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(node_id) DO UPDATE SET
            x = excluded.x,
            y = excluded.y,
            label_x = excluded.label_x,
            label_y = excluded.label_y,
            updated_at = CURRENT_TIMESTAMP
        """,
        rows,
    )
    conn.commit()
    conn.close()
    return len(rows)


def get_node_positions(node_ids: Optional[Iterable[str]] = None) -> Dict[str, dict]:
    create_tables()
    conn = connect()
    cur = conn.cursor()

    if node_ids is None:
        rows = cur.execute("SELECT node_id, x, y, label_x, label_y FROM node_positions").fetchall()
    else:
        ids = [str(item) for item in node_ids]
        if not ids:
            conn.close()
            return {}
        placeholders = ",".join("?" for _ in ids)
        rows = cur.execute(
            f"SELECT node_id, x, y, label_x, label_y FROM node_positions WHERE node_id IN ({placeholders})",
            ids,
        ).fetchall()

    conn.close()
    return {
        str(row["node_id"]): {
            "x": float(row["x"]), "y": float(row["y"]),
            "label_x": float(row["label_x"]) if row["label_x"] is not None else None,
            "label_y": float(row["label_y"]) if row["label_y"] is not None else None,
        }
        for row in rows
    }


def clear_node_positions() -> int:
    create_tables()
    conn = connect()
    cur = conn.cursor()
    cur.execute("DELETE FROM node_positions")
    deleted = cur.rowcount
    conn.commit()
    conn.close()
    return max(deleted, 0)
