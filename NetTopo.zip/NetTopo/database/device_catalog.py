"""Small, editable SQLite catalog of hardware families (not routing state)."""
import re
import sqlite3
from pathlib import Path

from runtime_paths import data_file

DATABASE = data_file("device_catalog.db")


def initialize_catalog():
    with sqlite3.connect(str(DATABASE)) as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS device_models (
            model_name TEXT PRIMARY KEY, vendor TEXT NOT NULL,
            device_type TEXT NOT NULL, model_pattern TEXT NOT NULL,
            source_url TEXT NOT NULL
        )""")
        families = {
            "3000": "https://www.cisco.com/c/en/us/td/docs/switches/lan/trustsec/configuration/guide/trustsec/appa_cat3k.html",
            "3550": "https://www.cisco.com/web/ANZ/cpp/refguide/hview/switch/3550.html",
            "3560": "https://www.cisco.com/c/en/us/products/collateral/switches/catalyst-3560-x-series-switches/data_sheet_c78-584733.pdf",
            "3750": "https://www.cisco.com/c/en/us/products/collateral/switches/catalyst-3560-x-series-switches/data_sheet_c78-584733.pdf",
            "3650": "https://www.cisco.com/c/en/us/support/switches/catalyst-3650-series-switches/series.html",
            "3850": "https://www.cisco.com/c/en/us/support/switches/catalyst-3850-series-switches/series.html",
            "4500": "https://www.cisco.com/c/en/us/support/docs/switches/catalyst-6500-series-switches/24330-185.html",
            "4900": "https://www.cisco.com/c/en/us/support/switches/catalyst-4900-series-switches/series.html",
            "6500": "https://www.cisco.com/c/en/us/support/docs/switches/catalyst-6500-series-switches/24330-185.html",
            "6800": "https://www.cisco.com/c/en/us/support/switches/catalyst-6800-series-switches/series.html",
            "9200": "https://www.cisco.com/c/en/us/products/collateral/switches/catalyst-9000/nb-06-cat9k-swit-plat-faq-cte-en.html",
            "9300": "https://www.cisco.com/c/en/us/products/collateral/switches/catalyst-9300-series-switches/nb-06-cat9300-ser-data-sheet-cte-en.html",
            "9500": "https://www.cisco.com/c/en/us/products/collateral/switches/catalyst-9500-series-switches/nb-06-cat9500-ser-data-sheet-cte-en.html",
            "9400": "https://www.cisco.com/c/en/us/products/collateral/switches/catalyst-9000/nb-06-cat9k-swit-plat-faq-cte-en.html",
            "9600": "https://www.cisco.com/c/en/us/products/collateral/switches/catalyst-9000/nb-06-cat9k-swit-plat-faq-cte-en.html",
        }
        # Modular chassis use a slot count in the SKU, not the family name.
        chassis = {"4500": "450[0367]|4510", "4900": "490[08]|4948",
                   "6500": "650[03469]|6513", "6800": "680[07]|6840|6880",
                   "9400": "940[047]|9410", "9600": "960[06]|9610"}
        for family, source in families.items():
            sku = "(?:" + chassis.get(family, family) + ")"
            suffix = r"[A-Z]*(?:\+[A-Z]+)?(?=[\s_,-]|$)"
            pattern = (r"\b(?:WS-)?C" + sku + suffix + r"|\bCatalyst\s+"
                       + sku + suffix)
            conn.execute("INSERT OR IGNORE INTO device_models VALUES (?, ?, ?, ?, ?)",
                         ("Cisco Catalyst " + family, "Cisco", "layer3_switch", pattern, source))
        # User-facing umbrella label; never match C3800/Cisco 3800 routers.
        conn.execute("INSERT OR IGNORE INTO device_models VALUES (?, ?, ?, ?, ?)",
                     ("Cisco Catalyst 3800", "Cisco", "layer3_switch",
                      r"\bCatalyst\s+3800(?=[\s,;.)-]|$)", families["3850"]))
        # sysObjectID cat38xxstack identifies a family, not an exact SKU.
        conn.execute("INSERT OR IGNORE INTO device_models VALUES (?, ?, ?, ?, ?)",
                     ("Cisco Catalyst 38xx Stack", "Cisco", "layer3_switch",
                      r"\bCatalyst\s+38xx\s+Stack\b",
                      "https://github.com/cisco/cisco-mibs/blob/main/v2/CISCO-PRODUCTS-MIB.my"))


def lookup_device_model(profile):
    # Never use hostname or neighbor descriptions: they can name another device.
    from scanner.hardware_identity import model_from_profile, vendor_from_profile
    if vendor_from_profile(profile) != "Cisco" and str(profile.get("vendor", "")).lower() != "cisco":
        return None
    if not DATABASE.exists():
        initialize_catalog()
    text = "\n".join(str(profile.get(key) or "") for key in
                     ("model", "hardware_model", "platform", "description", "hardware_description"))
    text += "\n" + model_from_profile(profile)
    with sqlite3.connect(str(DATABASE)) as conn:
        conn.row_factory = sqlite3.Row
        # A concrete 35xx/36xx/37xx/38xx model takes priority over a generic
        # Catalyst 3000 family label in the same local description.
        rows = conn.execute("SELECT * FROM device_models WHERE vendor = ? "
                            "ORDER BY (model_name IN ('Cisco Catalyst 3000', 'Cisco Catalyst 3800', 'Cisco Catalyst 38xx Stack')), model_name", ("Cisco",)).fetchall()
    for row in rows:
        if re.search(row["model_pattern"], text, re.I):
            return dict(row)
    return None


def routing_state(profile):
    """Return True/False/None from operational evidence, never from model name."""
    forwarding = str(profile.get("ip_forwarding") or "").strip().lower()
    if forwarding in {"1", "forwarding", "forwarding(1)"}:
        return True
    if forwarding in {"2", "notforwarding", "notforwarding(2)"}:
        return False
    if isinstance(profile.get("routing_enabled"), bool):
        return profile["routing_enabled"]
    return None


def operational_switch_type(profile):
    return "layer3_switch" if routing_state(profile) is True else "switch"


def apply_catalog(profile):
    match = lookup_device_model(profile)
    if match:
        profile["l3_capable"] = match["device_type"] == "layer3_switch"
        profile["device_type"] = operational_switch_type(profile) if profile["l3_capable"] else match["device_type"]
        profile["routing_enabled"] = routing_state(profile)
        profile["classification_source"] = "device_catalog + routing_state"
        profile["catalog_model"] = match["model_name"]
    elif profile.get("device_type") in {"switch", "layer3_switch"}:
        profile["device_type"] = operational_switch_type(profile)
        profile["routing_enabled"] = routing_state(profile)
    return profile


if __name__ == "__main__":
    initialize_catalog()
