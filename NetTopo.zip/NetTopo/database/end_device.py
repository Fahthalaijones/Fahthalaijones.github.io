from database.database import connect


def create_table():
    conn = connect()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS end_devices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            switch_ip TEXT,
            interface TEXT,
            ip TEXT,
            mac TEXT
        )
    """)

    conn.commit()
    conn.close()


def clear_end_devices():
    conn = connect()
    cur = conn.cursor()

    cur.execute("DELETE FROM end_devices")

    conn.commit()
    conn.close()


def insert_end_device(switch_ip, interface, ip, mac):
    conn = connect()
    cur = conn.cursor()

    cur.execute("""
        INSERT INTO end_devices(
            switch_ip,
            interface,
            ip,
            mac
        )
        VALUES(?,?,?,?)
    """, (
        switch_ip,
        interface,
        ip,
        mac
    ))

    conn.commit()
    conn.close()


def get_end_devices():
    conn = connect()
    cur = conn.cursor()

    cur.execute("""
        SELECT
            switch_ip,
            interface,
            ip,
            mac
        FROM end_devices
    """)

    rows = cur.fetchall()

    conn.close()

    return rows