import os
import sqlite3

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE = os.path.join(BASE_DIR, "network.db")

def create_tables():
    conn = sqlite3.connect(DATABASE)
    cur = conn.cursor()
    
    # สั่งสร้างตาราง devices (ปรับเปลี่ยนคอลัมน์ตามที่คุณใช้งานจริงใน network_scan.py ได้เลย)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS devices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ip TEXT UNIQUE NOT NULL,
        mac TEXT,
        hostname TEXT,
        last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)
    
    conn.commit()  # สำคัญมาก! ต้องกดบันทึกลงไฟล์
    conn.close()
    print("สร้างตาราง devices เรียบร้อยแล้วในไฟล์:", DATABASE)

# รันฟังก์ชันนี้หนึ่งครั้งเพื่อสร้างตาราง
if __name__ == "__main__":
    create_tables()
