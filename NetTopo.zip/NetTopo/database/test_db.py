import os
import sqlite3

# หาพาธของโฟลเดอร์ที่ไฟล์ test_db.py นี้ตั้งอยู่
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
db_path = os.path.join(BASE_DIR, "network.db")  # เปลี่ยนเป็นชื่อไฟล์ db ของคุณ

conn = sqlite3.connect(db_path)
cur = conn.cursor()
