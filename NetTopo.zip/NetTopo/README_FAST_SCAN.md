# Targeted service and infrastructure discovery

CDP/LLDP drives recursive network-device discovery and the credential queue.
Open HTTP/HTTPS ports on an unresolved neighbor do not turn that hop into a
server or remove its credential prompt. The dashboard lists raw CDP/LLDP counts
per collected device, independently of which physical links can be validated.
Advertisements pointing to the source device's own IP remain editable pending
hops. Entering a corrected management IP updates that observation after a
successful continuation; the original advertised address is retained as evidence.

ARP supplies concrete candidate IPs; it does not identify application services or
prove a physical link. The scanner probes ARP addresses with the current SNMP community to find switches whose management IP is not in CDP/LLDP. It never
expands route prefixes or scans whole subnets. A switch absent from both neighbor
advertisements and ARP needs its reachable management IP added to Root / Seed IP.
Being in the same VLAN and using the same community cannot reveal an unknown IP.
A switch discovered via ARP/SNMP is shown without an invented gateway cable when
CDP/LLDP provides no physical-link evidence.

Full Scan runs Nmap against individual endpoint IPs from ARP/FDB/endpoint neighbor
observations plus optional server IPs entered in Scan Options. Explicit service
targets accept IPv4 addresses only, never CIDRs or ranges. Infrastructure hops
waiting for credentials remain excluded from endpoint service classification.
ARP/FDB remains responsible for physical endpoint placement; an Nmap result alone
does not identify a switch port. Devices already mapped are kept if no service
responds. No subnet scan is used as a fallback for an empty ARP table.

The default fast pass checks twelve TCP ports for Web, DNS, and Mail:
`25,53,80,110,143,443,465,587,993,995,5000,8000,8080,8443`.
SSH, Telnet, and RDP are excluded from endpoint discovery. SSH access for reading
network-device topology is unchanged. TCP 53 does not cover UDP-only DNS servers.
The port list can be changed in `scanner/service_discovery.py` (`FAST_TCP_PORTS`).

Fast mode identifies open ports and labels service roles as port hints, not
verified applications or hardware types. Optional light verification runs a
second `-sV --version-light` pass only on IPs and ports found open. Probed
application names take precedence over port-number hints; the device details
show whether classification came from a probe or a port hint. Verification
shares the original deadline, and fast results survive verification failures.

Timing: `-T4 -Pn -n --open --max-retries 1 --host-timeout 10s`.
Batches contain up to 64 addresses, with four Nmap processes in parallel and a
shared 120-second deadline. Raw-packet permission failures retry with `-sT`.
Neither mode runs OS detection, NSE scripts, DNS lookups, or UDP scans. Slow or
filtered hosts can still time out; reducing timeouts/retries further may miss
services. The dashboard shows candidate/service counts and Nmap errors rather
than silently treating failed scans as zero services.

Tune workers and timeouts in `system_settings.py`. ARP snapshots are reused in a
single discovery run. No measured real-network speedup is claimed by offline tests.

Run offline regressions:
`python3 -m unittest test_topology_sources test_service_scan_fast test_mixed_communities test_neighbor_links test_discovery_recovery test_continue_topology test_device_catalog`

Nmap references:
- https://nmap.org/book/man-performance.html
- https://nmap.org/book/reduce-scantime.html

Hop continuation is topology-only: it follows new CDP/LLDP neighbors, skips
already collected primary IPs, and does not repeat ARP candidate probes, route
expansion, endpoint mapping, or Nmap. Run Full Scan explicitly when service
inventory needs refreshing. Each branch uses only its entered SNMP/SSH credentials. Auto tries that SNMP
community before its SSH fallback. A different credential requires explicit hop
continuation; earlier communities are never automatically reused. SNMP reads of the same
IP/community/OID are cached only within one device collection, with no persistent
credential cache. Continuation uses zero SNMP retries; initial scans retain the
normal retry setting. No actual wall-clock improvement is asserted by tests.

Network Information shows LAN prefixes measured from interface/VLAN IP addresses
and masks; loopbacks and /30-/32 transit/host links are excluded from that view.
Management IPs remain in selected-device details rather than the network sidebar.

CDP/LLDP names and chassis IDs reconcile advertised IPs into existing network
devices, with interface MAC evidence available for ARP aliases. All known network
interface IPs are excluded from endpoint classification. Speculative unmanaged
switch inference is disabled. Services without physical port evidence remain in
the separate unlocated-services list, rather than floating on the physical map.
