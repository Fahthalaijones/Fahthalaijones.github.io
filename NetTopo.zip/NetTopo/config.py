# V3.2 seeded recursive discovery configuration.
# Only R1 is configured. R2, switches and LAN networks are discovered.
ROOT_DEVICE_IP = "192.168.56.125"

SNMP_COMMUNITY = "public"
SNMP_PORT = 161
SNMP_TIMEOUT = 2
SNMP_RETRIES = 0

# Discovery safety limits. /20 contains 4096 addresses, so this value also
# supports the user's routed GNS3 lab if a /20 route appears in R1.
MAX_DISCOVERY_DEPTH = 6
MAX_DISCOVERED_NETWORKS = 32
MAX_HOSTS_PER_NETWORK = 4096
SNMP_PROBE_WORKERS = 24
PRIVATE_NETWORKS_ONLY = True

# The PC/Ubuntu host already has routes to the GNS3 networks. V3.2 therefore
# never changes the operating system routing table.
AUTO_ADD_DISCOVERED_ROUTES = False

# Topology evidence validation
# Require both CDP endpoints to report each other. This removes stale or
# mismatched one-sided links such as SW1--R2.
REQUIRE_RECIPROCAL_CDP = True

# Topology inference
INFER_UNMANAGED_SWITCHES = True
UNMANAGED_SWITCH_MIN_DEVICES = 2

# Flask configuration
FLASK_HOST = "0.0.0.0"
FLASK_PORT = 5000
FLASK_DEBUG = True
