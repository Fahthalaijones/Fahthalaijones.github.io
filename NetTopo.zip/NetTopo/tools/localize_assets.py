#!/usr/bin/env python3
"""Download pinned browser libraries, then switch the dashboard to local assets."""

import hashlib
import json
from pathlib import Path
import sys
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parents[1]
ASSETS = (
    (
        "https://unpkg.com/vis-network/standalone/umd/vis-network.min.js",
        "https://cdn.jsdelivr.net/npm/vis-network@9.1.9/standalone/umd/vis-network.min.js",
        "vendor/vis-network-9.1.9.min.js",
    ),
    (
        "https://cdn.jsdelivr.net/npm/chart.js",
        "https://cdn.jsdelivr.net/npm/chart.js@4.4.8/dist/chart.umd.js",
        "vendor/chart-4.4.8.umd.js",
    ),
)


def main():
    template = ROOT / "templates/index.html"
    html = template.read_text(encoding="utf-8")
    downloads = []
    for original, source, filename in ASSETS:
        local = "{{ url_for('static', filename='" + filename + "') }}"
        if original not in html and local not in html:
            raise ValueError(f"Expected script reference missing: {original}")
        print(f"Downloading {source}", flush=True)
        request = Request(source, headers={"User-Agent": "NetworkTopology-local-assets/1.0"})
        with urlopen(request, timeout=60) as response:
            data = response.read()
        if len(data) < 10000 or b"<html" in data[:1000].lower():
            raise ValueError(f"Invalid JavaScript download: {source}")
        downloads.append((filename, source, data))
        html = html.replace(original, local)

    # Do not change the HTML until every dependency has downloaded successfully.
    manifest = []
    for filename, source, data in downloads:
        destination = ROOT / "static" / filename
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_suffix(destination.suffix + ".tmp")
        temporary.write_bytes(data)
        temporary.replace(destination)
        manifest.append({"file": filename, "source": source,
                         "sha256": hashlib.sha256(data).hexdigest()})
    (ROOT / "static/vendor/manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )
    temporary = template.with_suffix(".html.tmp")
    temporary.write_text(html, encoding="utf-8")
    temporary.replace(template)
    print("Done. Dashboard libraries now load from local static files.")


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"Failed: {error}. HTML was not switched to missing assets.", file=sys.stderr)
        sys.exit(1)
