# แก้ CNT1 / ONGKOT ไม่ปรากฏเป็น Hop รอสแกนต่อ

สาเหตุ: IOL/IOU switch ประกาศ CDP Platform เป็น Linux Unix และถูกจำแนกเป็น endpoint
จนหายจากรายการ credential_required แม้เราเตอร์ต้นทางจะพบผ่าน CDP แล้ว

สิ่งที่แก้:
- อ่าน cdpCacheCapabilities (1.3.6.1.4.1.9.9.23.1.2.1.1.9) และจับคู่ด้วยดัชนีเดียวกับชื่อ/พอร์ต
- ให้ Router/Bridge/Switch/Repeater capability มีน้ำหนักเหนือข้อความ Linux
- หาก CDP Platform เป็น Linux Unix แต่ไม่มี capability ให้เก็บเป็น unknown เพื่อกรอกข้อมูลต่อ
- เก็บ Platform และ Capabilities เมื่ออ่าน CDP ผ่าน SSH ด้วย
- รู้จัก I86BI_LINUXL2 ในโปรไฟล์ SNMP ว่าเป็นสวิตช์
- Linux server ที่ไม่มีหลักฐานอุปกรณ์เครือข่ายยังคงเป็น endpoint

วิธีใช้กับโปรเจกต์เดิม:
1. หยุด Flask ด้วย Ctrl+C และสำรองโปรเจกต์เดิม
2. คัดลอก 4 ไฟล์ต่อไปนี้จาก ZIP ไปทับที่ตำแหน่งเดิม:
   scanner/cdp.py
   scanner/neighbor_kind.py
   scanner/ssh_collector.py
   scanner/device_profiler.py
3. เริ่มโปรแกรมด้วยคำสั่งเดิม แล้วเริ่มสแกนใหม่จาก RAMA
4. หากชุมชน SNMP ของ CNT1 ต่างกัน ให้เลือก Hop CNT1 แล้วกรอก IP และ community ของ CNT1
   ทำแบบเดียวกันกับ ONGKOT จากข้อมูลของ SRIDA
5. หาก CDP ไม่ประกาศ management IP ให้กรอก IP ที่ Ubuntu เข้าถึงได้เอง

ไม่ต้องเปลี่ยนฐานข้อมูลหรือ requirements.txt เพื่อใช้การแก้นี้
การสแกนต่อยังต้องมีเส้นทางไป/กลับและสิทธิ์ SNMP/SSH ที่ถูกต้อง

การตรวจสอบ: ทดสอบแบบจำลอง (offline) รวม Capabilities, ชื่อ/พอร์ต,
community ต่างกัน, สแกน Hop ต่อไป, ไม่มี management IP และ Linux server
ไม่ได้เชื่อมต่อ GNS3 หรืออุปกรณ์จริงของผู้ใช้ในการทดสอบ
