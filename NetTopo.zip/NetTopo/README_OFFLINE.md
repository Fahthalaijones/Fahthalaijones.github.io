# Local dashboard assets

Run once on a machine with Internet access (Python 3, no extra packages needed):

```sh
python3 tools/localize_assets.py
```

The script downloads Vis Network 9.1.9 and Chart.js 4.4.8 into `static/vendor/`,
records their source URLs and SHA-256 hashes in `manifest.json`, and changes
`templates/index.html` to Flask local static URLs only after both downloads succeed.
Keep the downloaded library copyright/license headers when distributing the files.

Copy the resulting project, including `static/vendor/` and the updated template,
to the offline machine. Start Flask normally and refresh the browser. No CDN
connection is needed, including on the first visit. Flask and its Python dependencies
must already be installed; discovery still needs access to the target local network.

The HTML template is rendered by Flask; opening it directly as a file is not supported.

## Windows launchers

Install Python 3.11 on the Windows machine used for preparation, then run
`setup.bat` with Internet access (`setup_windows.bat` calls the same setup). It creates a Windows `.venv`, installs
`requirements.txt`, and downloads the local browser assets. Use `start_windows.bat`
to launch without the Flask debugger or auto-reloader.

A Linux venv cannot be used on Windows. Python venvs are not portable: create one
on each target machine, or package a Windows executable on Windows with the
`templates/` and `static/` directories included. These BAT files do not build an EXE.
If discovery uses Nmap, install Nmap separately on the target machine.

## Windows EXE distribution

See `README_BUILD_WINDOWS.md`. On Windows x64 with Python 3.11 installed,
run `build_windows.bat` to produce `dist/NetTopo-Windows-x64.zip` and its
SHA-256 checksum. The ZIP contains a Python-independent executable and its
support files. Nmap/Npcap remain separate prerequisites for scanning.
Packaged databases are created per user in `%LOCALAPPDATA%\NetTopo`.

### ติดตั้งจาก source บน Windows

1. แตกไฟล์โปรเจกต์ทั้งโฟลเดอร์ แล้วติดตั้ง Python 3.11 พร้อม Python Launcher หรือเพิ่ม Python ใน PATH
2. ดับเบิลคลิก `setup.bat` เพื่อสร้าง `.venv` ภายในโฟลเดอร์โปรเจกต์ ติดตั้งทุกแพ็กเกจใน `requirements.txt` และดาวน์โหลดไฟล์ JavaScript สำหรับหน้าเว็บ
3. เมื่อติดตั้งสำเร็จ ดับเบิลคลิก `run.bat` (หรือ `start_windows.bat`) เพื่อเข้า `.venv` และเริ่มระบบพร้อมเปิดเบราว์เซอร์อัตโนมัติ ให้เปิดหน้าต่าง console ค้างไว้ระหว่างใช้งาน และกด Ctrl+C เพื่อหยุดระบบ

ต้องต่ออินเทอร์เน็ตระหว่าง setup และติดตั้ง Nmap/Npcap แยกสำหรับการสแกน
เรียก setup ซ้ำได้ โดยใช้ `.venv` เดิมถ้าเป็น Python 3.11
หาก `.venv` เดิมใช้ไม่ได้หรือเป็น Python เวอร์ชันอื่น สคริปต์จะแจ้งให้เปลี่ยนชื่อโฟลเดอร์ก่อนสร้างใหม่ โดยไม่ลบข้อมูลเอง
Python 3.12 ขึ้นไปไม่เหมาะกับ dependency SNMP รุ่นปัจจุบัน เนื่องจากไม่มี `asyncore`
สคริปต์นี้ติดตั้งสำหรับรันจาก source; หากต้องการสร้าง EXE ให้ใช้ `build_windows.bat`
