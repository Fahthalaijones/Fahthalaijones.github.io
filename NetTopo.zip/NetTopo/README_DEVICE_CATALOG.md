# Cisco hardware classification

`database/device_catalog.db` is a small SQLite hardware catalog shipped with the
project. `device_models` contains model name, vendor, device type, matching regex,
and a Cisco source URL. Included families: Catalyst 3000, 3550, 3560, 3650, 3750,
3850, 4500, 4900, 6500, 6800, 9200, 9300, 9400, 9500, and 9600.
Family patterns accept suffixes such as C9200L, C9300X, and C9500X, plus
modular chassis such as WS-C4507R, WS-C6509-E, C6807-XL, C9407R, and C9606R.
This is a hardware-family catalog, not a complete list of individual Cisco SKUs
or product OIDs. Catalyst wireless controllers and Nexus are not matched by
these Catalyst switch rules. Unknown OIDs still need verified model mappings.
The generic `Catalyst 3000 Series` / `C3000` label is supported; an explicit
3550/3560/3650/3750/3850 model takes priority when both labels are present.
This rule does not round arbitrary 3xxx product OIDs into the 3000 family.

SNMP matches collected model/sysDescr/sysObjectID-derived model data. SSH matches
the full local `show version` response. The catalog is checked before forwarding
heuristics, so a known L3 switch is not mistaken for a router. Import also preserves
L3 types and applies catalog matches. Unknown models retain existing detection.

Catalog models retain their L3 capability separately. They are displayed and
counted as `layer3_switch` only when forwarding/routing is confirmed enabled;
disabled or unknown state displays as `switch`. The explicit `Catalyst 3800`
umbrella label follows this rule; `Cisco 3800` / `C3800` router names do not
match it. SNMP uses the scalar `ipForwarding`, without requiring a routing-table
walk in Topology mode. This classification never creates a topology edge.
SSH uses explicit `ip routing` configuration or real coded routing-table entries.
A management default gateway alone does not count as routing. Exported nodes retain
capability and forwarding evidence so importing them can use the same rule.
Route collection for SNMP L3 switches requires `ipForwarding=1`.
No new SNMP walks are added by catalog lookup.

Edit this file with a SQLite editor to add known model patterns or exact SKU rules.
Patterns must target local hardware fields; names of neighbors/hostnames are not used.
Existing database edits are preserved when seeds are initialized. Bundle the DB
alongside Python modules when distributing the project.

Offline tests: `python3 -m unittest test_device_catalog`.
