NetTopo for Windows x64

1. Extract the entire ZIP into a folder.
2. Double-click NetTopo.exe. The dashboard opens in your default browser.
3. Keep the console window open while using NetTopo.
4. Close the console or press Ctrl+C to stop the program.

Python is included; no separate Python installation is needed.
Do not move NetTopo.exe away from its _internal folder.
If the browser does not open, copy the URL shown in the console.
Each launch uses an available local port; only this computer can open it.

Data is stored in %LOCALAPPDATA%\NetTopo and survives app replacement.
Browser settings may depend on the browser and local URL; re-enter scan
settings if needed after restarting. Export scan results before closing.
The NETTOPO_DATA_DIR environment variable can override the data folder.

Nmap is a separate prerequisite for host/service scanning. Install Nmap
from https://nmap.org/download.html using its Windows installer and include
Npcap when offered. Restart NetTopo after installation. NetTopo searches
standard Nmap install locations and PATH. Nmap/Npcap are not bundled.
Use scanning only on networks you have permission to manage.

Troubleshooting: run NetTopo.exe --smoke-test from Command Prompt to check
bundled files and database access. Report the console error if startup fails.
