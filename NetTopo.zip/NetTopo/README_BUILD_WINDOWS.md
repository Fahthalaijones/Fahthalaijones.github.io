# สร้าง NetTopo.exe สำหรับแจกบนเว็บ

บน Windows x64 ติดตั้ง **Python 3.11 แบบ 64-bit** พร้อม Python Launcher
แล้วดับเบิลคลิก `build_windows.bat` ขณะเชื่อมต่ออินเทอร์เน็ต
ใช้ Python 3.11 เพราะ pysnmp 4.4.12 ใช้ asyncore ที่ถูกถอดออกใน Python 3.12

สคริปต์สร้าง environment แยก `.venv-build`, ดาวน์โหลด JavaScript ที่ระบุเวอร์ชัน,
แพ็กด้วย PyInstaller และเรียก `--smoke-test` ตรวจหน้าเว็บ ไฟล์ static และฐานข้อมูล
จาก EXE ก่อนสร้าง ZIP พร้อม SHA-256

ไฟล์สำหรับอัปโหลดบนเว็บ:

- `dist/NetTopo-Windows-x64.zip`
- `dist/NetTopo-Windows-x64.zip.sha256`

ZIP มี EXE และ `_internal` ต้องแจกทั้งชุด ไม่มีฐานข้อมูลการสแกนของผู้สร้างรวมอยู่ด้วย
ฐานข้อมูลใหม่จะสร้างใน `%LOCALAPPDATA%\NetTopo` ของผู้ใช้แต่ละคน
คัดลอกคู่มือ `README_WINDOWS.txt` ลงชุดดาวน์โหลดโดยอัตโนมัติ

ก่อนเผยแพร่ให้ทดลองบน Windows ที่ไม่มี Python: แตก ZIP, เปิด EXE, ตรวจ Dashboard,
ติดตั้ง Nmap/Npcap, ลองสแกนเครือข่ายที่ได้รับอนุญาต และปิดแล้วเปิดใหม่เพื่อตรวจข้อมูลที่บันทึก
การทดสอบอัตโนมัติไม่ได้ตรวจการสแกนอุปกรณ์จริงหรือสิทธิ์ของ Npcap

ต้อง build บน Windows; ชุด source ที่เตรียมบน Linux ยังไม่ใช่ Windows executable
ดูรายละเอียดการแพ็กได้ที่ https://pyinstaller.org/en/stable/usage.html
