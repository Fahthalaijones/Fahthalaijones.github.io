"""Keep packaged user data outside the application bundle."""
import os
from pathlib import Path
import sys


def data_file(name):
    override = os.environ.get("NETTOPO_DATA_DIR")
    if override:
        directory = Path(override).expanduser().resolve()
    elif getattr(sys, "frozen", False):
        directory = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "NetTopo"
    else:
        directory = Path(__file__).resolve().parent / "database"
    directory.mkdir(parents=True, exist_ok=True)
    return directory / name
