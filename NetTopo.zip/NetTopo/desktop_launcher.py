"""Local browser launcher for the Windows distribution (console stays open)."""
import argparse
import os
from pathlib import Path
import sys
import threading
import webbrowser


def configure_nmap_path():
    if sys.platform == "win32":
        candidates = [Path(os.environ.get(key, "C:/Program Files")) / "Nmap"
                      for key in ("ProgramFiles", "ProgramFiles(x86)")]
        os.environ["PATH"] = os.pathsep.join(
            [str(path) for path in candidates if path.is_dir()] + [os.environ.get("PATH", "")]
        )


def main():
    parser = argparse.ArgumentParser(description="NetTopo local dashboard")
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--smoke-test", action="store_true", help="Check bundled dashboard and storage, then exit")
    args = parser.parse_args()
    configure_nmap_path()
    from app import app
    from database.device_catalog import initialize_catalog
    from runtime_paths import data_file
    from werkzeug.serving import make_server

    initialize_catalog()
    if args.smoke_test:
        with app.test_client() as client:
            for url in ("/", "/api/health", "/static/vendor/vis-network-9.1.9.min.js",
                        "/static/vendor/chart-4.4.8.umd.js"):
                response = client.get(url)
                if response.status_code != 200:
                    raise RuntimeError(f"Resource check failed: {url} ({response.status_code})")
        print("NetTopo smoke test passed. Data:", data_file("network.db").parent)
        return

    # Bind first; port 0 lets the OS select a free port without a race.
    server = make_server("127.0.0.1", 0, app, threaded=True)
    url = f"http://127.0.0.1:{server.server_port}"
    print(f"NetTopo: {url}\nData: {data_file('network.db').parent}", flush=True)
    print("Keep this window open. Press Ctrl+C or close it to stop NetTopo.", flush=True)
    if not args.no_browser:
        threading.Timer(0.5, webbrowser.open, args=(url,)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        import traceback
        traceback.print_exc()
        if getattr(sys, "frozen", False) and sys.stdin and sys.stdin.isatty():
            input("NetTopo could not start. Press Enter to close...")
        sys.exit(1)
