"""Internal runtime limits for discovery.

User scan targets and credentials are supplied by the Web Settings payload.
This module intentionally contains no Root/Seed IP, SNMP community, or SSH credential.
"""

SNMP_PORT = 161
# Fast interactive topology: one short SNMP attempt per missing credential/IP.
# Raise SNMP_TIMEOUT to 2-3 on high-latency WAN links if devices are missed.
SNMP_TIMEOUT = 1.5
SNMP_RETRIES = 0

MAX_DISCOVERY_DEPTH = 6
MAX_DISCOVERED_NETWORKS = 32
MAX_HOSTS_PER_NETWORK = 4096
SNMP_PROBE_WORKERS = 24
# Independent devices collect concurrently; each owns its SNMP engine.
DISCOVERY_WORKERS = 6
SNMP_BULK_REPETITIONS = 20
SERVICE_SCAN_BATCH_SIZE = 64
SERVICE_SCAN_WORKERS = 4
SERVICE_SCAN_HOST_TIMEOUT = "10s"
SERVICE_SCAN_MAX_RETRIES = 1
PRIVATE_NETWORKS_ONLY = True

REQUIRE_RECIPROCAL_CDP = True
INFER_UNMANAGED_SWITCHES = True
INFER_TRUNK_SWITCHES = False
UNMANAGED_SWITCH_MIN_DEVICES = 2

FLASK_HOST = "0.0.0.0"
FLASK_PORT = 5000
FLASK_DEBUG = True
