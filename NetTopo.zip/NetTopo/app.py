import json
import hashlib
import ipaddress
from copy import deepcopy
from collections import Counter
from threading import Lock

from flask import Flask, Response, jsonify, render_template, request

from system_settings import FLASK_DEBUG, FLASK_HOST, FLASK_PORT
from database.database import (
    clear_node_positions,
    create_tables,
    get_node_positions,
    save_node_positions,
)
from services.dashboard_service import run_discovery

app = Flask(__name__)
_scan_lock = Lock()
_cache = None


def _service_scan_options(body):
    supplied = body.get("service_target_ips") or []
    if not isinstance(supplied, list) or len(supplied) > 256:
        raise ValueError("Service targets must be a list of at most 256 IPv4 addresses")
    try:
        ips = list(dict.fromkeys(str(ipaddress.IPv4Address(str(value).strip())) for value in supplied))
    except ValueError:
        raise ValueError("Enter individual service-target IPv4 addresses; subnet ranges are not accepted")
    return {"service_target_ips": ips, "verify_services": body.get("verify_services") is True}

create_tables()


def _apply_saved_layout(payload):
    """Attach saved x/y positions to nodes without changing discovery data."""
    result = deepcopy(payload)
    nodes = result.get("nodes", [])
    # Browser-generated pending hops also have saved coordinates.
    node_ids = {str(node.get("id")) for node in nodes}
    node_ids.update("pending-hop:{}".format(row.get("key") or row.get("ip"))
                    for row in (result.get("metadata") or {}).get("credential_required") or [])
    positions = {key: value for key, value in get_node_positions().items() if key in node_ids}
    for node in nodes:
        saved = positions.get(str(node.get("id")))
        if saved:
            node["x"] = saved["x"]
            node["y"] = saved["y"]
            if saved.get("label_x") is not None:
                node["label_offset_x"] = saved["label_x"]
            if saved.get("label_y") is not None:
                node["label_offset_y"] = saved["label_y"]
            node["layout_saved"] = True
    result["layout"] = {
        "saved_positions": positions,
        "has_saved_layout": bool(positions),
    }
    return result


def _empty_dashboard_data():
    return {
        "nodes": [],
        "edges": [],
        "metadata": {"source": "idle", "message": "Waiting for user to start discovery"},
        "summary": {
            "total_devices": 0,
            "router_count": 0,
            "switch_count": 0,
            "managed_switch_count": 0,
            "layer3_switch_count": 0,
            "unmanaged_switch_count": 0,
            "end_device_count": 0,
            "link_count": 0,
            "cdp_links": 0,
            "arp_fdb_links": 0,
            "inferred_switch_links": 0,
            "scan_time": "",
            "scan_duration_seconds": 0,
            "target_network": "",
            "management_network": "",
            "gateway_ip": "",
            "switch_management_ips": [],
        },
        "devices": [],
        "services": [],
    }


def get_dashboard_data(force=False, scan_options=None):
    global _cache
    with _scan_lock:
        if force:
            # A Start Scan is a clean measurement. Never seed it with devices,
            # failed hops or topology observations from an earlier run/import.
            scan_options = dict(scan_options or {})
            scan_options.pop("known_devices", None)
            _cache = None
            # Saved coordinates belong to the previous scan. Only an explicit
            # Save Layout in this run may persist positions for these results.
            clear_node_positions()
            _cache = run_discovery(scan_options)
        if _cache is None:
            return _apply_saved_layout(_empty_dashboard_data())
        return _apply_saved_layout(_cache)


def _node_ip_set(nodes):
    values = set()
    for node in nodes or []:
        for key in ("ip", "management_ip"):
            value = str(node.get(key) or "").strip()
            if value:
                values.add(value)
        for value in node.get("management_ips") or []:
            value = str(value or "").strip()
            if value:
                values.add(value)
    return values


def _merge_dashboard_payload(base, branch, resolved_neighbor_key=None, resolved_neighbor_ip=None):
    """Merge a credential-resumed hop into the current topology cache.

    The branch scan starts only from the inaccessible neighbor.  Existing
    devices/links remain intact; no full rescan is required.
    """
    base = deepcopy(base or _empty_dashboard_data())
    branch = deepcopy(branch or _empty_dashboard_data())

    if resolved_neighbor_key and resolved_neighbor_ip:
        from topology.end_device_mapper import normalize_interface_name
        selected = next((row for row in (base.get("metadata") or {}).get("credential_required") or []
                         if (row.get("key") or row.get("ip")) == resolved_neighbor_key), None)
        if selected:
            for node in base.get("nodes", []):
                if selected.get("source_ip") != str(node.get("ip") or node.get("management_ip") or ""):
                    continue
                for field in ("cdp_neighbors", "lldp_neighbors"):
                    for neighbor in node.get(field) or []:
                        local = neighbor.get("local_port") or neighbor.get("local_interface") or "-"
                        if (normalize_interface_name(local) == normalize_interface_name(selected.get("local_interface") or "-")
                                and str(neighbor.get("management_ip") or "") == str(selected.get("ip") or "")):
                            neighbor.setdefault("advertised_management_ip", neighbor.get("management_ip") or "")
                            neighbor["management_ip"] = resolved_neighbor_ip
            base["metadata"]["credential_required"] = [row for row in base["metadata"]["credential_required"]
                                                       if (row.get("key") or row.get("ip")) != resolved_neighbor_key]

    node_map = {str(node.get("id")): node for node in base.get("nodes", []) if node.get("id") is not None}
    for node in branch.get("nodes", []):
        node_id = str(node.get("id"))
        if node_id in node_map:
            merged = dict(node_map[node_id])
            merged.update({k: v for k, v in node.items() if v not in (None, "", [], {})})
            for field in ("cdp_neighbors", "lldp_neighbors"):
                if field in node:
                    merged[field] = deepcopy(node[field])
            node_map[node_id] = merged
        else:
            node_map[node_id] = node
    nodes = list(node_map.values())
    hardware_types = {"router", "switch", "layer3_switch", "network_device"}
    from topology.device_reconciliation import reconcile_network_addresses
    from services.recursive_discovery_service import _merge_profile
    identity_profiles = {
        str(n["id"]): dict(n, query_ip=n.get("ip") or n.get("management_ip"),
                           interface_details={str(i): row for i, row in enumerate(n.get("interfaces") or []) if isinstance(row, dict)})
        for n in nodes if n.get("device_type") in hardware_types
    }
    _, _, node_aliases = reconcile_network_addresses(identity_profiles, _merge_profile)
    for old_id in node_aliases:
        node_map.pop(old_id, None)
    for identity, profile in identity_profiles.items():
        for field in ("management_ips", "identity_evidence", "cdp_neighbors", "lldp_neighbors"):
            if field in profile:
                node_map[identity][field] = profile[field]
        if profile.get("interface_details"):
            node_map[identity]["interfaces"] = list(profile["interface_details"].values())
    nodes = list(node_map.values())
    from topology.evidence_policy import network_ips, physical_topology
    confirmed_ips = network_ips(nodes)
    superseded = {str(n["id"]) for n in nodes if n.get("device_type") in {"end_device", "server", "printer"}
                  and str(n.get("ip") or n.get("management_ip")) in confirmed_ips}
    for node_id in superseded:
        node_map.pop(node_id, None)
    nodes = list(node_map.values())
    for node in nodes:
        device_type = node.get("device_type")
        if device_type not in hardware_types:
            continue
        node["icon_type"] = device_type if device_type != "network_device" else "unknown"
        node["group"] = "switch" if device_type in {"switch", "layer3_switch"} else "router"
        for field in ("service_role", "services", "service_identification"):
            node.pop(field, None)
        if node.get("display_type") == "Service Endpoint":
            node["display_type"] = {"switch": "Managed Switch", "layer3_switch": "Layer 3 Switch", "router": "Router"}.get(device_type, "Network Device")

    def edge_key(edge):
        from topology.end_device_mapper import normalize_interface_name
        a, b = str(edge.get("from")), str(edge.get("to"))
        endpoints = tuple(sorted(((a, normalize_interface_name(str(edge.get("local_interface") or ""))),
                                  (b, normalize_interface_name(str(edge.get("remote_interface") or ""))))))
        relation = str(edge.get("relation") or edge.get("protocol") or "")
        return endpoints + (("neighbor" if relation in {"cdp", "lldp", "cdp_lldp"} else relation),)

    edge_map = {}
    for edge in list(base.get("edges", [])) + list(branch.get("edges", [])):
        edge = dict(edge)
        for endpoint in ("from", "to"):
            while str(edge.get(endpoint)) in node_aliases:
                edge[endpoint] = node_aliases[str(edge[endpoint])]
        if str(edge.get("from")) == str(edge.get("to")):
            continue
        if str(edge.get("from")) in superseded or str(edge.get("to")) in superseded:
            continue
        edge_map[edge_key(edge)] = edge
    # Each community sees only part of the network. Validate neighbor evidence
    # again across BOTH snapshots to recover the links between scan branches.
    from topology.relationship_engine import build_validated_cdp_links, profile_ips, find_neighbor_identity
    from system_settings import REQUIRE_RECIPROCAL_CDP
    profiles = {}
    for node in nodes:
        if node.get("device_type") not in {"router", "switch", "layer3_switch", "network_device"}:
            continue
        node_id = str(node["id"])
        profile = dict(node, query_ip=node.get("ip") or node.get("management_ip"),
                       interface_details={str(i): row for i, row in enumerate(node.get("interfaces") or [])})
        profiles[node_id] = profile
    from topology.relationship_engine import build_profile_ip_index
    ip_index, _ = build_profile_ip_index(profiles)
    refreshed = {str(n["id"]) for n in branch.get("nodes", [])
                 if "cdp_neighbors" in n or "lldp_neighbors" in n}
    # Rebuild neighbor edges from current observations. Unioning cached edges
    # retained old cables after a port change and after CDP/LLDP reconciliation.
    observed = {identity for identity, profile in profiles.items()
                if profile.get("cdp_neighbors") or profile.get("lldp_neighbors")}
    branch_edge_keys = {edge_key(edge) for edge in branch.get("edges", [])}
    edge_map = {key: edge for key, edge in edge_map.items()
                if edge.get("relation") not in {"cdp", "lldp", "cdp_lldp"}
                or (key in branch_edge_keys and not ({str(edge.get("from")), str(edge.get("to"))} & observed))
                or not ({str(edge.get("from")), str(edge.get("to"))} & (refreshed | observed))}
    for link in build_validated_cdp_links(profiles, ip_index, require_reciprocal=REQUIRE_RECIPROCAL_CDP):
        edge = {
            "from": link["source_identity"], "to": link["target_identity"],
            "relation": link["relation"], "discovery": link["protocol"],
            "evidence": link["evidence"], "confidence": link["confidence"],
            "local_interface": link["local_interface"], "remote_interface": link["remote_interface"],
            "local_device": profiles[link["source_identity"]].get("hostname"),
            "remote_device": profiles[link["target_identity"]].get("hostname"),
            "label": "", "arrows": "",
        }
        edge_map[edge_key(edge)] = edge
    edges = list(edge_map.values())
    # Branches independently generate IDs such as cdp:1. Duplicate IDs make
    # vis.DataSet reject the merged graph after clearing the old display.
    for edge in edges:
        key = json.dumps(edge_key(edge), ensure_ascii=True)
        edge["id"] = "merged:" + hashlib.sha256(key.encode()).hexdigest()[:24]

    nodes, edges, unlocated = physical_topology(nodes, edges, confirmed_ips)
    node_map = {str(n["id"]): n for n in nodes}

    from topology.recursive_graph_builder import _calculate_levels
    roots = _node_ip_set([n for n in base.get("nodes", []) if n.get("level") == 0])
    root = next((str(n["id"]) for n in nodes if (n.get("ip") or n.get("management_ip")) in roots), str(nodes[0]["id"]) if nodes else "")
    levels = _calculate_levels(set(node_map), [{"source_identity": str(e["from"]), "target_identity": str(e["to"])} for e in edges], root)
    for node in nodes:
        node["level"] = levels[str(node["id"])]

    known_ips = _node_ip_set([node for node in nodes if node.get("device_type") in {"router", "switch", "layer3_switch", "network_device"}])
    pending = {}
    for row in list((base.get("metadata") or {}).get("credential_required") or []) + list((branch.get("metadata") or {}).get("credential_required") or []):
        if (str(row.get("protocol") or "").upper() in {"CDP", "LLDP"}
                and any(identity in refreshed and row.get("source_ip") in profile_ips(profile)
                        for identity, profile in profiles.items())):
            # Fresh neighbor tables below rebuild these rows, including new
            # hops. Do not retain advertisements removed from that source.
            continue
        ip = str(row.get("ip") or "").strip()
        possible_peers = {key: profile for key, profile in profiles.items()
                          if str(row.get("source_ip") or "") not in profile_ips(profile)}
        resolved = ip in known_ips if ip else find_neighbor_identity(possible_peers, ip_index, {"remote_device": row.get("hostname")})
        if row.get("address_conflict") or (ip not in known_ips and not resolved):
            key = row.get("key") or ip
            if key:
                pending[key] = row

    from services.neighbor_inventory import pending_neighbor_hops
    for row in pending_neighbor_hops(profiles, ip_index):
        # Replace older IP-keyed entries with current per-observation evidence.
        pending.pop(row["ip"], None)
        pending[row["key"]] = row

    metadata = dict(base.get("metadata") or {})
    metadata.update({k: v for k, v in (branch.get("metadata") or {}).items() if k != "credential_required"})
    metadata["source"] = "scan"
    metadata["credential_required"] = list(pending.values())
    metadata["neighbor_sources"] = [
        {"ip": p.get("query_ip"), "hostname": p.get("hostname"),
         "cdp_count": len(p.get("cdp_neighbors") or []), "lldp_count": len(p.get("lldp_neighbors") or [])}
        for p in profiles.values()
    ]
    metadata["discovery_complete"] = not bool(pending)
    metadata["service_endpoint_count"] = sum(n.get("device_type") == "end_device" and bool(n.get("services")) for n in nodes)
    metadata["continued_hop"] = True
    metadata["root_ip"] = (base.get("metadata") or {}).get("root_ip") or metadata.get("root_ip", "")
    if (base.get("metadata") or {}).get("requested_root_ips"):
        metadata["requested_root_ips"] = base["metadata"]["requested_root_ips"]

    counts = Counter(node.get("device_type", "unknown") for node in nodes)
    relations = Counter(edge.get("relation", "unknown") for edge in edges)
    old_summary = dict(base.get("summary") or {})
    new_summary = dict(branch.get("summary") or {})
    summary = dict(old_summary)
    summary.update({k: v for k, v in new_summary.items() if k in {"scan_time", "scan_level", "connection_mode"}})
    summary.update({
        "total_devices": len(nodes),
        "router_count": counts.get("router", 0),
        "switch_count": counts.get("switch", 0) + counts.get("layer3_switch", 0) + counts.get("unmanaged_switch", 0) + counts.get("inferred_trunk_switch", 0),
        "managed_switch_count": counts.get("switch", 0) + counts.get("layer3_switch", 0),
        "layer3_switch_count": counts.get("layer3_switch", 0),
        "unmanaged_switch_count": counts.get("unmanaged_switch", 0),
        "end_device_count": counts.get("end_device", 0),
        "link_count": len(edges),
        "cdp_links": relations.get("cdp", 0) + relations.get("lldp", 0) + relations.get("cdp_lldp", 0),
        "lldp_links": relations.get("lldp", 0) + relations.get("cdp_lldp", 0),
        "arp_fdb_links": relations.get("arp_fdb", 0) + relations.get("unmanaged_downstream", 0),
        "inferred_switch_links": relations.get("inferred_unmanaged_switch", 0) + relations.get("inferred_trunk_switch", 0),
        "scan_duration_seconds": round(float(new_summary.get("scan_duration_seconds") or 0), 2),
        "total_scan_duration_seconds": round(float(old_summary.get("total_scan_duration_seconds", old_summary.get("scan_duration_seconds")) or 0)
                                               + float(new_summary.get("scan_duration_seconds") or 0), 2),
    })
    from topology.network_information import lan_networks
    summary["lan_networks"] = sorted({network for node in nodes
                                       for network in (node.get("lan_networks") or lan_networks(node))})

    devices = []
    for node in nodes:
        devices.append({
            "id": node.get("id", ""), "ip": node.get("ip") or node.get("management_ip") or "-",
            "hostname": node.get("hostname") or "Unknown", "mac": node.get("mac") or "-",
            "device_type": node.get("device_type") or "unknown", "vendor": node.get("vendor") or "Unknown",
            "connected_to": node.get("connected_to") or "-", "port": node.get("switch_port") or node.get("uplink_port") or "-",
            "discovery": " + ".join(node.get("discovery") or []),
        })
    service_records = list(base.get("services") or []) + list(branch.get("services") or []) + [
        {"ip": n.get("ip"), "hostname": n.get("hostname"), "role": n.get("service_role"), "services": n.get("services")}
        for n in unlocated + nodes if n.get("services") and n.get("device_type") == "end_device"
    ]
    services = {str(row.get("ip")): row for row in service_records
                if str(row.get("ip")) not in confirmed_ips}
    placed_ips = {str(n.get("ip")) for n in nodes if n.get("device_type") == "end_device"}
    for row in services.values():
        row["connection_known"] = str(row.get("ip")) in placed_ips
    unlocated_map = {str(n.get("ip") or n.get("id")): n
                     for n in (base.get("metadata", {}).get("unlocated_endpoints", [])
                               + branch.get("metadata", {}).get("unlocated_endpoints", []) + unlocated)}
    metadata["unlocated_endpoints"] = [n for ip, n in unlocated_map.items()
                                       if ip not in confirmed_ips and ip not in placed_ips]
    metadata["unlocated_services"] = [row for row in services.values() if not row["connection_known"]]
    metadata["located_service_endpoint_count"] = sum(row["connection_known"] for row in services.values())
    metadata["service_endpoint_count"] = len(services)
    return {"nodes": nodes, "edges": edges, "metadata": metadata, "summary": summary, "devices": devices, "services": list(services.values())}


def _normalise_import_payload(data):
    """Accept this project's exported JSON and a topology-wrapped variant."""
    if not isinstance(data, dict):
        raise ValueError("JSON root must be an object")

    if isinstance(data.get("topology"), dict):
        topology = data["topology"]
        merged = dict(data)
        merged["nodes"] = topology.get("nodes", [])
        merged["edges"] = topology.get("edges", [])
        data = merged

    nodes = data.get("nodes")
    edges = data.get("edges")
    if not isinstance(nodes, list) or not isinstance(edges, list):
        raise ValueError("JSON must contain 'nodes' and 'edges' arrays")

    for node in nodes:
        if not isinstance(node, dict) or node.get("id") is None:
            raise ValueError("Every node must be an object with an 'id'")
        from database.device_catalog import apply_catalog
        apply_catalog(node)
        if node.get("device_type") == "layer3_switch":
            node["group"] = "switch"
            node["display_type"] = "Layer 3 Switch"
        elif node.get("device_type") == "switch":
            node["group"] = "switch"
            node["display_type"] = "Managed Switch"
    for edge in edges:
        if not isinstance(edge, dict) or edge.get("from") is None or edge.get("to") is None:
            raise ValueError("Every edge must contain 'from' and 'to'")

    payload = deepcopy(data)
    payload.setdefault("metadata", {})
    if not isinstance(payload.get("metadata"), dict):
        payload["metadata"] = {}
    payload["metadata"]["source"] = "import"
    payload.setdefault("services", [])

    # Older export files may not contain these convenience sections.
    if not isinstance(payload.get("devices"), list):
        payload["devices"] = [
            {
                "id": node.get("id", ""),
                "ip": node.get("ip") or node.get("management_ip") or "-",
                "hostname": node.get("hostname") or node.get("display_name") or "Unknown",
                "mac": node.get("mac") or "-",
                "device_type": node.get("device_type") or node.get("group") or "unknown",
                "vendor": node.get("vendor") or "Unknown",
                "connected_to": node.get("connected_to") or "-",
                "port": node.get("switch_port") or node.get("uplink_port") or "-",
                "discovery": " + ".join(node.get("discovery") or []),
            }
            for node in nodes
        ]

    if not isinstance(payload.get("summary"), dict):
        types = [node.get("device_type") or node.get("group") or "unknown" for node in nodes]
        payload["summary"] = {
            "total_devices": len(nodes),
            "router_count": types.count("router"),
            "switch_count": types.count("switch") + types.count("layer3_switch") + types.count("unmanaged_switch") + types.count("inferred_trunk_switch"),
            "managed_switch_count": types.count("switch") + types.count("layer3_switch"),
            "layer3_switch_count": types.count("layer3_switch"),
            "unmanaged_switch_count": types.count("unmanaged_switch"),
            "end_device_count": types.count("end_device"),
            "link_count": len(edges),
            "cdp_links": sum(1 for edge in edges if edge.get("relation") == "cdp"),
            "arp_fdb_links": sum(1 for edge in edges if edge.get("relation") in {"arp_fdb", "unmanaged_downstream"}),
            "inferred_switch_links": sum(1 for edge in edges if edge.get("relation") in {"inferred_unmanaged_switch", "inferred_trunk_switch"}),
            "scan_time": data.get("exported_at") or "",
            "scan_duration_seconds": 0,
            "target_network": "Imported topology",
            "management_network": "Imported topology",
            "gateway_ip": "",
            "switch_management_ips": [node.get("ip") for node in nodes if node.get("device_type") in {"switch", "layer3_switch"} and node.get("ip")],
        }

    # Catalog matching can change old imported classifications. Refresh counts
    # and table types even when the export already supplied a summary/table.
    types = Counter(node.get("device_type") or node.get("group") or "unknown" for node in nodes)
    payload["summary"].update({
        "router_count": types["router"],
        "layer3_switch_count": types["layer3_switch"],
        "managed_switch_count": types["switch"] + types["layer3_switch"],
        "switch_count": types["switch"] + types["layer3_switch"] + types["unmanaged_switch"] + types["inferred_trunk_switch"],
    })
    by_id = {str(node["id"]): node for node in nodes}
    for row in payload.get("devices") or []:
        node = by_id.get(str(row.get("id")))
        if node:
            row["device_type"] = node.get("device_type") or node.get("group") or "unknown"
    return payload


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/dashboard")
def dashboard():
    try:
        return jsonify(success=True, **get_dashboard_data(force=False))
    except Exception as exc:
        app.logger.exception("Could not build dashboard")
        return jsonify(success=False, error=str(exc)), 500


@app.route("/api/scan", methods=["POST"])
def scan():
    try:
        body = request.get_json(silent=True) or {}
        scan_level = str(body.get("scan_level") or "full").strip().lower()
        connection_mode = str(body.get("connection_mode") or "auto").strip().lower()
        snmp = body.get("snmp") if isinstance(body.get("snmp"), dict) else {}
        ssh = body.get("ssh") if isinstance(body.get("ssh"), dict) else {}
        root_ips = body.get("root_ips") if isinstance(body.get("root_ips"), list) else []
        root_ips = [str(ip).strip() for ip in root_ips if str(ip).strip()]

        if scan_level not in {"topology", "full"}:
            return jsonify(success=False, error="Invalid scan_level"), 400
        if connection_mode not in {"auto", "snmp", "ssh"}:
            return jsonify(success=False, error="Invalid connection_mode"), 400
        if len(root_ips) != 1:
            return jsonify(success=False, error="Please enter exactly one Root / Seed IP in Scan Options"), 400
        try:
            root_ips = [str(ipaddress.IPv4Address(root_ips[0]))]
        except ValueError:
            return jsonify(success=False, error="Please enter one valid Root / Seed IPv4 address"), 400

        supplied_community = str(snmp.get("community") or "").strip()
        ssh_enabled = bool(ssh.get("enabled") and str(ssh.get("username") or "").strip())
        if connection_mode == "snmp" and not supplied_community:
            return jsonify(success=False, error="SNMP mode requires a Community String in Settings"), 400
        if connection_mode == "ssh" and not ssh_enabled:
            return jsonify(success=False, error="SSH mode requires an enabled SSH credential"), 400
        if connection_mode == "auto" and not supplied_community and not ssh_enabled:
            return jsonify(success=False, error="Enter SNMP or SSH information in Settings"), 400

        # Credentials are used only for this scan request and are not written
        # to SQLite or returned to the browser.
        scan_options = {
            **_service_scan_options(body),
            "scan_level": scan_level,
            "connection_mode": connection_mode,
            "root_ips": root_ips,
            "snmp_community": supplied_community,
            "ssh": {
                "enabled": bool(ssh.get("enabled")),
                "username": str(ssh.get("username") or "").strip(),
                "password": str(ssh.get("password") or ""),
                "port": int(ssh.get("port") or 22),
                "device_type": str(ssh.get("device_type") or "auto"),
            },
        }
        return jsonify(success=True, **get_dashboard_data(force=True, scan_options=scan_options))
    except ValueError as exc:
        return jsonify(success=False, error=str(exc)), 400
    except Exception as exc:
        app.logger.exception("Could not scan network")
        return jsonify(success=False, error=str(exc)), 500


@app.route("/api/scan/continue", methods=["POST"])
def continue_scan_hop():
    """Resume discovery from one inaccessible CDP/LLDP neighbor.

    This endpoint intentionally scans only the selected hop with the credential
    entered in the popup, then merges the result into the current topology.
    """
    global _cache
    try:
        body = request.get_json(silent=True) or {}
        root_ip = str(body.get("root_ip") or "").strip()
        if not root_ip:
            return jsonify(success=False, error="Neighbor IP is required"), 400
        scan_level = str(body.get("scan_level") or "topology").strip().lower()
        if scan_level not in {"topology", "full"}:
            scan_level = "topology"
        connection_mode = str(body.get("connection_mode") or "auto").strip().lower()
        if connection_mode not in {"auto", "snmp", "ssh"}:
            connection_mode = "auto"
        snmp = body.get("snmp") if isinstance(body.get("snmp"), dict) else {}
        ssh = body.get("ssh") if isinstance(body.get("ssh"), dict) else {}
        community = str(snmp.get("community") or "").strip()
        ssh_enabled = bool(ssh.get("enabled") and str(ssh.get("username") or "").strip())
        if not community and not ssh_enabled:
            return jsonify(success=False, error="Enter an SNMP Community or SSH credential for this hop"), 400

        options = {
            **_service_scan_options(body),
            "scan_level": scan_level,
            "connection_mode": connection_mode,
            "root_ips": [root_ip],
            "snmp_community": community,
            "ssh": {
                "enabled": bool(ssh.get("enabled")),
                "username": str(ssh.get("username") or "").strip(),
                "password": str(ssh.get("password") or ""),
                "port": int(ssh.get("port") or 22),
                "device_type": str(ssh.get("device_type") or "auto"),
            },

        }
        with _scan_lock:
            options["resume"] = True
            options["scan_level"] = "topology"
            options["skip_ips"] = sorted({str(node.get("ip") or node.get("management_ip"))
                                           for node in (_cache or {}).get("nodes", [])
                                           if node.get("device_type") in {"router", "switch", "layer3_switch", "network_device"}
                                           and (node.get("ip") or node.get("management_ip"))} - {root_ip})
            branch = run_discovery(options)
            branch.setdefault("metadata", {})["resume_scope"] = "new-cdp-lldp-hops"
            _cache = _merge_dashboard_payload(_cache, branch,
                                              resolved_neighbor_key=str(body.get("neighbor_key") or ""),
                                              resolved_neighbor_ip=root_ip)
            result = _apply_saved_layout(_cache)
        return jsonify(success=True, **result)
    except ValueError as exc:
        return jsonify(success=False, error=str(exc)), 400
    except Exception as exc:
        app.logger.exception("Could not continue hop discovery")
        return jsonify(success=False, error=str(exc)), 500


@app.route("/api/topology")
def topology():
    try:
        data = get_dashboard_data(force=False)
        return jsonify(
            success=True,
            nodes=data["nodes"],
            edges=data["edges"],
            metadata=data["metadata"],
            layout=data.get("layout", {}),
        )
    except Exception as exc:
        app.logger.exception("Could not build topology")
        return jsonify(success=False, nodes=[], edges=[], error=str(exc)), 500


@app.route("/api/layout", methods=["GET", "POST", "DELETE"])
def layout():
    try:
        if request.method == "GET":
            positions = get_node_positions()
            return jsonify(success=True, positions=positions)

        if request.method == "DELETE":
            deleted = clear_node_positions()
            return jsonify(success=True, deleted=deleted)

        body = request.get_json(silent=True) or {}
        positions = body.get("positions", {})
        if not isinstance(positions, dict):
            return jsonify(success=False, error="positions must be an object"), 400
        saved = save_node_positions(positions)
        return jsonify(success=True, saved=saved)
    except Exception as exc:
        app.logger.exception("Could not update topology layout")
        return jsonify(success=False, error=str(exc)), 500


@app.route("/api/import", methods=["POST"])
def import_topology():
    global _cache
    try:
        if "file" not in request.files:
            return jsonify(success=False, error="Please choose a JSON file"), 400
        upload = request.files["file"]
        if not upload.filename:
            return jsonify(success=False, error="Please choose a JSON file"), 400
        if not upload.filename.lower().endswith(".json"):
            return jsonify(success=False, error="Only .json files are supported"), 400

        raw = upload.read()
        if len(raw) > 10 * 1024 * 1024:
            return jsonify(success=False, error="JSON file is too large (max 10 MB)"), 413
        data = json.loads(raw.decode("utf-8-sig"))
        imported = _normalise_import_payload(data)

        # If the exported file contains node coordinates, persist them so the
        # same arrangement survives browser/server restarts.
        imported_positions = {}
        for node in imported["nodes"]:
            if node.get("x") is not None and node.get("y") is not None:
                imported_positions[str(node["id"])] = {
                    "x": node["x"], "y": node["y"],
                    "label_x": node.get("label_offset_x"),
                    "label_y": node.get("label_offset_y"),
                }
        if imported_positions:
            save_node_positions(imported_positions)

        with _scan_lock:
            _cache = imported

        payload = _apply_saved_layout(imported)
        return jsonify(success=True, imported=True, filename=upload.filename, **payload)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        return jsonify(success=False, error=f"Invalid JSON file: {exc}"), 400
    except ValueError as exc:
        return jsonify(success=False, error=str(exc)), 400
    except Exception as exc:
        app.logger.exception("Could not import topology")
        return jsonify(success=False, error=str(exc)), 500


@app.route("/api/export/json")
def export_json():
    payload = get_dashboard_data(force=False)
    export_payload = deepcopy(payload)
    export_payload["export_version"] = "4.21"
    # x/y are already attached by _apply_saved_layout for positions saved in DB.
    body = json.dumps(export_payload, ensure_ascii=False, indent=2)
    return Response(
        body,
        mimetype="application/json",
        headers={"Content-Disposition": "attachment; filename=network_topology.json"},
    )



@app.route("/api/health")
def health():
    return jsonify(success=True, version="4.23-complete-router-discovery-model")


if __name__ == "__main__":
    app.run(host=FLASK_HOST, port=FLASK_PORT, debug=FLASK_DEBUG)
