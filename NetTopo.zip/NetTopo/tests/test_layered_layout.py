import ast
from copy import deepcopy
from pathlib import Path
from threading import Lock
import unittest
from unittest.mock import Mock

from scanner.ssh_collector import _apply_nat_statistics
from topology.layered_layout import apply_layered_layout, nat_outside_ports
from scanner.nat import CNAT_INTERFACE_REALM, enrich_nat_interfaces


class LayeredLayoutTests(unittest.TestCase):
    def test_snmp_nat_roles_generate_cloud_on_outside_port(self):
        details = {'10': {'name': 'Gi0/0'}, '20': {'name': 'Gi0/1'}}
        enrich_nat_interfaces('10.0.0.1', 'public', details, walk=lambda *args: [
            (CNAT_INTERFACE_REALM + '.10', '2'),
            (CNAT_INTERFACE_REALM + '.20', '1'),
        ])
        payload = {'nodes': [{'id': 'r', 'device_type': 'router',
                              'interfaces': list(details.values())}], 'edges': []}
        apply_layered_layout(payload)
        self.assertEqual(len(payload['nodes']), 2)
        self.assertEqual(len(payload['edges']), 1)
        self.assertEqual(payload['edges'][0]['local_interface'], 'Gi0/0')
        self.assertEqual(details['20']['nat_role'], 'inside')

    def test_unsupported_nat_mib_preserves_interface_inventory(self):
        details = {'1': {'name': 'Gi0/0'}}
        enrich_nat_interfaces('10.0.0.1', 'public', details, walk=Mock(side_effect=TimeoutError()))
        self.assertEqual(details, {'1': {'name': 'Gi0/0'}})

    def test_imported_interface_details_generate_cloud(self):
        payload = {'nodes': [{'id': 'r', 'device_type': 'router',
                              'interface_details': {'1': {'name': 'Gi0/0', 'nat': 'outside'}}}],
                   'edges': []}
        apply_layered_layout(payload)
        self.assertEqual(payload['edges'][0]['local_interface'], 'Gi0/0')

    def test_cloud_layers_and_scan_root_are_independent(self):
        details = {'1': {'name': 'GigabitEthernet0/0'}, '2': {'name': 'GigabitEthernet0/1'}}
        _apply_nat_statistics(details, 'Outside interfaces:\n Gi0/0\nInside interfaces:\n Gi0/1\nHits: 0')
        self.assertEqual(details['1']['nat_role'], 'outside')
        self.assertNotIn('nat_role', details['2'])
        payload = {
            'nodes': [
                {'id': 'r', 'device_type': 'router', 'interfaces': list(details.values())},
                {'id': 's', 'device_type': 'switch', 'ip': '10.0.0.2'},
                {'id': 'pc', 'device_type': 'end_device'},
            ],
            'edges': [{'from': 'r', 'to': 's'}, {'from': 's', 'to': 'pc'}],
            'metadata': {'root_ip': '10.0.0.2'},
        }
        apply_layered_layout(payload)
        self.assertEqual([n['level'] for n in payload['nodes']], [1, 2, 3, 0])
        self.assertTrue(payload['nodes'][1]['is_root'])
        self.assertFalse(payload['nodes'][-1]['is_root'])
        self.assertEqual(payload['edges'][-1]['local_interface'], 'GigabitEthernet0/0')
        self.assertTrue(payload['edges'][-1]['dashes'])
        snapshot = deepcopy(payload)
        apply_layered_layout(payload)
        self.assertEqual(payload, snapshot)

    def test_inside_nat_and_unmarked_ports_do_not_infer_internet(self):
        self.assertEqual(nat_outside_ports({'interfaces': [
            {'name': 'Gi0/0', 'nat_role': 'inside'},
            {'name': 'Gi0/1', 'alias': 'NAT inside'},
            {'name': 'Gi0/2', 'alias': 'LAN'},
        ]}), {})
        self.assertIn('Gi0/3', nat_outside_ports({'interfaces': [{'name': 'Gi0/3', 'alias': 'NAT'}]}))

    def test_cycles_and_disconnected_components_have_finite_hop_layers(self):
        payload = {'nodes': [{'id': str(i), 'device_type': 'router'} for i in range(5)],
                   'edges': [{'from': '0', 'to': '1'}, {'from': '1', 'to': '2'},
                             {'from': '2', 'to': '0'}, {'from': '3', 'to': '4'}]}
        apply_layered_layout(payload)
        self.assertEqual([n['level'] for n in payload['nodes']], [0, 1, 1, 2, 3])

    def test_new_scan_discards_import_and_scans_again_on_each_request(self):
        # Exercise the actual cache orchestration without Flask/SNMP dependencies.
        tree = ast.parse(Path('app.py').read_text())
        function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'get_dashboard_data')
        discovery = Mock(side_effect=[{'nodes': [{'id': 'new'}]}, {'nodes': [{'id': 'newer'}]}])
        clear = Mock()
        namespace = {'_cache': {'nodes': [{'id': 'imported'}]}, '_scan_lock': Lock(),
                     'run_discovery': discovery, 'clear_node_positions': clear,
                     '_apply_saved_layout': lambda value: value, '_empty_dashboard_data': lambda: {}}
        exec(compile(ast.Module(body=[function], type_ignores=[]), 'app.py', 'exec'), namespace)
        options = {'root_ips': ['10.0.0.1'], 'known_devices': [{'id': 'imported'}]}
        self.assertEqual(namespace['get_dashboard_data'](True, options)['nodes'][0]['id'], 'new')
        self.assertEqual(namespace['get_dashboard_data'](True, options)['nodes'][0]['id'], 'newer')
        self.assertEqual(discovery.call_count, 2)
        self.assertEqual(clear.call_count, 2)
        for call in discovery.call_args_list:
            self.assertNotIn('known_devices', call.args[0])
        self.assertIn('known_devices', options)


if __name__ == '__main__':
    unittest.main()
