# import os
# import sys

# # บรรทัดพวกนี้จะหาพาธของโฟลเดอร์หลัก (network_topology) แล้วแอดเข้า Python Path ให้แบบอัตโนมัติ
# BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# if BASE_DIR not in sys.path:
#     sys.path.append(BASE_DIR)
# from discover import discover_hosts
# from device import get_device
# from database.database import insert_device

# hosts = discover_hosts("192.168.56.0/24")

# for ip in hosts:

#     device = get_device(ip)

#     if device["hostname"]:

#         device["ip"] = ip

#         insert_device(device)

#         print(device)

# #/////////////////////////////////////////////////////////////

import os
import sys

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.append(BASE_DIR)

from scanner.discover import discover_hosts
from scanner.device import get_device, discover_end_devices
from scanner.cdp import get_cdp_neighbors
from scanner.interface import get_interface_map
from scanner.fdb import get_mac_port_table
from scanner.arp import get_arp_table

from database.database import insert_device

from database.end_device import (
    create_table,
    clear_end_devices,
    insert_end_device
)

NETWORK = "192.168.56.0/24"

# -----------------------------
# 1. Scan ทุก Host
# -----------------------------

hosts = discover_hosts(NETWORK)

print(f"\nพบ Host จำนวน {len(hosts)} เครื่อง\n")

# -----------------------------
# 2. เก็บ Router / Switch
# -----------------------------

network_devices = []

for ip in hosts:

    print("=" * 60)
    print("Scanning :", ip)

    device = get_device(ip)

    if device["hostname"]:

        device["ip"] = ip

        insert_device(device)

        network_devices.append(device)

        print("Hostname :", device["hostname"])

    else:

        print("No SNMP")
        continue

# -----------------------------
# 3. CDP Discovery
# -----------------------------

print("\n")
print("=" * 60)
print("CDP DISCOVERY")
print("=" * 60)

for device in network_devices:

    print(f"\nDevice : {device['hostname']} ({device['ip']})")

    neighbors = get_cdp_neighbors(device["ip"])

    if not neighbors:

        print("No CDP Neighbor")
        continue

    for n in neighbors:

        print(
            f"{n['local_port']} --> "
            f"{n['remote_device']} "
            f"{n['management_ip']} "
            f"({n['remote_port']})"
        )

# -----------------------------
# 4. End Device Discovery
# -----------------------------

print("\n")
print("=" * 60)
print("END DEVICE DISCOVERY")
print("=" * 60)

for device in network_devices:

    switch_ip = device["ip"]

    print(f"\nSwitch : {switch_ip}")

    try:

        interface_map = get_interface_map(switch_ip)

        fdb_table = get_mac_port_table(switch_ip)

        arp_table = get_arp_table(switch_ip)

        print("\n===== DEBUG =====")
        print("ARP")
        print(arp_table)

        print("\nFDB")
        print(fdb_table)

        print("\nINTERFACE")
        print(interface_map)
        print("=================\n")
        end_devices = discover_end_devices(
            arp_table,
            fdb_table,
            interface_map
        )

        if not end_devices:

            print("No End Device")

        for end in end_devices:

            insert_end_device(
                switch_ip=switch_ip,
                interface=end["interface"],
                ip=end["ip"],
                mac=end["mac"]
            )

            print(
                end["interface"],
                end["ip"],
                end["mac"]
            )

    except Exception as e:

        print(e)
