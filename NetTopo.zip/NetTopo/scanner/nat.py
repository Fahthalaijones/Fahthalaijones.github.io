"""Read Cisco NAT interface roles through SNMP, including SNMP-only scans."""

# Cisco's public MIB: github.com/cisco/cisco-mibs/blob/main/v2/CISCO-IETF-NAT-MIB.my
CNAT_INTERFACE_REALM = "1.3.6.1.4.1.9.10.77.1.1.4.1.2"


def enrich_nat_interfaces(ip, community, details, walk=None):
    if walk is None:
        from scanner.snmp import snmp_walk
        walk = snmp_walk
    try:
        rows = walk(ip, CNAT_INTERFACE_REALM, community)
        for oid, value in rows:
            prefix = CNAT_INTERFACE_REALM + "."
            if not str(oid).startswith(prefix):
                continue
            interface = details.get(str(oid)[len(prefix):])
            if interface is None:
                continue
            realm = str(value).strip().lower()
            role = {"1": "inside", "private": "inside", "private(1)": "inside",
                    "2": "outside", "public": "outside", "public(2)": "outside"}.get(realm)
            if role:
                interface["nat_role"] = role
                interface["nat_evidence"] = "CISCO-IETF-NAT-MIB cnatInterfaceRealm: " + realm
    except Exception:
        # Unsupported NAT MIBs must not prevent the rest of discovery.
        return
