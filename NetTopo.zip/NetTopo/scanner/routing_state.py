"""Interpret Cisco routing evidence without confusing a management gateway with routing."""
import re


def cisco_routing_state(config_text, route_text):
    if re.search(r"^\s*no ip routing\s*$", config_text, re.M | re.I):
        return False
    if re.search(r"^\s*(?:ip routing|ipv6 unicast-routing)\s*$", config_text, re.M | re.I):
        return True
    # A real IOS route entry has a routing code, unlike the host-mode
    # 'Default gateway is ... / Host / Gateway' management table.
    if re.search(r"^\s*(?:C|L|S\*?|O(?:\s+(?:IA|E1|E2|N1|N2))?|D(?:\s+EX)?|B|R)\s+\d{1,3}(?:\.\d{1,3}){3}/\d+", route_text, re.M):
        return True
    if re.search(r"Default gateway is|IP routing (?:is )?not enabled", route_text, re.I):
        return False
    return None
