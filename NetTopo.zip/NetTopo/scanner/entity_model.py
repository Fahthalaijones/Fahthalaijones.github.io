"""Vendor-neutral hardware model discovery through ENTITY-MIB.

ENTITY-MIB is an IETF standard implemented by many enterprise vendors.  The
collector intentionally does not contain a vendor/model allow-list.
"""
from typing import Dict

from scanner.snmp import snmp_walk

ENT_PHYSICAL_CLASS = "1.3.6.1.2.1.47.1.1.1.1.5"
ENT_PHYSICAL_DESCR = "1.3.6.1.2.1.47.1.1.1.1.2"
ENT_PHYSICAL_NAME = "1.3.6.1.2.1.47.1.1.1.1.7"
ENT_PHYSICAL_MODEL = "1.3.6.1.2.1.47.1.1.1.1.13"


def _suffix_map(rows, base_oid: str) -> Dict[str, str]:
    prefix = base_oid.rstrip(".") + "."
    return {oid[len(prefix):]: str(value or "").strip() for oid, value in rows if oid.startswith(prefix)}


def _clean(value: object) -> str:
    text = " ".join(str(value or "").replace("\x00", " ").split()).strip()
    if text.lower() in {"", "unknown", "none", "n/a", "-", "0"}:
        return ""
    return text


def get_entity_hardware(ip: str, community: str = "public") -> Dict[str, str]:
    """Return the best chassis model/name/description from ENTITY-MIB.

    entPhysicalClass=3 means chassis.  If a device does not expose class data,
    prefer the first useful model name.  Empty dict means ENTITY-MIB was not
    available and callers should fall back to sysDescr/sysObjectID.
    """
    models = _suffix_map(snmp_walk(ip, ENT_PHYSICAL_MODEL, community), ENT_PHYSICAL_MODEL)
    if not models:
        return {}
    classes = _suffix_map(snmp_walk(ip, ENT_PHYSICAL_CLASS, community), ENT_PHYSICAL_CLASS)
    names = _suffix_map(snmp_walk(ip, ENT_PHYSICAL_NAME, community), ENT_PHYSICAL_NAME)
    descrs = _suffix_map(snmp_walk(ip, ENT_PHYSICAL_DESCR, community), ENT_PHYSICAL_DESCR)

    indexes = list(models)
    chassis = [idx for idx in indexes if str(classes.get(idx, "")).strip() in {"3", "chassis", "chassis(3)"}]
    ordered = chassis + [idx for idx in indexes if idx not in chassis]
    for idx in ordered:
        model = _clean(models.get(idx))
        if not model:
            continue
        return {
            "hardware_model": model,
            "hardware_name": _clean(names.get(idx)),
            "hardware_description": _clean(descrs.get(idx)),
            "entity_index": idx,
        }
    return {}
