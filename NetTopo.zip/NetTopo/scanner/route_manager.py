"""Temporary route management for the GNS3 discovery lab."""

import ipaddress
import os
import subprocess
from typing import Dict


def route_exists(network: str) -> bool:
    try:
        result = subprocess.run(
            ["ip", "route", "show", network],
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError:
        return False
    return bool(result.stdout.strip())


def ensure_route(network: str, gateway: str) -> Dict[str, object]:
    result = {
        "network": network,
        "gateway": gateway,
        "changed": False,
        "success": True,
        "message": "route already available",
    }

    try:
        network_obj = ipaddress.ip_network(network, strict=False)
        gateway_obj = ipaddress.ip_address(gateway)
    except ValueError as exc:
        result.update(success=False, message=str(exc))
        return result

    if route_exists(str(network_obj)):
        return result

    if os.geteuid() != 0:
        result.update(
            success=False,
            message="root permission is required to add the discovered route",
        )
        return result

    command = [
        "ip", "route", "replace", str(network_obj), "via", str(gateway_obj)
    ]
    process = subprocess.run(command, capture_output=True, text=True, check=False)
    if process.returncode == 0:
        result.update(changed=True, message="route added")
    else:
        result.update(
            success=False,
            message=(process.stderr or process.stdout or "route command failed").strip(),
        )
    return result
