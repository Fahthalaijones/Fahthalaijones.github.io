"""Fast vendor/model helpers based on data already collected by SNMP.

No additional SNMP walks are performed here.  The goal is to keep discovery
fast while turning sysDescr/sysObjectID into useful UI text.
"""
import re
from typing import Dict

ENTERPRISE_VENDORS = {
    "9": "Cisco",
    "11": "HPE / HP",
    "2636": "Juniper",
    "14988": "MikroTik",
    "14823": "Aruba",
    "41112": "Ubiquiti",
}

# Small exact map for product OIDs that are used by the lab/current topology.
# Unknown products still fall back to sysDescr or a normalized Hardware ID.
PRODUCT_MODELS = {
    # CISCO-PRODUCTS-MIB: ciscoCat9407R (Catalyst 9400, 7-slot chassis).
    "1.3.6.1.4.1.9.1.2500": "Cisco Catalyst C9407R",
    # Cisco lab/router images
    "1.3.6.1.4.1.9.1.222": "Cisco 7206VXR",

    # CISCO-PRODUCTS-MIB: cat38xxstack. This identifies the stack family,
    # not an individual member's exact chassis/SKU.
    # https://github.com/cisco/cisco-mibs/blob/main/v2/CISCO-PRODUCTS-MIB.my
    "1.3.6.1.4.1.9.1.1745": "Cisco Catalyst 38xx Stack",

    # Catalyst 3560-X family (CISCO-PRODUCTS-MIB).  Keeping these exact
    # sysObjectID mappings avoids exposing a raw Hardware ID when sysDescr
    # contains only the IOS software image name.
    "1.3.6.1.4.1.9.1.1226": "Cisco Catalyst 3560X-24",
    "1.3.6.1.4.1.9.1.1227": "Cisco Catalyst 3560X-48P-E",
    "1.3.6.1.4.1.9.1.1228": "Cisco Catalyst 3560X-24P",
    "1.3.6.1.4.1.9.1.1229": "Cisco Catalyst 3560X-48P",

    # Catalyst 3650 image used by the current lab.
    "1.3.6.1.4.1.9.1.1824": "Cisco Catalyst 3650-48TS",
}


def clean_text(value: object) -> str:
    value = str(value or "").replace("\x00", " ")
    value = " ".join(value.split())
    return "".join(ch for ch in value if ch.isprintable()).strip()


def normalize_object_id(value: object) -> str:
    text = clean_text(value).strip(".")
    if not text:
        return ""
    text = text.replace("SNMPv2-SMI::enterprises.", "1.3.6.1.4.1.")
    text = text.replace("enterprises.", "1.3.6.1.4.1.")
    # pysnmp can occasionally return iso.3.6... instead of a dotted numeric OID.
    if text.startswith("iso."):
        text = "1." + text[4:]
    match = re.search(r"(?:^|[^0-9])(1\.3\.6\.1\.4\.1(?:\.\d+)+)$", text)
    return match.group(1) if match else text


def enterprise_number(object_id: object) -> str:
    oid = normalize_object_id(object_id)
    match = re.match(r"^1\.3\.6\.1\.4\.1\.(\d+)(?:\.|$)", oid)
    return match.group(1) if match else ""


def vendor_from_profile(profile: Dict[str, object]) -> str:
    raw = clean_text(profile.get("description"))
    lower = raw.lower()
    checks = (
        ("cisco", "Cisco"), ("mikrotik", "MikroTik"), ("routeros", "MikroTik"),
        ("juniper", "Juniper"), ("aruba", "Aruba"), ("hewlett", "HPE / HP"),
        ("procurve", "HPE / HP"), ("ubiquiti", "Ubiquiti"),
    )
    for token, vendor in checks:
        if token in lower:
            return vendor
    ent = enterprise_number(profile.get("object_id"))
    if ent in ENTERPRISE_VENDORS:
        return ENTERPRISE_VENDORS[ent]
    return "Enterprise {}".format(ent) if ent else "Unknown"


def model_from_profile(profile: Dict[str, object]) -> str:
    for key in ("model", "hardware_model", "platform", "product_name", "board_name"):
        value = clean_text(profile.get(key))
        # Imported/previously normalized profiles may carry an old fallback
        # in model. It must not hide a real hardware model or an OID mapping.
        if value.lower().startswith("hardware id ") or re.fullmatch(r"\.?\d+(?:\.\d+)+", value):
            continue
        if value and value.lower() not in {"unknown", "none", "n/a", "-"}:
            return value[:120]

    raw = clean_text(profile.get("description"))
    lower = raw.lower()
    oid = normalize_object_id(profile.get("object_id"))

    # An exact product OID is stronger than a generic software description.
    if oid in PRODUCT_MODELS:
        return PRODUCT_MODELS[oid]

    if raw and not lower.startswith("0x"):
        labelled = re.search(
            r"(?:model(?:\s+name|\s+number)?|product(?:\s+name)?|platform|hardware|board(?:-name)?)"
            r"\s*[:=]\s*([A-Za-z0-9][A-Za-z0-9._/+ -]{1,70})", raw, re.I,
        )
        if labelled:
            return labelled.group(1).strip(" ,;-")[:120]

        if "mikrotik" in lower or "routeros" in lower:
            if "chr" in lower:
                return "MikroTik CHR"
            return "MikroTik RouterOS"

        if "cisco" in lower:
            if re.search(r"\bC?7206VXR\b", raw, re.I):
                return "Cisco 7206VXR"
            if re.search(r"\bC?7200\b", raw, re.I):
                return "Cisco 7200"
            if "LINUX_L2" in raw.upper() or "IOSVL2" in raw.upper():
                image = re.search(r"Software\s*\(([^)]+)\)", raw, re.I)
                return ("Cisco L2 ({})".format(image.group(1).strip()) if image else "Cisco IOSvL2")[:120]
            image = re.search(r"Software\s*\(([^)]+)\)", raw, re.I)
            if image:
                return "Cisco ({})".format(image.group(1).strip())[:120]
            return "Cisco IOS"

        first = re.split(r"[\r\n;]", raw, maxsplit=1)[0].strip(" ,;-")
        if first:
            return first[:120]

    return "Hardware ID {}".format(oid)[:120] if oid else "Unknown"
