"""Concurrent, lightweight SNMP probing."""

from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Iterable, List

from scanner.snmp import snmp_get

SYS_NAME = "1.3.6.1.2.1.1.5.0"
SYS_OBJECT_ID = "1.3.6.1.2.1.1.2.0"


def responds_to_snmp(ip: str, community: str) -> bool:
    try:
        return bool(snmp_get(ip, SYS_NAME, community) or snmp_get(ip, SYS_OBJECT_ID, community))
    except Exception:
        return False


def find_snmp_hosts(
    ips: Iterable[str],
    community: str,
    max_workers: int = 24,
) -> List[str]:
    unique_ips = sorted({str(ip) for ip in ips if ip})
    found: List[str] = []

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(responds_to_snmp, ip, community): ip
            for ip in unique_ips
        }
        for future in as_completed(futures):
            ip = futures[future]
            try:
                if future.result():
                    found.append(ip)
            except Exception:
                continue

    return sorted(found)
