import nmap

def discover_hosts(network):

    nm = nmap.PortScanner()

    print(f"Scanning {network}")

    nm.scan(
        hosts=network,
        arguments="-sn"
    )

    hosts = []

    for host in nm.all_hosts():

        if nm[host].state() == "up":

            hosts.append(host)

    return hosts


if __name__ == "__main__":

    devices = discover_hosts("192.168.56.0/24")

    print(devices)
