"""Read a switch forwarding database and map MAC addresses to interfaces."""

from typing import Dict, List

from scanner.arp import normalize_mac
from scanner.interface import get_interface_map
from scanner.snmp import snmp_walk
from scanner.vlan import get_access_vlan_by_ifindex, get_vlan_database

DOT1D_BASE_PORT_IFINDEX = "1.3.6.1.2.1.17.1.4.1.2"
DOT1D_TP_FDB_PORT = "1.3.6.1.2.1.17.4.3.1.2"


def get_bridge_port_mapping(
    ip: str,
    community: str = "public",
) -> Dict[str, str]:
    mapping: Dict[str, str] = {}
    for oid, value in snmp_walk(ip, DOT1D_BASE_PORT_IFINDEX, community):
        mapping[oid.split(".")[-1]] = str(value)
    return mapping


def get_fdb_table(ip: str, community: str = "public") -> List[dict]:
    rows: List[dict] = []
    prefix = DOT1D_TP_FDB_PORT + "."

    for oid, bridge_port in snmp_walk(ip, DOT1D_TP_FDB_PORT, community):
        if not oid.startswith(prefix):
            continue

        mac_numbers = oid[len(prefix):].split(".")
        if len(mac_numbers) != 6:
            continue

        try:
            mac = ":".join(f"{int(number):02X}" for number in mac_numbers)
        except ValueError:
            continue

        rows.append({"mac": normalize_mac(mac), "bridge_port": str(bridge_port)})

    return rows


def get_mac_port_table(
    ip: str,
    community: str = "public",
    *,
    interfaces=None,
    access_vlans=None,
    vlan_names=None,
) -> List[dict]:
    bridge_map = get_bridge_port_mapping(ip, community)
    if interfaces is None:
        interfaces = get_interface_map(ip, community)
    if access_vlans is None:
        access_vlans = get_access_vlan_by_ifindex(ip, community)
    if vlan_names is None:
        vlan_names = get_vlan_database(ip, community)
    result: List[dict] = []

    for entry in get_fdb_table(ip, community):
        ifindex = bridge_map.get(entry["bridge_port"], "")
        result.append(
            {
                **entry,
                "ifindex": ifindex,
                "interface": interfaces.get(ifindex, f"ifIndex {ifindex}" if ifindex else "Unknown"),
                "vlan": access_vlans.get(ifindex),
                "vlan_name": vlan_names.get(access_vlans.get(ifindex)) if access_vlans.get(ifindex) else "",
            }
        )

    return result
