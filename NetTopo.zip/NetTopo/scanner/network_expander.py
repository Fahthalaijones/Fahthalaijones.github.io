"""Extract safe connected IPv4 networks from SNMP interface addresses."""

import ipaddress
from typing import Dict, List, Set


def networks_from_profile(
    profile: Dict[str, object],
    private_only: bool = True,
    max_hosts: int = 1024,
) -> List[str]:
    networks: Set[str] = set()

    for row in profile.get("ip_addresses", []):
        ip_value = row.get("ip")
        netmask = row.get("netmask")
        if not ip_value or not netmask:
            continue

        try:
            address = ipaddress.ip_address(ip_value)
            network = ipaddress.ip_network(
                "{}/{}".format(ip_value, netmask), strict=False
            )
        except ValueError:
            continue

        if address.is_loopback or address.is_link_local or address.is_multicast:
            continue
        if private_only and not network.is_private:
            continue
        if network.num_addresses > max_hosts:
            continue

        networks.add(str(network))

    return sorted(networks)
