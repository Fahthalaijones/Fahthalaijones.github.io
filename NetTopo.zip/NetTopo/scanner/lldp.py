"""IEEE LLDP neighbor discovery through LLDP-MIB.

Works with Cisco and MikroTik implementations by joining standard LLDP-MIB remote-table columns
with the common (timeMark, localPortNum, remIndex) suffix.  The local LLDP
port number is resolved through lldpLocPortId/Desc instead of assuming it is
an IF-MIB ifIndex.
"""

import ipaddress
from typing import Dict, List

from scanner.snmp import snmp_walk

LLDP_REM_CHASSIS = "1.0.8802.1.1.2.1.4.1.1.5"
LLDP_REM_PORT_ID = "1.0.8802.1.1.2.1.4.1.1.7"
LLDP_REM_PORT_DESC = "1.0.8802.1.1.2.1.4.1.1.8"
LLDP_REM_SYS_NAME = "1.0.8802.1.1.2.1.4.1.1.9"
LLDP_REM_SYS_DESC = "1.0.8802.1.1.2.1.4.1.1.10"
LLDP_REM_MAN_ADDR_IF_SUBTYPE = "1.0.8802.1.1.2.1.4.2.1.3"
LLDP_LOC_PORT_ID = "1.0.8802.1.1.2.1.3.7.1.3"
LLDP_LOC_PORT_DESC = "1.0.8802.1.1.2.1.3.7.1.4"


def _suffix_map(rows, base_oid: str) -> Dict[str, str]:
    prefix = base_oid.rstrip(".") + "."
    return {oid[len(prefix):]: value for oid, value in rows if oid.startswith(prefix)}


def _remote_key(suffix: str) -> str:
    # lldpRemEntry index = timeMark.localPortNum.remIndex
    parts = suffix.split(".")
    return ".".join(parts[:3]) if len(parts) >= 3 else suffix


def _local_port_map(ip: str, community: str) -> Dict[str, str]:
    ids = _suffix_map(snmp_walk(ip, LLDP_LOC_PORT_ID, community), LLDP_LOC_PORT_ID)
    desc = _suffix_map(snmp_walk(ip, LLDP_LOC_PORT_DESC, community), LLDP_LOC_PORT_DESC)
    indexes = set(ids) | set(desc)
    return {
        idx: _best_port_id(ids.get(idx, ""), desc.get(idx, ""), f"LLDP port {idx}")
        for idx in indexes
    }


def _decode_printable_hex_port(value: str) -> str:
    """Recover text when an older collector rendered a text Port ID as hex/MAC.

    RouterOS commonly advertises Port ID ``ether1``.  Six ASCII bytes may have
    been rendered as ``65:74:68:65:72:31`` by older generic SNMP formatting.
    Keep real MAC addresses unchanged and only decode clearly printable text.
    """
    text = str(value or "").strip()
    compact = text.replace(":", "").replace("-", "").replace(" ", "")
    if len(compact) >= 4 and len(compact) % 2 == 0:
        try:
            raw = bytes.fromhex(compact)
            decoded = raw.decode("utf-8").strip("\x00").strip()
            if decoded and all(ch.isprintable() for ch in decoded) and any(ch.isalpha() for ch in decoded):
                return decoded
        except (ValueError, UnicodeDecodeError):
            pass
    return text


def _best_port_id(port_id: str, port_desc: str, fallback: str) -> str:
    port_id = _decode_printable_hex_port(port_id)
    port_desc = _decode_printable_hex_port(port_desc)
    from topology.end_device_mapper import normalize_mac
    if (port_id.isdigit() or normalize_mac(port_id)) and port_desc and not normalize_mac(port_desc):
        return port_desc
    # Prefer a human-readable interface ID.  RouterOS may describe a bridge
    # member as bridge/ether1; the Port ID itself (ether1) is the physical port.
    for value in (port_id, port_desc):
        value = str(value or "").strip()
        if value and value.lower() not in {"unknown", "none", "0"}:
            return value
    return fallback


def _management_addresses(ip: str, community: str) -> Dict[str, str]:
    """Best-effort IPv4 extraction from lldpRemManAddrTable indexes."""
    result: Dict[str, str] = {}
    prefix = LLDP_REM_MAN_ADDR_IF_SUBTYPE + "."
    for oid, _ in snmp_walk(ip, LLDP_REM_MAN_ADDR_IF_SUBTYPE, community):
        if not oid.startswith(prefix):
            continue
        suffix = oid[len(prefix):]
        parts = suffix.split(".")
        if len(parts) < 7:
            continue
        key = ".".join(parts[:3])
        nums = []
        for token in parts[3:]:
            try:
                nums.append(int(token))
            except ValueError:
                nums.append(-1)
        # Variable-length OCTET STRING indexes are commonly encoded as
        # subtype, length, address-octets.  Taking the final four octets is
        # robust for IPv4 on both Cisco and RouterOS LLDP-MIB outputs.
        if len(nums) == 6 and nums[:2] == [1, 4] and all(0 <= n <= 255 for n in nums[-4:]):
            candidate = ".".join(str(n) for n in nums[-4:])
            try:
                address = ipaddress.ip_address(candidate)
            except ValueError:
                continue
            if address.version == 4 and not address.is_unspecified:
                result.setdefault(key, str(address))
    return result


def get_lldp_neighbors(ip: str, community: str = "public") -> List[dict]:
    chassis = _suffix_map(snmp_walk(ip, LLDP_REM_CHASSIS, community), LLDP_REM_CHASSIS)
    # Chassis ID is mandatory in an LLDP remote entry. On a device without
    # LLDP-MIB, don't time out on another eight absent columns.
    if not chassis:
        return []
    port_ids = _suffix_map(snmp_walk(ip, LLDP_REM_PORT_ID, community), LLDP_REM_PORT_ID)
    port_desc = _suffix_map(snmp_walk(ip, LLDP_REM_PORT_DESC, community), LLDP_REM_PORT_DESC)
    systems = _suffix_map(snmp_walk(ip, LLDP_REM_SYS_NAME, community), LLDP_REM_SYS_NAME)
    descriptions = _suffix_map(snmp_walk(ip, LLDP_REM_SYS_DESC, community), LLDP_REM_SYS_DESC)
    local_ports = _local_port_map(ip, community)
    management = _management_addresses(ip, community)

    all_suffixes = set(chassis) | set(port_ids) | set(port_desc) | set(systems) | set(descriptions)
    neighbors: List[dict] = []
    seen = set()
    for suffix in sorted(all_suffixes):
        key = _remote_key(suffix)
        parts = key.split(".")
        if len(parts) < 3:
            continue
        local_port_num = parts[1]
        remote_device = systems.get(suffix) or systems.get(key) or chassis.get(suffix) or chassis.get(key) or "Unknown"
        remote_port = _best_port_id(
            port_ids.get(suffix) or port_ids.get(key) or "",
            port_desc.get(suffix) or port_desc.get(key) or "",
            "Unknown",
        )
        row = {
            "source_ip": ip,
            "local_ifindex": local_port_num,
            "local_port": local_ports.get(local_port_num, f"LLDP port {local_port_num}"),
            "remote_device": remote_device,
            "remote_port": remote_port,
            "management_ip": management.get(key, ""),
            "platform": descriptions.get(suffix) or descriptions.get(key) or "",
            "chassis": chassis.get(suffix) or chassis.get(key) or "",
            "protocol": "LLDP",
        }
        dedupe = (row["local_port"], row["remote_device"], row["remote_port"], row["management_ip"])
        if dedupe not in seen:
            seen.add(dedupe)
            neighbors.append(row)
    return neighbors
