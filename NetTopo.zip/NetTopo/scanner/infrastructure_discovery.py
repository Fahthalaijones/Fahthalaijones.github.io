"""Find infrastructure at concrete ARP addresses; never expand a subnet."""
import ipaddress
from concurrent.futures import ThreadPoolExecutor

from scanner.arp import get_arp_table
from scanner.snmp_probe import responds_to_snmp
from scanner.snmp import snmp_session
from system_settings import SNMP_PROBE_WORKERS


def find_arp_snmp_candidates(profile, credential_profiles, excluded_ips=()):
    communities = list(dict.fromkeys(str(row.get('snmp_community') or '').strip()
                                    for row in credential_profiles if row.get('snmp_community')))
    if not communities:
        return []
    if '_arp_scan_cache' not in profile:
        if 'arp_entries' in profile:
            profile['_arp_scan_cache'] = list(profile.get('arp_entries') or [])
        elif profile.get('_snmp_community'):
            with snmp_session():
                profile['_arp_scan_cache'] = get_arp_table(profile['query_ip'], profile['_snmp_community'])
        else:
            profile['_arp_scan_cache'] = []
    excluded = set(excluded_ips)
    excluded.add(str(profile.get('query_ip') or ''))
    candidates = []
    for row in profile['_arp_scan_cache']:
        try:
            address = ipaddress.IPv4Address(str(row.get('ip') or ''))
        except ValueError:
            continue
        if address.is_unspecified or address.is_multicast or address.is_loopback or str(address) in excluded:
            continue
        if str(address) not in candidates:
            candidates.append(str(address))
    profile['_arp_snmp_target_count'] = len(candidates)

    def probe(ip):
        # Each probe owns and closes its engine; never reuse a previous run.
        with snmp_session():
            return ip if any(responds_to_snmp(ip, community) for community in communities) else None

    with ThreadPoolExecutor(max_workers=SNMP_PROBE_WORKERS) as executor:
        return [ip for ip in executor.map(probe, candidates) if ip]
