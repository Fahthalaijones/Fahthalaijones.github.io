"""Read IPv4 routes from a router through the legacy IP-MIB route table.

The route table is used only to expand the discovery scan scope. It must not
be used as proof that two devices are directly connected.
"""

import ipaddress
from typing import Dict, List, Optional

from scanner.snmp import snmp_walk

IP_ROUTE_DEST = "1.3.6.1.2.1.4.21.1.1"
IP_ROUTE_IFINDEX = "1.3.6.1.2.1.4.21.1.2"
IP_ROUTE_NEXT_HOP = "1.3.6.1.2.1.4.21.1.7"
IP_ROUTE_TYPE = "1.3.6.1.2.1.4.21.1.8"
IP_ROUTE_MASK = "1.3.6.1.2.1.4.21.1.11"


def _value_map(rows, base_oid: str) -> Dict[str, str]:
    prefix = base_oid.rstrip(".") + "."
    result: Dict[str, str] = {}
    for full_oid, value in rows:
        if full_oid.startswith(prefix):
            result[full_oid[len(prefix):]] = value
    return result


def _is_usable_network(
    destination: str,
    netmask: str,
    private_only: bool,
    max_hosts: int,
) -> Optional[str]:
    try:
        network = ipaddress.ip_network(
            "{}/{}".format(destination, netmask),
            strict=False,
        )
    except ValueError:
        return None

    if network.version != 4:
        return None
    if network.prefixlen == 0 or network.prefixlen == 32:
        return None
    if network.is_loopback or network.is_link_local or network.is_multicast:
        return None
    if private_only and not network.is_private:
        return None
    if network.num_addresses > max_hosts:
        return None
    return str(network)


def get_ipv4_routes(
    ip: str,
    community: str = "public",
    private_only: bool = True,
    max_hosts: int = 4096,
) -> List[Dict[str, object]]:
    """Return safe IPv4 route records from an SNMP router.

    Route types from RFC1213/IP-MIB:
      2 = invalid, 3 = direct, 4 = indirect.
    """
    destinations = _value_map(snmp_walk(ip, IP_ROUTE_DEST, community), IP_ROUTE_DEST)
    masks = _value_map(snmp_walk(ip, IP_ROUTE_MASK, community), IP_ROUTE_MASK)
    next_hops = _value_map(
        snmp_walk(ip, IP_ROUTE_NEXT_HOP, community), IP_ROUTE_NEXT_HOP
    )
    ifindexes = _value_map(
        snmp_walk(ip, IP_ROUTE_IFINDEX, community), IP_ROUTE_IFINDEX
    )
    route_types = _value_map(snmp_walk(ip, IP_ROUTE_TYPE, community), IP_ROUTE_TYPE)

    routes: List[Dict[str, object]] = []
    seen = set()
    for suffix, destination_value in destinations.items():
        destination = destination_value or suffix
        netmask = masks.get(suffix, "")
        network = _is_usable_network(
            destination,
            netmask,
            private_only=private_only,
            max_hosts=max_hosts,
        )
        if not network or network in seen:
            continue

        route_type_text = str(route_types.get(suffix, "")).strip()
        try:
            route_type = int(route_type_text)
        except ValueError:
            route_type = 0
        if route_type == 2:
            continue

        seen.add(network)
        routes.append({
            "network": network,
            "destination": destination,
            "netmask": netmask,
            "next_hop": next_hops.get(suffix, "0.0.0.0"),
            "ifindex": ifindexes.get(suffix, ""),
            "route_type": route_type,
            "route_kind": "direct" if route_type == 3 else "indirect",
            "source_router": ip,
        })

    return sorted(routes, key=lambda row: row["network"])
