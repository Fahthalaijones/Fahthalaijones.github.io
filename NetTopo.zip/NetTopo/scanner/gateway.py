"""Read the host's default IPv4 gateway without changing its routes."""

import ipaddress
import platform
import subprocess


def get_default_gateway():
    if platform.system() == "Windows":
        command = [
            "powershell.exe", "-NoProfile", "-NonInteractive", "-Command",
            "Get-NetIPConfiguration | Where-Object { $_.IPv4DefaultGateway "
            "-and $_.NetAdapter.Status -eq 'Up' } | "
            "Sort-Object { $_.NetIPv4Interface.InterfaceMetric } | "
            "ForEach-Object { $_.IPv4DefaultGateway.NextHop } | Select-Object -First 1",
        ]
        result = subprocess.run(command, capture_output=True, text=True, timeout=10, check=True)
        address = result.stdout.strip()
    elif platform.system() == "Linux":
        # /proc also works on hosts that do not have the ip command installed.
        with open("/proc/net/route", encoding="ascii") as routes:
            candidates = []
            for line in list(routes)[1:]:
                fields = line.split()
                if len(fields) > 7 and fields[1] == "00000000" and int(fields[3], 16) & 3 == 3:
                    address = str(ipaddress.IPv4Address(bytes.fromhex(fields[2])[::-1]))
                    candidates.append((int(fields[6]), address))
        address = min(candidates)[1] if candidates else ""
    else:
        result = subprocess.run(["route", "-n", "get", "default"], capture_output=True,
                                text=True, timeout=10, check=True)
        address = next((line.split(":", 1)[1].strip() for line in result.stdout.splitlines()
                        if line.strip().startswith("gateway:")), "")
    gateway = ipaddress.IPv4Address(address)
    if gateway.is_unspecified:
        raise ValueError("No default IPv4 gateway")
    return str(gateway)
