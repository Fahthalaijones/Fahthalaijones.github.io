"""SSH/CLI fallback collector for network discovery.

This module is intentionally optional.  The project keeps SNMP as the primary
collector, but when an operator supplies SSH credentials the discovery engine
can obtain the core topology evidence through CLI commands instead.
"""

import ipaddress
import re
import socket
import time
import shutil
from typing import Dict, List, Optional


def _netmiko():
    try:
        from netmiko import ConnectHandler, SSHDetect
    except ImportError:
        raise RuntimeError(
            "SSH fallback requires Netmiko. Install it with: pip3 install netmiko"
        )
    return ConnectHandler, SSHDetect


def _device_type_name(value: str) -> str:
    value = (value or "auto").strip().lower()
    return {
        "cisco_ios": "cisco_ios",
        "cisco": "cisco_ios",
        "mikrotik_routeros": "mikrotik_routeros",
        "mikrotik": "mikrotik_routeros",
    }.get(value, "auto")


LEGACY_KEX = (
    "diffie-hellman-group14-sha1",
    "diffie-hellman-group-exchange-sha1",
    "diffie-hellman-group1-sha1",
)
LEGACY_CIPHERS = ("aes256-cbc", "aes128-cbc", "aes192-cbc", "3des-cbc")
LEGACY_HOST_KEYS = ("ssh-rsa",)


def _prepend_supported(preferred, current):
    """Prepend legacy algorithms only when Paramiko itself supports them."""
    result = []
    for item in tuple(preferred) + tuple(current):
        if item in current and item not in result:
            result.append(item)
    return tuple(result)


class _LegacyOpenSSHConnection:
    """CLI wrapper using the host OpenSSH client for very old IOS SSH stacks.

    Modern devices are still handled by Netmiko/Paramiko first.  This class is
    used only after an SSH algorithm-negotiation error.  It deliberately enables
    legacy algorithms per process/connection, not in /etc/ssh/ssh_config.

    This is useful for old Cisco images (for example C7200) that only offer
    SHA-1 KEX, ssh-rsa host keys and CBC ciphers.  The same command works when
    tested manually with OpenSSH, so this fallback avoids differences between
    Paramiko builds/security policies.
    """

    LEGACY_PROFILES = (
        ("diffie-hellman-group14-sha1", "aes128-cbc"),
        ("diffie-hellman-group-exchange-sha1", "aes128-cbc"),
        ("diffie-hellman-group1-sha1", "aes128-cbc"),
        ("diffie-hellman-group14-sha1", "aes256-cbc"),
        ("diffie-hellman-group14-sha1", "aes192-cbc"),
        ("diffie-hellman-group1-sha1", "3des-cbc"),
    )

    def __init__(self, ip, username, password, port=22, timeout=10):
        try:
            import pexpect
        except ImportError:
            raise RuntimeError(
                "Legacy SSH fallback requires pexpect. Install it with: pip3 install pexpect"
            )

        self._pexpect = pexpect
        self._child = None
        self._prompt_re = r"(?m)[^\r\n]+[>#]\s*$"
        self.legacy_kex = ""
        self.legacy_cipher = ""
        self._connect(ip, username, password, int(port), int(timeout))

    @staticmethod
    def _ssh_args(ip, username, port, kex, cipher, timeout):
        return [
            "-p", str(port),
            "-o", "BatchMode=no",
            "-o", "PreferredAuthentications=password,keyboard-interactive",
            "-o", "PubkeyAuthentication=no",
            "-o", "StrictHostKeyChecking=no",
            "-o", "UserKnownHostsFile=/dev/null",
            "-o", "LogLevel=ERROR",
            "-o", "ConnectTimeout=%s" % timeout,
            "-o", "KexAlgorithms=+%s" % kex,
            "-o", "HostKeyAlgorithms=+ssh-rsa",
            "-o", "Ciphers=+%s" % cipher,
            "%s@%s" % (username, ip),
        ]

    def _connect(self, ip, username, password, port, timeout):
        errors = []
        for kex, cipher in self.LEGACY_PROFILES:
            child = None
            try:
                args = self._ssh_args(ip, username, port, kex, cipher, timeout)
                child = self._pexpect.spawn(
                    shutil.which("ssh") or "ssh", args=args, encoding="utf-8", timeout=timeout
                )
                # Password can be requested as "Password:" or "admin@host's password:".
                idx = child.expect([
                    r"(?i)(?:password|passphrase):\s*$",
                    r"(?i)are you sure you want to continue connecting.*yes/no.*",
                    self._prompt_re,
                    self._pexpect.EOF,
                    self._pexpect.TIMEOUT,
                ])
                if idx == 1:
                    child.sendline("yes")
                    idx = child.expect([r"(?i)(?:password|passphrase):\s*$", self._prompt_re,
                                        self._pexpect.EOF, self._pexpect.TIMEOUT])
                    if idx == 0:
                        child.sendline(password)
                        child.expect(self._prompt_re)
                    elif idx != 1:
                        raise RuntimeError("SSH did not reach a CLI prompt")
                elif idx == 0:
                    child.sendline(password)
                    # Authentication failures are surfaced clearly rather than
                    # trying every legacy algorithm with a bad password.
                    auth_idx = child.expect([
                        self._prompt_re,
                        r"(?i)permission denied|authentication failed|(?:password|passphrase):\s*$",
                        self._pexpect.EOF,
                        self._pexpect.TIMEOUT,
                    ])
                    if auth_idx == 1:
                        raise PermissionError("SSH authentication failed")
                    if auth_idx != 0:
                        raise RuntimeError("SSH connection closed before CLI prompt")
                elif idx == 2:
                    pass
                else:
                    msg = (child.before or "").strip()
                    raise RuntimeError(msg or "SSH negotiation failed")

                self._child = child
                self.legacy_kex = kex
                self.legacy_cipher = cipher
                # Disable paging on Cisco IOS. Ignore errors on non-Cisco devices.
                try:
                    self.send_command("terminal length 0", read_timeout=4)
                except Exception:
                    pass
                return
            except PermissionError:
                if child is not None:
                    try:
                        child.close(force=True)
                    except Exception:
                        pass
                raise
            except Exception as exc:
                errors.append("%s/%s: %s" % (kex, cipher, exc))
                if child is not None:
                    try:
                        child.close(force=True)
                    except Exception:
                        pass

        raise RuntimeError("Legacy OpenSSH fallback failed: " + "; ".join(errors[-3:]))

    def send_command(self, command, read_timeout=12):
        if self._child is None:
            raise RuntimeError("SSH session is not connected")
        self._child.sendline(str(command).rstrip())
        old_timeout = self._child.timeout
        self._child.timeout = read_timeout
        try:
            self._child.expect(self._prompt_re)
            output = self._child.before or ""
        finally:
            self._child.timeout = old_timeout
        lines = output.replace("\r", "").splitlines()
        # pexpect output normally starts with the command echo.
        while lines and not lines[0].strip():
            lines.pop(0)
        if lines and lines[0].strip() == str(command).strip():
            lines = lines[1:]
        return "\n".join(lines).strip()

    def find_prompt(self):
        if self._child is None:
            return "Unknown#"
        self._child.sendline("")
        old_timeout = self._child.timeout
        self._child.timeout = 3
        try:
            self._child.expect(self._prompt_re)
            # matched prompt is available in after
            return (self._child.after or "Unknown#").strip()
        finally:
            self._child.timeout = old_timeout

    def disconnect(self):
        if self._child is None:
            return
        try:
            self._child.sendline("exit")
        except Exception:
            pass
        try:
            self._child.close(force=True)
        except Exception:
            pass
        self._child = None

def _is_algorithm_negotiation_error(exc):
    text = str(exc).lower()
    return any(token in text for token in (
        "no acceptable kex",
        "no matching key exchange",
        "incompatible ssh peer",
        "no matching host key",
        "no matching cipher",
        "incompatiblepeer",
        "key exchange method",
    ))


def _connect_legacy(ip: str, ssh: Dict[str, object]):
    username = str(ssh.get("username") or "").strip()
    password = str(ssh.get("password") or "")
    port = int(ssh.get("port") or 22)
    conn = _LegacyOpenSSHConnection(ip, username, password, port=port)
    return conn, "cisco_ios_legacy"


def _is_authentication_error(exc):
    text = str(exc).lower()
    return any(token in text for token in (
        "authentication failed",
        "permission denied",
        "auth fail",
        "bad authentication",
        "incorrect password",
    ))


def _tcp_port_open(ip: str, port: int, timeout: float = 2.5) -> bool:
    try:
        with socket.create_connection((ip, int(port)), timeout=timeout):
            return True
    except OSError:
        return False


def _connect(ip: str, ssh: Dict[str, object]):
    ConnectHandler, SSHDetect = _netmiko()
    username = str(ssh.get("username") or "").strip()
    password = str(ssh.get("password") or "")
    port = int(ssh.get("port") or 22)
    requested = _device_type_name(str(ssh.get("device_type") or "auto"))
    if not username:
        raise RuntimeError("SSH username is required")

    base = {
        "host": ip,
        "username": username,
        "password": password,
        "port": port,
        "conn_timeout": 5,
        "banner_timeout": 6,
        "auth_timeout": 6,
        "fast_cli": True,
    }

    modern_error = None
    try:
        if requested == "auto":
            detector = SSHDetect(device_type="autodetect", **base)
            detected = detector.autodetect()
            if not detected:
                detected = "cisco_ios"
            base["device_type"] = detected
        else:
            base["device_type"] = requested
        return ConnectHandler(**base), base["device_type"]
    except Exception as exc:
        modern_error = exc

    # Never reinterpret an authentication failure as a legacy-algorithm issue.
    if _is_authentication_error(modern_error):
        raise modern_error

    # Old IOS/7200 images can make Netmiko/Paramiko fail before Netmiko wraps
    # the exception with the original KEX text.  If TCP/22 is reachable we
    # therefore also try the system OpenSSH fallback, not only when the exact
    # exception string happens to match our KEX detector.
    should_try_legacy = (
        _is_algorithm_negotiation_error(modern_error)
        or _tcp_port_open(ip, port)
    )

    if should_try_legacy:
        if not shutil.which("ssh"):
            raise RuntimeError(
                "Modern SSH failed ({}) and system OpenSSH was not found for legacy fallback"
                .format(modern_error)
            )
        try:
            return _connect_legacy(ip, ssh)
        except Exception as legacy_exc:
            raise RuntimeError(
                "Modern SSH failed: {}; Legacy OpenSSH fallback failed: {}"
                .format(modern_error, legacy_exc)
            )

    raise modern_error

def can_connect_ssh(ip: str, ssh: Dict[str, object]) -> bool:
    conn = None
    try:
        conn, _ = _connect(ip, ssh)
        return True
    except Exception:
        return False
    finally:
        if conn is not None:
            try:
                conn.disconnect()
            except Exception:
                pass


def _safe_command(conn, command: str) -> str:
    try:
        return conn.send_command(command, read_timeout=12) or ""
    except Exception:
        return ""


def _hostname_from_prompt(prompt: str) -> str:
    return re.sub(r"[>#\s]+$", "", str(prompt or "").strip()) or "Unknown"


def _parse_interfaces(text: str):
    interface_map: Dict[str, str] = {}
    details: Dict[str, dict] = {}
    addresses: List[dict] = []
    idx = 1
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line or line.lower().startswith("interface"):
            continue
        parts = re.split(r"\s+", line)
        if len(parts) < 5:
            continue
        name, ip_value = parts[0], parts[1]
        status = parts[-2]
        protocol = parts[-1]
        if not re.match(r"^[A-Za-z]", name):
            continue
        key = str(idx)
        interface_map[key] = name
        details[key] = {
            "ifindex": key,
            "name": name,
            "description": "",
            "admin_status": "up" if status.lower() not in {"administratively", "disabled"} else "down",
            "status": protocol,
            "speed": "",
            "mtu": "",
            "mac": "",
            "ip_addresses": [],
            "interface_kind": "SVI" if name.lower().startswith("vlan") else "Physical/Logical",
        }
        try:
            ipaddress.ip_address(ip_value)
            row = {"ip": ip_value, "netmask": "", "ifindex": key}
            addresses.append(row)
            details[key]["ip_addresses"].append({"ip": ip_value, "netmask": ""})
        except ValueError:
            pass
        idx += 1
    return interface_map, details, addresses


def _apply_nat_statistics(details, text):
    """Keep only named outside interfaces from Cisco's read-only NAT summary."""
    match = re.search(r"Outside interfaces:\s*(.*?)(?=\bInside interfaces:|\bHits:|\bExpired translations:|\Z)",
                      text or "", re.I | re.S)
    if not match:
        return
    names = re.findall(r"[A-Za-z][A-Za-z-]*\d[\w/.:\-]*", match.group(1))

    def key(name):
        # Interface names may be abbreviated in CLI output.
        return re.sub(r"[^a-z0-9/.:-]", "", re.sub(
            r"^(GigabitEthernet|FastEthernet|TenGigabitEthernet|Ethernet)",
            lambda m: {"gigabitethernet": "gi", "fastethernet": "fa",
                       "tengigabitethernet": "te", "ethernet": "eth"}[m.group(1).lower()],
            name, flags=re.I).lower())

    outside = {key(name) for name in names}
    for detail in details.values():
        if key(str(detail.get("name") or "")) in outside:
            detail["nat_role"] = "outside"
            detail["nat_evidence"] = "show ip nat statistics: Outside interfaces: " + detail["name"]


def _parse_neighbors(text: str, source: str = "CDP") -> List[dict]:
    neighbors = []
    # A single LLDP record contains both Local Intf and Chassis id. Splitting
    # at both markers detached the local interface from its neighbor.
    marker = r"Local Intf\s*:" if re.search(r"Local Intf\s*:", text or "", re.I) else (
        r"Device ID\s*:" if source.upper() == "CDP" else r"Chassis id\s*:")
    blocks = re.split(r"(?=" + marker + r")", text or "", flags=re.I)
    for block in blocks:
        device = re.search(r"(?:Device ID|System Name)\s*:\s*([^\r\n]+)", block, re.I)
        mgmt = re.search(r"(?:IP address|Management Address|Management address)\s*:\s*([0-9.]+)", block, re.I)
        local = re.search(r"(?:Interface|Local Intf)\s*:\s*([^,\r\n]+)", block, re.I)
        remote = re.search(r"(?:Port ID \(outgoing port\)|Port id|Port ID)\s*:\s*([^\r\n]+)", block, re.I)
        platform = re.search(r"Platform\s*:\s*([^,\r\n]+)", block, re.I)
        capabilities = re.search(r"Capabilities\s*:\s*([^\r\n]+)", block, re.I)
        if not device and not mgmt:
            continue
        neighbors.append({
            "remote_device": (device.group(1).strip() if device else "Unknown"),
            "management_ip": (mgmt.group(1).strip() if mgmt else ""),
            "local_interface": (local.group(1).strip() if local else "Unknown"),
            "remote_interface": (remote.group(1).strip() if remote else "Unknown"),
            "local_ifindex": "",
            "protocol": source,
            "platform": platform.group(1).strip() if platform else "",
            "capabilities": capabilities.group(1).strip() if capabilities else "",
        })
    return neighbors


def _parse_routes(text: str) -> List[dict]:
    results = []
    seen = set()
    for line in (text or "").splitlines():
        # Match route prefixes such as 192.168.10.0/24. Host /32 routes are ignored.
        for match in re.finditer(r"\b((?:\d{1,3}\.){3}\d{1,3})/(\d{1,2})\b", line):
            cidr = match.group(0)
            if cidr in seen:
                continue
            try:
                network = ipaddress.ip_network(cidr, strict=False)
            except ValueError:
                continue
            if network.prefixlen >= 31:
                continue
            seen.add(str(network))
            next_hop = ""
            via = re.search(r"via\s+((?:\d{1,3}\.){3}\d{1,3})", line, re.I)
            if via:
                next_hop = via.group(1)
            results.append({"network": str(network), "next_hop": next_hop, "ifindex": ""})
    return results


def _parse_arp(text: str) -> List[dict]:
    from scanner.arp import normalize_mac
    import ipaddress
    rows = []
    for line in (text or "").splitlines():
        parts = line.split()
        if len(parts) < 6 or parts[0].lower() != "internet":
            continue
        try:
            address = str(ipaddress.IPv4Address(parts[1]))
        except ValueError:
            continue
        mac = normalize_mac(parts[3])
        if mac and mac != "00:00:00:00:00:00":
            rows.append({"ip": address, "mac": mac, "ifindex": "", "interface": parts[-1]})
    return rows


def build_ssh_device_profile(ip: str, ssh: Dict[str, object], scan_level: str = "topology", neighbor_only=False) -> Dict[str, object]:
    conn = None
    try:
        conn, platform = _connect(ip, ssh)
        prompt = conn.find_prompt()
        hostname = _hostname_from_prompt(prompt)
        version = _safe_command(conn, "show version")
        int_brief = _safe_command(conn, "show ip interface brief")
        interfaces, interface_details, addresses = _parse_interfaces(int_brief)
        _apply_nat_statistics(interface_details, _safe_command(conn, "show ip nat statistics"))

        cdp_text = _safe_command(conn, "show cdp neighbors detail")
        cdp_neighbors = _parse_neighbors(cdp_text, "CDP")
        lldp_text = _safe_command(conn, "show lldp neighbors detail")
        lldp_neighbors = _parse_neighbors(lldp_text, "LLDP")

        description = version.strip() or platform
        from database.device_catalog import lookup_device_model
        from scanner.routing_state import cisco_routing_state
        lower = version.lower()
        is_switch = any(token in lower for token in ("iosvl2", "linux_l2", "l2 image", "ethernet switch"))
        is_switch = is_switch or bool(lookup_device_model({"description": description})) or "catalyst" in lower
        route_text = "" if neighbor_only else _safe_command(conn, "show ip route")
        routing_config = _safe_command(conn, "show running-config | include ^ip routing|^no ip routing|^ipv6 unicast-routing")
        routing_enabled = cisco_routing_state(routing_config, route_text)
        routes = _parse_routes(route_text) if routing_enabled is True else []
        device_type = "switch" if is_switch else "router"

        profile = {
            "hostname": hostname,
            "description": description,
            "object_id": "",
            "query_ip": ip,
            "interfaces": interfaces,
            "interface_details": interface_details,
            "ip_addresses": addresses,
            "ip_forwarding": "1" if routing_enabled is True else ("2" if routing_enabled is False else ""),
            "routing_enabled": routing_enabled,
            "bridge_address": "ssh-detected" if device_type == "switch" else "",
            "cdp_neighbors": cdp_neighbors,
            "lldp_neighbors": lldp_neighbors,
            "route_networks": routes,
            "vlan_database": [],
            "device_type": device_type,
            "access_method": "SSH-Legacy" if "legacy" in str(platform).lower() else "SSH",
            "ssh_platform": platform,
            "ssh_kex": getattr(conn, "legacy_kex", ""),
            "ssh_cipher": getattr(conn, "legacy_cipher", ""),
        }
        from database.device_catalog import apply_catalog
        if scan_level == "full":
            profile["arp_entries"] = _parse_arp(_safe_command(conn, "show ip arp"))
        return apply_catalog(profile)
    finally:
        if conn is not None:
            try:
                conn.disconnect()
            except Exception:
                pass
