"""Fast, service-focused enrichment for already mapped end devices.

This deliberately avoids -sV/-O/-sC.  Nmap's service database can provide a
useful rough service name from well-known TCP ports without expensive version
probing.  The purpose is topology enrichment, not vulnerability scanning.
"""

from __future__ import annotations

import subprocess
import ipaddress
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import monotonic
import xml.etree.ElementTree as ET
from typing import Dict, Iterable, List
from system_settings import (
    SERVICE_SCAN_BATCH_SIZE, SERVICE_SCAN_WORKERS,
    SERVICE_SCAN_HOST_TIMEOUT, SERVICE_SCAN_MAX_RETRIES,
)

# Common infrastructure/application services that are useful to a junior
# network administrator.  UDP-heavy discovery (SNMP/RADIUS) is intentionally
# omitted here because UDP scanning can make Full Scan dramatically slower.
FAST_TCP_PORTS = [
    25, 53, 80, 110, 143, 443, 465, 587, 993, 995, 5000, 8000, 8080, 8443,
]


def _role_for_ports(ports: Iterable[int]) -> str:
    values = set(int(p) for p in ports)
    roles = []
    if values & {80, 443, 5000, 8000, 8080, 8443}:
        roles.append("Web")
    if 53 in values:
        roles.append("DNS")
    if values & {25, 110, 143, 465, 587, 993, 995}:
        roles.append("Mail")
    if values & {1433, 1521, 3306, 5432}:
        roles.append("Database")
    if values & {389, 636}:
        roles.append("Directory / AAA")
    if 9100 in values:
        roles.append("Printer")
    if values & {20, 21}:
        roles.append("FTP")
    if 445 in values:
        roles.append("File Sharing")
    return " + ".join(roles) if roles else "Network Service"


class ServiceResults(dict):
    def __init__(self, *args, errors=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.diagnostics = {"errors": list(errors or [])}


def discover_common_services(ips: Iterable[str], timeout: int = 120, verify: bool = False) -> Dict[str, Dict[str, object]]:
    targets = set()
    for value in ips:
        try:
            address = ipaddress.ip_address(str(value).strip())
        except ValueError:
            continue
        if address.version == 4:
            targets.add(str(address))
    targets = sorted(targets)
    if not targets:
        return ServiceResults()
    deadline = monotonic() + timeout
    batches = [targets[i:i + SERVICE_SCAN_BATCH_SIZE] for i in range(0, len(targets), SERVICE_SCAN_BATCH_SIZE)]
    output = ServiceResults()
    with ThreadPoolExecutor(max_workers=SERVICE_SCAN_WORKERS) as executor:
        futures = [executor.submit(_scan_batch, batch, deadline) for batch in batches]
        for future in as_completed(futures):
            result = future.result()
            output.update(result)
            output.diagnostics["errors"].extend(getattr(result, "diagnostics", {}).get("errors", []))
    output.diagnostics["errors"] = list(dict.fromkeys(output.diagnostics["errors"]))
    output.diagnostics["target_count"] = len(targets)
    if verify and output:
        # Only probe ports already found open. Closed/unreachable targets do
        # not pay for application identification; keep fast results on failure.
        grouped = {}
        for ip, info in output.items():
            ports = tuple(sorted(s["port"] for s in info["services"]))
            grouped.setdefault(ports, []).append(ip)
        with ThreadPoolExecutor(max_workers=SERVICE_SCAN_WORKERS) as executor:
            futures = [executor.submit(_scan_batch, ips[i:i + SERVICE_SCAN_BATCH_SIZE], deadline, ports, True)
                       for ports, ips in grouped.items() for i in range(0, len(ips), SERVICE_SCAN_BATCH_SIZE)]
            for future in as_completed(futures):
                result = future.result()
                output.update(result)
                output.diagnostics["errors"].extend(result.diagnostics["errors"])
    output.diagnostics["errors"] = list(dict.fromkeys(output.diagnostics["errors"]))
    output.diagnostics["mode"] = "light-service-verification" if verify else "port-hints"
    return output


def _scan_batch(targets, deadline, ports=None, verify=False):
    remaining = deadline - monotonic()
    if remaining <= 0:
        return ServiceResults(errors=["Service scan deadline reached; some IPs were not scanned"])

    selected_ports = list(ports or FAST_TCP_PORTS)
    command = [
        # Nmap chooses SYN with raw-packet privileges, connect otherwise.
        "nmap", "-T4", "-Pn", "-n", "--open",
        "--max-retries", str(SERVICE_SCAN_MAX_RETRIES), "--host-timeout", SERVICE_SCAN_HOST_TIMEOUT,
        *(["-sV", "--version-light"] if verify else []),
        "-p", ",".join(str(port) for port in selected_ports),
        "-oX", "-", *targets,
    ]
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=remaining, check=False)
        # Containers or Windows installations may appear privileged but lack
        # raw-packet access/Npcap. Retry connect scan only for that failure.
        error = str(result.stderr or "").lower()
        raw_unavailable = any(token in error for token in (
            "requires root", "operation not permitted", "failed to open device",
            "failed to open interface", "npcap", "winpcap", "permission denied",
        ))
        if result.returncode and raw_unavailable:
            remaining = deadline - monotonic()
            if remaining <= 0:
                return ServiceResults(errors=["Service scan deadline reached before connect fallback"])
            result = subprocess.run([command[0], "-sT", *command[1:]], capture_output=True,
                                    text=True, timeout=remaining, check=False)
    except FileNotFoundError:
        return ServiceResults(errors=["Nmap is not installed or is not in PATH"])
    except subprocess.TimeoutExpired:
        return ServiceResults(errors=["Service scan timed out; results may be incomplete"])
    except OSError:
        return ServiceResults(errors=["Could not start Nmap; check installation and permissions"])
    if result.returncode != 0 or not result.stdout.strip():
        return ServiceResults(errors=["Nmap failed or returned no scan output; check permissions/connectivity"])

    try:
        root = ET.fromstring(result.stdout)
    except ET.ParseError:
        return ServiceResults(errors=["Nmap returned incomplete or invalid XML"])

    output = ServiceResults()
    if any(host.get("timedout") == "true" for host in root.findall("host")):
        output.diagnostics["errors"].append("Some hosts exceeded the service scan timeout")
    for host in root.findall("host"):
        ip = ""
        for address in host.findall("address"):
            if address.get("addrtype") == "ipv4":
                ip = address.get("addr", "")
                break
        if not ip:
            continue

        services: List[Dict[str, object]] = []
        open_ports: List[int] = []
        for port in host.findall("ports/port"):
            state = port.find("state")
            if state is None or state.get("state") != "open":
                continue
            try:
                port_id = int(port.get("portid", "0"))
            except ValueError:
                continue
            if port_id not in selected_ports or port.get("protocol", "tcp") != "tcp":
                continue
            service = port.find("service")
            service_name = service.get("name", "unknown") if service is not None else "unknown"
            services.append({
                "port": port_id,
                "protocol": port.get("protocol", "tcp"),
                "service": service_name,
                "identification": "probe" if service is not None and service.get("method") == "probed" else "port",
                "product": service.get("product", "") if service is not None else "",
                "version": service.get("version", "") if service is not None else "",
            })
            open_ports.append(port_id)

        if services:
            output[ip] = {
                "services": services,
                "service_role": _role_for_services(services),
                "classification_source": "nmap-probe" if any(s["identification"] == "probe" for s in services) else "nmap-port-hint",
            }
    return output


def _role_for_services(services):
    roles = []
    for service in services:
        name = str(service.get("service") or "").lower()
        role = ""
        if service.get("identification") == "probe":
            if "http" in name:
                role = "Web"
            elif name in {"domain", "dns"}:
                role = "DNS"
            elif any(token in name for token in ("smtp", "pop3", "imap")):
                role = "Mail"
        role = role or _role_for_ports([service["port"]])
        roles.extend(role.split(" + "))
    return " + ".join(dict.fromkeys(roles))
