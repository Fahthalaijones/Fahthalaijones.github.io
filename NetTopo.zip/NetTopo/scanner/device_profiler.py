"""Collect a reusable SNMP profile for a network device."""

from typing import Dict
from database.device_catalog import apply_catalog
from database.device_catalog import lookup_device_model
from database.device_catalog import operational_switch_type

from system_settings import MAX_HOSTS_PER_NETWORK, PRIVATE_NETWORKS_ONLY
from scanner.cdp import get_cdp_neighbors
from scanner.lldp import get_lldp_neighbors
from scanner.device import get_device
from scanner.interface import get_interface_map, get_interfaces
from scanner.ip_address import get_interface_ipv4_addresses
from scanner.route_table import get_ipv4_routes
from scanner.fdb import get_mac_port_table
from scanner.snmp import snmp_get
from scanner.vlan import get_switch_vlan_inventory

IP_FORWARDING = "1.3.6.1.2.1.4.1.0"
SYS_SERVICES = "1.3.6.1.2.1.1.7.0"
BRIDGE_NUM_PORTS = "1.3.6.1.2.1.17.1.2.0"


def _has_layer2_evidence(profile):
    try:
        return bool(int(str(profile.get("sys_services") or "0")) & 2) and int(str(profile.get("bridge_num_ports") or "0")) >= 2
    except ValueError:
        return False


def _classify(profile: Dict[str, object]) -> str:
    """Match known hardware first, then use forwarding and platform hints.

    Explicit switch platform text wins first (important for IOSvL2/IOL L2).
    Otherwise IP forwarding identifies routers.  Non-forwarding multi-port
    network devices are treated as switches.  This avoids BRIDGE-MIB probes
    turning Cisco routers into switches and removes two SNMP GETs per device.
    """
    match = lookup_device_model(profile)
    if match:
        return operational_switch_type(profile) if match["device_type"] == "layer3_switch" else match["device_type"]
    description = str(profile.get("description") or "").lower()
    object_id = str(profile.get("object_id") or "")
    forwarding = str(profile.get("ip_forwarding") or "").strip()
    interfaces = profile.get("interfaces") or {}

    switch_tokens = (
        "iosvl2", "linux_l2", "i86bi_linuxl2", "ethernet switch", "layer 2 switch",
        "layer2 switch", "catalyst", "switch software",
    )
    # Current lab Catalyst 3650 product OID.  Keep the decision cheap: this is
    # data already returned by sysObjectID, not another probe.
    known_switch_oid = any(token in object_id for token in ("9.1.1824",))
    if known_switch_oid or any(token in description for token in switch_tokens):
        return operational_switch_type(profile)
    # An embedded Linux OS is not endpoint evidence when the agent explicitly
    # reports layer-2 service and multiple bridge ports. Conversely, a server
    # with several NICs alone does not satisfy this evidence.
    if _has_layer2_evidence(profile):
        return operational_switch_type(profile)
    from scanner.neighbor_kind import neighbor_kind
    if neighbor_kind({"description": description}) == "endpoint":
        return "end_device"
    if forwarding == "1":
        return "router"
    if len(interfaces) >= 2:
        return "switch"
    return "network_device"


def build_device_profile(ip: str, community: str, scan_level: str = "full", neighbor_only=False) -> Dict[str, object]:
    basic = get_device(ip, community)
    interfaces = get_interface_map(ip, community)
    interface_details = get_interfaces(ip, community)
    addresses = get_interface_ipv4_addresses(ip, community)

    addresses_by_index = {}
    for row in addresses:
        addresses_by_index.setdefault(str(row.get("ifindex") or ""), []).append({
            "ip": row.get("ip") or "",
            "netmask": row.get("netmask") or "",
        })
    for ifindex, detail in interface_details.items():
        detail["ifindex"] = str(ifindex)
        detail["ip_addresses"] = addresses_by_index.get(str(ifindex), [])
        name = str(detail.get("name") or "")
        detail["interface_kind"] = "SVI" if name.lower().startswith("vlan") else "Physical/Logical"

    try:
        cdp_neighbors = get_cdp_neighbors(ip, community)
    except Exception:
        cdp_neighbors = []
    try:
        lldp_neighbors = get_lldp_neighbors(ip, community)
    except Exception:
        lldp_neighbors = []

    forwarding = snmp_get(ip, IP_FORWARDING, community) or ""
    profile: Dict[str, object] = {
        **basic,
        "query_ip": ip,
        "interfaces": interfaces,
        "interface_details": interface_details,
        "ip_addresses": addresses,
        "ip_forwarding": forwarding,
        "cdp_neighbors": cdp_neighbors,
        "lldp_neighbors": lldp_neighbors,
        "route_networks": [],
    }
    profile["device_type"] = _classify(profile)
    if profile["device_type"] in {"router", "layer3_switch", "network_device"}:
        from scanner.nat import enrich_nat_interfaces
        enrich_nat_interfaces(ip, community, interface_details)
    if profile["device_type"] in {"end_device", "network_device"}:
        profile["sys_services"] = snmp_get(ip, SYS_SERVICES, community) or ""
        try:
            layer2 = bool(int(str(profile["sys_services"] or "0")) & 2)
        except ValueError:
            layer2 = False
        if layer2:
            profile["bridge_num_ports"] = snmp_get(ip, BRIDGE_NUM_PORTS, community) or ""
            profile["device_type"] = _classify(profile)
            if _has_layer2_evidence(profile):
                profile["classification_source"] = "SNMP sysServices + BRIDGE-MIB ports"
    apply_catalog(profile)

    # Enrich Layer-2 switch interfaces with VLAN inventory. This works on
    # Cisco IOSvL2 images that expose CISCO-VTP-MIB and
    # CISCO-VLAN-MEMBERSHIP-MIB even when Q-BRIDGE-MIB is unavailable.
    profile["vlan_database"] = {}
    profile["access_method"] = "SNMP"
    vlan_inventory = None
    if profile["device_type"] in {"switch", "layer3_switch"} and scan_level != "topology":
        try:
            vlan_inventory = get_switch_vlan_inventory(ip, community)
        except Exception:
            vlan_inventory = None

        vlan_database = (vlan_inventory or {}).get("vlans") or {}
        access_vlans = (vlan_inventory or {}).get("access_vlan_by_ifindex") or {}
        trunk_status = (vlan_inventory or {}).get("trunk_by_ifindex") or {}
        profile["vlan_database"] = [
            {"vlan_id": vlan_id, "name": vlan_database[vlan_id]}
            for vlan_id in sorted(vlan_database)
        ]

        for ifindex, detail in interface_details.items():
            vlan_id = access_vlans.get(str(ifindex))
            is_trunk = trunk_status.get(str(ifindex))
            if is_trunk is True:
                detail["switchport_mode"] = "trunk"
                detail["access_vlan"] = None
            elif vlan_id is not None:
                detail["switchport_mode"] = "access"
                detail["access_vlan"] = vlan_id
                detail["access_vlan_name"] = vlan_database.get(vlan_id, "VLAN{}".format(vlan_id))
            elif is_trunk is False:
                detail["switchport_mode"] = "not-trunking"
            else:
                detail["switchport_mode"] = "unknown"

    # Read routes only from Layer-3 forwarding devices. These routes expand
    # scan scope but never create topology links by themselves.
    if scan_level == "full" and not neighbor_only and (profile["device_type"] == "router" or (profile["device_type"] == "layer3_switch" and str(forwarding) == "1")):
        profile["route_networks"] = get_ipv4_routes(
            ip,
            community=community,
            private_only=PRIVATE_NETWORKS_ONLY,
            max_hosts=MAX_HOSTS_PER_NETWORK,
        )

    # Collect FDB in the device worker, while its SNMP session is still open.
    # Reuse this round's interface/VLAN inventory rather than reading it again
    # sequentially during graph building. Never do this for hop-only scans.
    if scan_level == "full" and not neighbor_only and profile["device_type"] in {"switch", "layer3_switch"}:
        try:
            profile["_fdb_scan_cache"] = get_mac_port_table(
                ip, community=community, interfaces=interfaces,
                access_vlans=(vlan_inventory or {}).get("access_vlan_by_ifindex"),
                vlan_names=(vlan_inventory or {}).get("vlans"),
            )
        except Exception:
            # Allow the graph stage to retry a failed collection.
            pass

    return profile
