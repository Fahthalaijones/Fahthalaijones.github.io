"""Small SNMP helper functions used by the discovery modules."""

from typing import List, Optional, Tuple
from contextlib import contextmanager
from contextvars import ContextVar

from pysnmp.hlapi import (
    CommunityData,
    ContextData,
    ObjectIdentity,
    ObjectType,
    SnmpEngine,
    UdpTransportTarget,
    getCmd,
    nextCmd,
    bulkCmd,
)
from pysnmp.proto.rfc1902 import OctetString

from system_settings import SNMP_PORT, SNMP_RETRIES, SNMP_TIMEOUT, SNMP_BULK_REPETITIONS

SnmpRow = Tuple[str, str]
_session = ContextVar("snmp_collection_session", default=None)


@contextmanager
def snmp_session(retries=None):
    """Cache duplicate OID reads only during one device collection."""
    session = {"retries": SNMP_RETRIES if retries is None else retries, "cache": {}, "engine": None}
    token = _session.set(session)
    try:
        yield
    finally:
        try:
            engine = session["engine"]
            if engine is not None and getattr(engine, "transportDispatcher", None) is not None:
                engine.transportDispatcher.closeDispatcher()
        finally:
            _session.reset(token)


def _engine():
    session = _session.get()
    if session is None:
        return SnmpEngine()
    if session["engine"] is None:
        session["engine"] = SnmpEngine()
    return session["engine"]


def _transport(ip):
    session = _session.get()
    return UdpTransportTarget((ip, SNMP_PORT), timeout=SNMP_TIMEOUT,
                              retries=session["retries"] if session is not None else SNMP_RETRIES)


def _format_snmp_value(value) -> str:
    """Convert SNMP values without destroying binary MAC/mask octets."""
    if isinstance(value, OctetString):
        raw = bytes(value.asOctets())

        # LLDP Port ID and interface names are OCTET STRINGs too.  A very
        # important RouterOS example is ``ether1``: it is exactly six bytes.
        # Treat printable text as text *before* applying the six-byte MAC rule;
        # otherwise ether1 became 65:74:68:65:72:31 and topology interfaces
        # were displayed incorrectly.
        try:
            decoded = raw.decode("utf-8").strip("\x00").strip()
        except UnicodeDecodeError:
            decoded = ""
        if decoded and all(ch.isprintable() for ch in decoded):
            return decoded

        # Binary MAC address stored as six octets.
        if len(raw) == 6:
            return ":".join(f"{byte:02X}" for byte in raw)

        # IPv4 address/netmask stored as four binary octets.
        if len(raw) == 4:
            return ".".join(str(byte) for byte in raw)

        return "0x" + raw.hex().upper()

    # Integer, Gauge, Counter, IpAddress and other normal SNMP types.
    try:
        return value.prettyPrint().strip('"')
    except Exception:
        return str(value).strip('"')


def snmp_get(ip: str, oid: str, community: str = "public") -> Optional[str]:
    """Read one SNMP OID. Return None when the device does not answer."""
    session = _session.get()
    key = ("get", ip, community, oid)
    if session is not None and key in session["cache"]:
        return session["cache"][key]
    try:
        iterator = getCmd(
            _engine(),
            CommunityData(community, mpModel=1),
            _transport(ip),
            ContextData(),
            ObjectType(ObjectIdentity(oid)),
        )

        error_indication, error_status, _, var_binds = next(iterator)
        if error_indication or error_status or not var_binds:
            if session is not None:
                session["cache"][key] = None
            return None

        value = _format_snmp_value(var_binds[0][1])
        if session is not None:
            session["cache"][key] = value
        return value

    except Exception:
        return None


def snmp_walk(ip: str, oid: str, community: str = "public") -> List[SnmpRow]:
    """Walk an SNMP subtree and return [(full_oid, formatted_value), ...]."""
    rows: List[SnmpRow] = []
    session = _session.get()
    key = ("walk", ip, community, oid)
    if session is not None and key in session["cache"]:
        return list(session["cache"][key])
    complete = True

    try:
        def walk(bulk):
            args = (_engine(), CommunityData(community, mpModel=1), _transport(ip), ContextData())
            if bulk:
                return bulkCmd(*args, 0, SNMP_BULK_REPETITIONS,
                               ObjectType(ObjectIdentity(oid)), lexicographicMode=False)
            return nextCmd(*args, ObjectType(ObjectIdentity(oid)), lexicographicMode=False)

        # GETBULK reduces round trips for large interface/neighbor tables.
        # Fall back to GETNEXT for agents that reject bulk requests.
        iterator = walk(True)

        for bulk in (True, False):
            if not bulk:
                iterator = walk(False)
            complete = True
            fallback_allowed = False
            for error_indication, error_status, _, var_binds in iterator:
                if error_indication or error_status:
                    complete = False
                    fallback_allowed = bool(error_status) and not error_indication
                    break
                for var_bind in var_binds:
                    rows.append((str(var_bind[0]), _format_snmp_value(var_bind[1])))
            if complete or rows or not fallback_allowed:
                break

    except Exception:
        return []

    if session is not None and complete:
        session["cache"][key] = list(rows)
    return rows
