"""Interface MIB helpers."""

from typing import Dict

from scanner.snmp import snmp_walk

IF_DESCR = "1.3.6.1.2.1.2.2.1.2"
IF_NAME = "1.3.6.1.2.1.31.1.1.1.1"
IF_TYPE = "1.3.6.1.2.1.2.2.1.3"
IF_ADMIN_STATUS = "1.3.6.1.2.1.2.2.1.7"
IF_OPER_STATUS = "1.3.6.1.2.1.2.2.1.8"
IF_ALIAS = "1.3.6.1.2.1.31.1.1.1.18"
IF_PHYS_ADDRESS = "1.3.6.1.2.1.2.2.1.6"


def _walk_to_index_map(ip: str, oid: str, community: str) -> Dict[str, str]:
    result: Dict[str, str] = {}
    for full_oid, value in snmp_walk(ip, oid, community):
        result[full_oid.split(".")[-1]] = value
    return result


def get_interface_map(ip: str, community: str = "public") -> Dict[str, str]:
    """Return {ifIndex: interface_name}. Prefer ifName, fallback to ifDescr."""
    descriptions = _walk_to_index_map(ip, IF_DESCR, community)
    names = _walk_to_index_map(ip, IF_NAME, community)

    all_indexes = set(descriptions) | set(names)
    return {
        index: names.get(index) or descriptions.get(index) or f"ifIndex {index}"
        for index in all_indexes
    }


def get_interfaces(ip: str, community: str = "public") -> Dict[str, dict]:
    """Return detailed interface records keyed by ifIndex."""
    interface_map = get_interface_map(ip, community)
    types = _walk_to_index_map(ip, IF_TYPE, community)
    admin_statuses = _walk_to_index_map(ip, IF_ADMIN_STATUS, community)
    statuses = _walk_to_index_map(ip, IF_OPER_STATUS, community)
    aliases = _walk_to_index_map(ip, IF_ALIAS, community)
    mac_addresses = _walk_to_index_map(ip, IF_PHYS_ADDRESS, community)

    status_names = {
        "1": "up",
        "2": "down",
        "3": "testing",
        "4": "unknown",
        "5": "dormant",
        "6": "notPresent",
        "7": "lowerLayerDown",
    }

    return {
        index: {
            "name": name,
            "admin_status": status_names.get(admin_statuses.get(index, ""), "unknown"),
            "status": status_names.get(statuses.get(index, ""), "unknown"),
            "type": types.get(index, ""),
            "alias": aliases.get(index, ""),
            "mac": mac_addresses.get(index, ""),
        }
        for index, name in interface_map.items()
    }
