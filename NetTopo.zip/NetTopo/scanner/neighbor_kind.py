"""Conservative neighbor hints: endpoint OS names are not SNMP hop requests."""
import re


def _cdp_network_capability(value):
    """CDP uses a four-octet bitmap: router/bridge/switch/repeater win over OS."""
    text = str(value or "").strip()
    try:
        if re.fullmatch(r"\d+", text):
            bits = int(text)
        elif re.fullmatch(r"(?:\d{1,3}\.){3}\d{1,3}", text):
            bits = int.from_bytes(bytes(int(part) for part in text.split(".")), "big")
        else:
            compact = re.sub(r"[\s:-]", "", re.sub(r"^0x", "", text, flags=re.I))
            bits = int(compact, 16) if len(compact) == 8 and re.fullmatch(r"[0-9a-fA-F]+", compact) else 0
        if bits & 0x4F:
            return True
    except ValueError:
        pass
    # SSH 'show cdp neighbors detail' prints names instead of a bitmap.
    return bool(re.search(r"\b(?:router|switch|bridge|repeater)\b", text, re.I))


def neighbor_kind(row):
    if str(row.get("protocol") or "CDP").upper() == "CDP" and _cdp_network_capability(row.get("capabilities")):
        return "network"
    text = str(row.get("platform") or row.get("description") or "").lower()
    if re.search(r"routeros|mikrotik|catalyst|cisco\s+ios|\b(?:router|switch|firewall)\b|\b(?:ws-)?c(?:3560|3650|3750|3850|9300|9500)", text):
        return "network"
    if re.search(r"iosvl2|i86bi_linuxl2|linux_l2", text):
        return "network"
    # IOL/IOU CDP advertises 'Linux Unix'. Older/limited agents may omit
    # capabilities; retain an uncertain hop rather than silently hiding it.
    if str(row.get("protocol") or "").upper() == "CDP" and re.fullmatch(r"linux\s+uni(?:x)?", text.strip()):
        return "unknown"
    if re.search(r"\b(?:linux|ubuntu|debian|windows|vmware|esxi|server|printer)\b", text):
        return "endpoint"
    return "unknown"
