# V3.1 Hybrid Recursive Discovery

This version requires only one configured SNMP seed device:

```python
ROOT_DEVICE_IP = "192.168.56.125"
```

The scanner then:

1. Reads R1 System MIB, Interface MIB, IP-MIB and CDP.
2. Extracts connected networks such as `192.168.10.0/24` and `192.168.0.0/30`.
3. Adds temporary Linux routes through R1 when enabled.
4. Uses Nmap host discovery on each discovered network.
5. Probes SNMP hosts and recursively profiles R2 and managed switches.
6. Reads R2 interfaces and discovers LANs behind R2, such as `192.168.20.0/24`.
7. Builds CDP links and ARP+FDB end-device links.
8. Infers an unmanaged switch when multiple MAC addresses are learned on one managed-switch port.

## Lab routing requirements

R1 must know the route to every network behind R2. Example:

```cisco
R1(config)# ip route 192.168.20.0 255.255.255.0 192.168.0.2
```

R2 must have a return route to the management network:

```cisco
R2(config)# ip route 192.168.56.0 255.255.255.0 192.168.0.1
```

The application can add Linux routes through R1 automatically. Run it as root:

```bash
sudo -E venv/bin/python3 test_recursive_discovery.py
sudo -E venv/bin/python3 app.py
```

Disable route changes with:

```python
AUTO_ADD_DISCOVERED_ROUTES = False
```

Then add routes manually on Ubuntu.

## Verify before testing

```bash
snmpget -v2c -c public 192.168.56.125 1.3.6.1.2.1.1.5.0
ping -c 2 192.168.0.2
ping -c 2 192.168.20.1
```

On routers and switches, generate ARP/FDB entries by pinging gateways from VPCS before scanning.
