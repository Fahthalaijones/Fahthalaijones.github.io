"""Compatibility wrapper for the recursive graph builder."""

from topology.recursive_graph_builder import build_recursive_topology

__all__ = ["build_recursive_topology"]
