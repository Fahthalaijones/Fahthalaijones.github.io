import ipaddress
from typing import Iterable, Optional

from scanner.arp import get_arp_table
from scanner.fdb import get_mac_port_table


def normalize_mac(mac: str) -> str:
    if not mac:
        return ""

    clean = (
        str(mac)
        .strip()
        .replace(":", "")
        .replace("-", "")
        .replace(".", "")
        .replace(" ", "")
        .upper()
    )

    if len(clean) != 12:
        return ""

    return ":".join(clean[index:index + 2] for index in range(0, 12, 2))


def normalize_interface_name(interface_name: str) -> str:
    if not interface_name:
        return ""

    name = str(interface_name).strip().lower().replace(" ", "")
    replacements = [
        ("tengigabitethernet", "te"),
        ("gigabitethernet", "gi"),
        ("fastethernet", "fa"),
        ("ethernet", "et"),
        ("port-channel", "po"),
        ("portchannel", "po"),
    ]

    for full_name, short_name in replacements:
        if name.startswith(full_name):
            return short_name + name[len(full_name):]

    return name


def _is_in_network(ip_value: str, network: Optional[str]) -> bool:
    if not network:
        return True
    try:
        return ipaddress.ip_address(ip_value) in ipaddress.ip_network(network, strict=False)
    except ValueError:
        return False


def map_end_devices(
    router_ip: str,
    switch_ip: str,
    community: str = "public",
    excluded_ips: Optional[Iterable[str]] = None,
    excluded_interfaces: Optional[Iterable[str]] = None,
    target_network: Optional[str] = None,
):
    excluded_ip_set = {
        str(ip).strip()
        for ip in (excluded_ips or [])
        if ip
    }
    excluded_interface_set = {
        normalize_interface_name(interface_name)
        for interface_name in (excluded_interfaces or [])
        if interface_name
    }

    arp_entries = get_arp_table(router_ip, community=community)
    fdb_entries = get_mac_port_table(switch_ip, community=community)

    fdb_by_mac = {}
    for fdb_entry in fdb_entries:
        mac = normalize_mac(fdb_entry.get("mac", ""))
        if mac:
            fdb_by_mac.setdefault(mac, []).append(fdb_entry)

    end_devices = []
    seen_devices = set()

    for arp_entry in arp_entries:
        device_ip = str(arp_entry.get("ip", "")).strip()
        device_mac = normalize_mac(arp_entry.get("mac", ""))

        if not device_ip or not device_mac:
            continue
        if device_ip in excluded_ip_set:
            continue
        if not _is_in_network(device_ip, target_network):
            continue

        for fdb_entry in fdb_by_mac.get(device_mac, []):
            interface_name = str(fdb_entry.get("interface", "Unknown")).strip()
            normalized_interface = normalize_interface_name(interface_name)

            if normalized_interface in excluded_interface_set:
                continue

            unique_key = (device_ip, device_mac, switch_ip, normalized_interface)
            if unique_key in seen_devices:
                continue
            seen_devices.add(unique_key)

            end_devices.append({
                "ip": device_ip,
                "mac": device_mac,
                "router_ifindex": arp_entry.get("ifindex", ""),
                "switch_ip": switch_ip,
                "interface": interface_name,
                "ifindex": fdb_entry.get("ifindex", ""),
                "bridge_port": fdb_entry.get("bridge_port", ""),
                "confidence": "high",
                "confidence_percent": 95,
                "evidence": "Router ARP + Switch FDB",
            })

    return end_devices
