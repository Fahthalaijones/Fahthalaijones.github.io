"""Separate unknown locations and label evidence-based L2 hypotheses."""
NETWORK_TYPES = {'router', 'switch', 'layer3_switch', 'network_device'}
ENDPOINT_TYPES = {'end_device', 'server', 'printer'}
INFERRED_TYPES = {'unmanaged_switch', 'inferred_trunk_switch'}


def network_ips(nodes):
    ips = set()
    for node in nodes:
        if node.get('device_type') not in NETWORK_TYPES:
            continue
        ips.update(str(ip) for ip in [node.get('ip'), node.get('management_ip'), *(node.get('management_ips') or [])] if ip)
        for interface in node.get('interfaces') or []:
            if isinstance(interface, dict):
                ips.update(str(row['ip']) for row in interface.get('ip_addresses') or [] if row.get('ip'))
    return ips


def physical_topology(nodes, edges, reserved_ips=()):
    reserved = network_ips(nodes) | set(reserved_ips)
    removed = {str(n['id']) for n in nodes if (n.get('device_type') in INFERRED_TYPES and n.get('inference_basis') != 'multiple-macs-one-physical-port')
               or (n.get('device_type') in ENDPOINT_TYPES and str(n.get('ip') or n.get('management_ip')) in reserved)}
    uncertain = {str(n['id']) for n in nodes if n.get('device_type') in ENDPOINT_TYPES and n.get('port_known') is False}
    ids = {str(n['id']) for n in nodes} - removed - uncertain
    valid_edges = [e for e in edges if str(e.get('from')) in ids and str(e.get('to')) in ids]
    connected = {str(e[k]) for e in valid_edges for k in ('from', 'to')}
    unlocated, visible = [], []
    for node in nodes:
        node_id = str(node['id'])
        if node_id in removed:
            continue
        if node.get('device_type') in ENDPOINT_TYPES and (node_id in uncertain or node_id not in connected):
            unlocated.append(dict(node, port_known=False, connection_status='ยังไม่พบหลักฐานพอร์ตเชื่อมต่อ'))
        else:
            visible.append(node)
    visible_ids = {str(n['id']) for n in visible}
    return visible, [e for e in valid_edges if str(e['from']) in visible_ids and str(e['to']) in visible_ids], unlocated
