"""Stable device identity helpers for the GNS3 topology prototype.

Identity rules are deliberately different for routers and switches:

* A router can answer SNMP on several interface addresses.  Those addresses
  must resolve to one logical device, so routers use their SNMP hostname as
  the primary identity.
* Cloned IOSvL2 switches can share sysObjectID and bridge MAC.  Switches must
  therefore use their management/query IP as the primary identity.
"""

from typing import Dict, Iterable, Optional


def clean_ip(value: object) -> str:
    return str(value or "").strip()


def primary_management_ip(profile: Dict[str, object]) -> str:
    for key in ("management_ip", "query_ip", "ip"):
        value = clean_ip(profile.get(key))
        if value:
            return value

    for value in profile.get("management_ips") or []:
        value = clean_ip(value)
        if value:
            return value

    for row in profile.get("ip_addresses") or []:
        value = clean_ip(row.get("ip"))
        if value:
            return value
    return ""


def make_device_identity(profile: Dict[str, object], fallback: Optional[str] = None) -> str:
    """Return one logical identity for a discovered network device.

    Router:
      hostname first, because one router owns several routed interface IPs.

    Switch:
      management/query IP first, because cloned GNS3 switches may have the
      same model, sysObjectID and bridge MAC.
    """
    device_type = str(profile.get("device_type") or "").strip().lower()
    hostname = str(profile.get("hostname") or "").strip().lower()
    management_ip = primary_management_ip(profile)
    bridge = str(profile.get("bridge_address") or "").strip().lower()
    object_id = str(profile.get("object_id") or "").strip().lower()

    if device_type == "router" and hostname:
        return "router-name:{}".format(hostname)

    if management_ip:
        return "ip:{}".format(management_ip)

    if hostname and bridge:
        return "name-bridge:{}:{}".format(hostname, bridge)
    if hostname and object_id:
        return "name-object:{}:{}".format(hostname, object_id)
    if hostname:
        return "name:{}".format(hostname)
    return "unknown:{}".format(fallback or id(profile))


def all_profile_ips(profile: Dict[str, object]) -> Iterable[str]:
    seen = set()
    for key in ("management_ip", "query_ip", "ip"):
        value = clean_ip(profile.get(key))
        if value and value not in seen:
            seen.add(value)
            yield value
    for value in profile.get("management_ips") or []:
        value = clean_ip(value)
        if value and value not in seen:
            seen.add(value)
            yield value
    for row in profile.get("ip_addresses") or []:
        value = clean_ip(row.get("ip"))
        if value and value not in seen:
            seen.add(value)
            yield value
