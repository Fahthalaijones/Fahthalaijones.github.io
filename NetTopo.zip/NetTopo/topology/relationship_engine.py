"""Evidence-only relationship engine for V4.

Rules:
- Interface networks and route tables expand scan scope only.
- Network-device edges come only from CDP/LLDP observations.
- End-device edges come only from Router ARP + Switch FDB correlation.
- One-sided CDP needs a known management IP or a RouterOS interoperability match.
"""

from collections import defaultdict
from typing import Dict, Iterable, List, Optional, Set, Tuple

from scanner.arp import get_arp_table
from scanner.fdb import get_mac_port_table
from scanner.snmp import snmp_session
from topology.end_device_mapper import normalize_interface_name, normalize_mac


def profile_ips(profile: Dict[str, object]) -> Set[str]:
    values: Set[str] = set()
    for value in profile.get("management_ips") or []:
        if value:
            values.add(str(value))
    if profile.get("query_ip"):
        values.add(str(profile["query_ip"]))
    for row in profile.get("ip_addresses") or []:
        if row.get("ip"):
            values.add(str(row["ip"]))
    return values


def build_profile_ip_index(profiles):
    """A successful query address outranks another device's secondary alias."""
    owners, primary = defaultdict(set), defaultdict(set)
    for identity, profile in profiles.items():
        for ip in profile_ips(profile):
            owners[ip].add(identity)
        query = str(profile.get("query_ip") or profile.get("ip") or "")
        if query:
            primary[query].add(identity)
    index, ambiguous = {}, set()
    for ip, identities in owners.items():
        strongest = primary.get(ip) or identities
        if len(strongest) == 1:
            index[ip] = next(iter(strongest))
        else:
            ambiguous.add(ip)
    return index, ambiguous


def _hostname_key(value: object) -> str:
    """Normalize LLDP/CDP system names without assuming a DNS suffix."""
    text = str(value or "").strip().lower().rstrip(".")
    if text in {"unknown", "unknown neighbor", "router", "switch", "localhost", "device"}:
        return ""
    import ipaddress
    try:
        return str(ipaddress.ip_address(text))
    except ValueError:
        pass
    return text.split(".", 1)[0] if text else ""


def _profile_macs(profile: Dict[str, object]) -> Set[str]:
    values: Set[str] = set()
    bridge = normalize_mac(str(profile.get("bridge_address") or ""))
    if bridge:
        values.add(bridge)
    details = profile.get("interface_details") or {}
    if isinstance(details, dict):
        rows = details.values()
    else:
        rows = details
    for row in rows:
        if not isinstance(row, dict):
            continue
        mac = normalize_mac(str(row.get("mac") or ""))
        if mac:
            values.add(mac)
    return values


def find_neighbor_identity(
    profiles: Dict[str, Dict[str, object]],
    ip_index: Dict[str, str],
    neighbor: Dict[str, object],
) -> Optional[str]:
    # 1) LLDP management address is the strongest and simplest match.
    management_ip = str(neighbor.get("management_ip") or "").strip()
    if management_ip and management_ip in ip_index:
        return ip_index[management_ip]

    # 2) RouterOS/Cisco may omit lldpRemManAddr.  LLDP chassis ID is commonly
    #    an interface/bridge MAC, so use it as a vendor-neutral fallback.
    chassis = normalize_mac(str(neighbor.get("chassis") or ""))
    if chassis:
        mac_matches = [
            identity for identity, profile in profiles.items()
            if chassis in _profile_macs(profile)
        ]
        if len(mac_matches) == 1:
            return mac_matches[0]

    # 3) System Name can be short on one vendor and FQDN on another.
    remote_name = _hostname_key(neighbor.get("remote_device"))
    if not remote_name:
        return None
    matches = [
        identity
        for identity, profile in profiles.items()
        if _hostname_key(profile.get("hostname")) == remote_name
    ]
    return matches[0] if len(matches) == 1 else None


def build_cdp_observations(
    profiles: Dict[str, Dict[str, object]],
    ip_index: Dict[str, str],
) -> List[Dict[str, object]]:
    observations: List[Dict[str, object]] = []
    for source_identity, profile in profiles.items():
        neighbors = list(profile.get("cdp_neighbors") or []) + list(profile.get("lldp_neighbors") or [])
        for neighbor in neighbors:
            target_identity = find_neighbor_identity(profiles, ip_index, neighbor)
            if not target_identity or target_identity == source_identity:
                continue
            observations.append({
                "source_identity": source_identity,
                "target_identity": target_identity,
                # SNMP collectors use local_port/remote_port, while the SSH
                # parser uses local_interface/remote_interface.  Normalize both
                # here so a Cisco<->RouterOS link never loses its real ports.
                "local_interface": str(neighbor.get("local_port") or neighbor.get("local_interface") or "Unknown"),
                "remote_interface": str(neighbor.get("remote_port") or neighbor.get("remote_interface") or "Unknown"),
                "protocol": str(neighbor.get("protocol") or "neighbor").lower(),
            })
    return observations


def _port_quality(value: object) -> int:
    text = str(value or "").strip()
    if not text or text.lower() in {"unknown", "none", "0", "-", "n/a"}:
        return 0
    if text.lower().startswith("lldp port ") or text.lower().startswith("ifindex "):
        return 1
    if text.isdigit() or (len(text.replace(":", "").replace("-", "").replace(".", "")) == 12
                          and all(ch in "0123456789abcdefABCDEF:.-" for ch in text)):
        return 1
    # Normal interface names (Gi0/0, Et0/1, ether1, bridge1, etc.)
    return 3


def _observation_quality(row: Dict[str, object]) -> Tuple[int, int, int]:
    # Prefer rows that know both endpoints' interfaces.  LLDP wins a tie because
    # it is the vendor-neutral evidence used by both Cisco and RouterOS.
    protocol = str(row.get("protocol") or "").lower()
    return (
        _port_quality(row.get("local_interface")) + _port_quality(row.get("remote_interface")),
        _port_quality(row.get("local_interface")),
        1 if protocol == "lldp" else 0,
    )


def _best_observation(rows: List[Dict[str, object]]) -> Optional[Dict[str, object]]:
    return max(rows, key=_observation_quality) if rows else None


def select_consistent_links(links):
    """Keep strongest cable evidence; leave equal conflicting claims unresolved."""
    def endpoint(identity, interface):
        name = normalize_interface_name(str(interface or ""))
        if _port_quality(interface) < 3 or name.startswith(("bridge", "vlan", "po", "loopback", "lo")):
            return None
        return str(identity), name

    def rank(link):
        return (str(link.get("evidence", "")).startswith("reciprocal-"),
                sum(_port_quality(link.get(k)) >= 3 for k in ("local_interface", "remote_interface")),
                # A protocol preference cannot resolve two contradictory
                # one-sided claims about the same physical port.
                int(link.get("confidence") or 0) if str(link.get("evidence", "")).startswith("reciprocal-") else 0)

    claims = defaultdict(list)
    endpoints = []
    for index, link in enumerate(links):
        pair = (endpoint(link["source_identity"], link.get("local_interface")),
                endpoint(link["target_identity"], link.get("remote_interface")))
        endpoints.append(pair)
        for own, peer, peer_identity in ((pair[0], pair[1], link["target_identity"]),
                                         (pair[1], pair[0], link["source_identity"])):
            if own:
                claims[own].append((index, (str(peer_identity), peer), rank(link)))
    rejected = set()
    for rows in claims.values():
        strongest = max(row[2] for row in rows)
        winners = [row for row in rows if row[2] == strongest]
        if len({row[1] for row in winners}) > 1:
            rejected.update(row[0] for row in rows)
        else:
            winner = winners[0][1]
            rejected.update(row[0] for row in rows if row[1] != winner)
    return [link for index, link in enumerate(links) if index not in rejected]


def build_validated_cdp_links(
    profiles: Dict[str, Dict[str, object]],
    ip_index: Dict[str, str],
    require_reciprocal: bool = True,
    root_identity: Optional[str] = None,
) -> List[Dict[str, object]]:
    """Build physical links from CDP/LLDP evidence.

    For a reciprocal link, each endpoint's *local* interface is authoritative.
    This matters for Cisco <-> MikroTik: Cisco may report remote Port ID ether1,
    while RouterOS independently reports its local ether1.  We therefore never
    derive the MikroTik endpoint from a Cisco ifIndex.

    CDP permits one-sided evidence with a resolved management IP. LLDP may be accepted one-sided when the
    remote endpoint is already a discovered device, because some RouterOS/SNMP
    combinations omit parts of lldpRemTable even though the peer advertises LLDP.
    """
    observations = build_cdp_observations(profiles, ip_index)
    directed: Dict[Tuple[str, str], List[Dict[str, object]]] = defaultdict(list)
    for row in observations:
        directed[(str(row["source_identity"]), str(row["target_identity"]))].append(row)

    links: List[Dict[str, object]] = []
    seen = set()

    def port(value):
        return normalize_interface_name(str(value or "")) if _port_quality(value) >= 3 else ""

    for source, target in sorted(directed):
        forward_rows = directed[(source, target)]
        reverse_rows = directed.get((target, source), [])
        for forward in sorted(forward_rows, key=_observation_quality, reverse=True):
            local = port(forward.get("local_interface"))
            remote = port(forward.get("remote_interface"))
            # Match the same physical cable, not merely the same device pair.
            compatible = [row for row in reverse_rows
                          if not (local and port(row.get("remote_interface")) and local != port(row.get("remote_interface")))
                          and not (remote and port(row.get("local_interface")) and remote != port(row.get("local_interface")))]
            reverse = _best_observation(compatible) if len({(port(r.get("local_interface")), port(r.get("remote_interface"))) for r in compatible}) <= 1 else None
            protocol = str(forward.get("protocol") or "neighbor").lower()
            protocols = {protocol}
            if reverse:
                protocols.add(str(reverse.get("protocol") or "neighbor").lower())
            if reverse is None and require_reciprocal and protocol != "lldp":
                # An advertised management address resolving uniquely to a
                # collected device is sufficient for one-sided CDP evidence.
                neighbors = list(profiles[source].get("cdp_neighbors") or []) + list(profiles[source].get("lldp_neighbors") or [])
                verified = any(ip_index.get(str(n.get("management_ip") or "")) == target
                               and port(n.get("local_port") or n.get("local_interface")) == local
                               and port(n.get("remote_port") or n.get("remote_interface")) == remote for n in neighbors)
                desc = str(profiles[source].get("description", "")) + str(profiles[target].get("description", ""))
                if not verified and not any(t in desc.lower() for t in ("mikrotik", "routeros")):
                    continue
            local_interface = str(forward.get("local_interface") or "Unknown")
            remote_interface = str(forward.get("remote_interface") or "Unknown")
            if reverse and _port_quality(reverse.get("local_interface")) > 1:
                remote_interface = str(reverse["local_interface"])
            key = tuple(sorted(((source, port(local_interface)), (target, port(remote_interface)))))
            relation = "cdp_lldp" if len(protocols) > 1 else next(iter(protocols))
            if key in seen:
                existing = next(link for link in links if link["_key"] == key)
                merged = set(existing["protocol"].lower().split(" + ")) | protocols
                existing["protocol"] = " + ".join(p.upper() for p in sorted(merged))
                existing["relation"] = "cdp_lldp" if len(merged) > 1 else next(iter(merged))
                continue
            seen.add(key)
            links.append({
                "_key": key, "source_identity": source, "target_identity": target,
                "local_interface": local_interface, "remote_interface": remote_interface,
                "relation": relation, "protocol": " + ".join(p.upper() for p in sorted(protocols)),
                "evidence": ("reciprocal-" if reverse else "verified-one-sided-") + "+".join(sorted(protocols)),
                "confidence": 100 if reverse else (90 if protocol == "lldp" else 85),
            })
    for link in links:
        link.pop("_key", None)

    return select_consistent_links(links)


def cdp_ports_by_device(links: Iterable[Dict[str, object]]) -> Dict[str, Set[str]]:
    result: Dict[str, Set[str]] = defaultdict(set)
    for link in links:
        a = str(link["source_identity"])
        b = str(link["target_identity"])
        result[a].add(normalize_interface_name(str(link.get("local_interface") or "")))
        result[b].add(normalize_interface_name(str(link.get("remote_interface") or "")))
    return result


def infrastructure_ports(profiles, links):
    """Reserve advertised network-neighbor ports even while the peer is locked."""
    from scanner.neighbor_kind import neighbor_kind
    ports = cdp_ports_by_device(links)
    for identity, profile in profiles.items():
        for neighbor in list(profile.get("cdp_neighbors") or []) + list(profile.get("lldp_neighbors") or []):
            if neighbor_kind(neighbor) == "endpoint":
                continue
            local = neighbor.get("local_port") or neighbor.get("local_interface")
            if _port_quality(local) >= 3:
                ports[identity].add(normalize_interface_name(str(local)))
    return ports


def collect_router_arp(
    profiles: Dict[str, Dict[str, object]],
    community: str,
    include_switches: bool = False,
) -> Dict[str, List[Dict[str, object]]]:
    result: Dict[str, List[Dict[str, object]]] = {}
    for identity, profile in profiles.items():
        allowed_types = {"router", "layer3_switch", "switch", "network_device"} if include_switches else {"router", "layer3_switch"}
        if profile.get("device_type") not in allowed_types:
            continue
        query_ip = str(profile.get("query_ip") or "")
        if not query_ip:
            continue
        if "_arp_scan_cache" in profile:
            result[identity] = profile["_arp_scan_cache"]
            continue
        if "arp_entries" in profile:
            result[identity] = profile.get("arp_entries") or []
            profile["_arp_scan_cache"] = result[identity]
            continue
        try:
            with snmp_session():
                result[identity] = get_arp_table(query_ip, community=profile.get("_snmp_community", community))
        except Exception:
            result[identity] = []
        profile["_arp_scan_cache"] = result[identity]
    return result


def map_end_devices_all_switches(
    profiles: Dict[str, Dict[str, object]],
    cdp_links: List[Dict[str, object]],
    community: str,
    network_device_ips: Set[str],
) -> List[Dict[str, object]]:
    """Correlate every router ARP table with every switch FDB.

    CDP-facing ports are excluded. Therefore a client MAC learned on an uplink
    is ignored on an upstream switch and attached only to its true access switch.
    """
    router_arp = collect_router_arp(profiles, community)
    cdp_ports = infrastructure_ports(profiles, cdp_links)

    arp_by_mac: Dict[str, List[Dict[str, object]]] = defaultdict(list)
    for router_identity, entries in router_arp.items():
        for entry in entries:
            ip_value = str(entry.get("ip") or "").strip()
            mac = normalize_mac(str(entry.get("mac") or ""))
            if not ip_value or not mac or ip_value in network_device_ips:
                continue
            arp_by_mac[mac].append({
                "ip": ip_value,
                "mac": mac,
                "router_identity": router_identity,
                "router_ifindex": entry.get("ifindex", ""),
            })

    results: List[Dict[str, object]] = []
    seen: Set[Tuple[str, str, str]] = set()
    for switch_identity, profile in profiles.items():
        if profile.get("device_type") not in {"switch", "layer3_switch"}:
            continue
        switch_ip = str(profile.get("query_ip") or "")
        if not switch_ip:
            continue
        try:
            if "_fdb_scan_cache" not in profile:
                with snmp_session():
                    profile["_fdb_scan_cache"] = get_mac_port_table(switch_ip, community=profile.get("_snmp_community", community))
            fdb_rows = profile["_fdb_scan_cache"]
        except Exception:
            fdb_rows = []

        excluded_ports = cdp_ports.get(switch_identity, set())
        for fdb in fdb_rows:
            mac = normalize_mac(str(fdb.get("mac") or ""))
            interface = str(fdb.get("interface") or "Unknown")
            normalized_port = normalize_interface_name(interface)
            if not mac or normalized_port in excluded_ports:
                continue
            for arp in arp_by_mac.get(mac, []):
                key = (switch_identity, arp["ip"], normalized_port)
                if key in seen:
                    continue
                seen.add(key)
                results.append({
                    **arp,
                    "switch_identity": switch_identity,
                    "switch_ip": switch_ip,
                    "interface": interface,
                    "ifindex": fdb.get("ifindex", ""),
                    "bridge_port": fdb.get("bridge_port", ""),
                    "vlan": fdb.get("vlan"),
                    "vlan_name": fdb.get("vlan_name", ""),
                    "port_known": True,
                    "relation": "arp_fdb",
                    "confidence": 95,
                    "evidence": "Router ARP + Switch FDB; CDP uplinks excluded",
                })
    return results


def _base_interface_name(name: str) -> str:
    """Return normalized parent interface for subinterfaces.

    Example: FastEthernet2/1.10 -> fastethernet2/1. This prevents ARP entries
    learned through router-on-a-stick subinterfaces from being mistaken for
    directly connected PCs when the parent interface has a CDP neighbor.
    """
    normalized = normalize_interface_name(str(name or ""))
    if "." in normalized:
        normalized = normalized.split(".", 1)[0]
    return normalized



def _subinterface_vlan(name: str) -> Optional[int]:
    """Extract a VLAN ID from common router subinterface names.

    Examples:
    - FastEthernet2/1.10 -> 10
    - GigabitEthernet0/0.99 -> 99

    This is an evidence fallback for IOS images that expose router ARP and
    CDP but do not expose per-VLAN FDB through Q-BRIDGE-MIB.
    """
    normalized = normalize_interface_name(str(name or ""))
    if "." not in normalized:
        return None
    suffix = normalized.rsplit(".", 1)[-1]
    try:
        vlan = int(suffix)
    except ValueError:
        return None
    return vlan if 1 <= vlan <= 4094 else None


def _router_switch_trunks(
    profiles: Dict[str, Dict[str, object]],
    cdp_links: List[Dict[str, object]],
) -> Dict[Tuple[str, str], Dict[str, str]]:
    """Return {(router_identity, normalized_parent_if): switch information}."""
    result: Dict[Tuple[str, str], Dict[str, str]] = {}
    for link in cdp_links:
        source = str(link.get("source_identity") or "")
        target = str(link.get("target_identity") or "")
        source_type = str((profiles.get(source) or {}).get("device_type") or "")
        target_type = str((profiles.get(target) or {}).get("device_type") or "")

        if source_type in {"router", "layer3_switch"} and target_type in {"switch", "layer3_switch"} and source_type != target_type:
            router_identity = source
            switch_identity = target
            router_port = str(link.get("local_interface") or "Unknown")
            switch_port = str(link.get("remote_interface") or "Unknown")
        elif source_type in {"switch", "layer3_switch"} and target_type in {"router", "layer3_switch"} and source_type != target_type:
            router_identity = target
            switch_identity = source
            router_port = str(link.get("remote_interface") or "Unknown")
            switch_port = str(link.get("local_interface") or "Unknown")
        else:
            continue

        result[(router_identity, _base_interface_name(router_port))] = {
            "switch_identity": switch_identity,
            "router_port": router_port,
            "switch_uplink_port": switch_port,
        }
    return result


def map_end_devices_via_router_vlan_and_cdp(
    profiles: Dict[str, Dict[str, object]],
    cdp_links: List[Dict[str, object]],
    community: str,
    network_device_ips: Set[str],
    already_mapped: Optional[Set[Tuple[str, str]]] = None,
) -> List[Dict[str, object]]:
    """Attach router ARP clients to a directly connected managed switch.

    Used when the switch SNMP agent does not expose a usable per-VLAN FDB.
    Router ARP identifies IP/MAC/ifIndex, the ifIndex identifies a router
    subinterface, and CDP identifies the managed switch connected to the
    subinterface's parent physical interface.

    The exact switch access port cannot be proven without FDB/VLAN membership,
    so the result deliberately reports ``port_known=False``.
    """
    mapped = already_mapped or set()
    trunks = _router_switch_trunks(profiles, cdp_links)
    router_arp = collect_router_arp(profiles, community)
    results: List[Dict[str, object]] = []
    seen: Set[Tuple[str, str, str]] = set()

    for router_identity, entries in router_arp.items():
        profile = profiles.get(router_identity) or {}
        interfaces = profile.get("interfaces") or {}

        for entry in entries:
            ip_value = str(entry.get("ip") or "").strip()
            mac = normalize_mac(str(entry.get("mac") or ""))
            ifindex = str(entry.get("ifindex") or "").strip()
            interface = str(interfaces.get(ifindex) or "ifIndex {}".format(ifindex))
            vlan = _subinterface_vlan(interface)
            trunk = trunks.get((router_identity, _base_interface_name(interface)))

            if not ip_value or not mac or ip_value in network_device_ips:
                continue
            if (ip_value, mac) in mapped:
                continue
            if vlan is None or trunk is None:
                continue

            switch_identity = trunk["switch_identity"]
            key = (switch_identity, ip_value, mac)
            if key in seen:
                continue
            seen.add(key)
            results.append({
                "ip": ip_value,
                "mac": mac,
                "router_identity": router_identity,
                "router_ifindex": ifindex,
                "router_interface": interface,
                "vlan": vlan,
                "switch_identity": switch_identity,
                "switch_ip": str((profiles.get(switch_identity) or {}).get("query_ip") or ""),
                "switch_uplink_port": trunk["switch_uplink_port"],
                "interface": "VLAN {} (port unavailable)".format(vlan),
                "port_known": False,
                "relation": "arp_vlan_cdp_fallback",
                "confidence": 82,
                "evidence": (
                    "Router ARP + router subinterface VLAN + Router/Switch CDP; "
                    "switch per-VLAN FDB unavailable via SNMP"
                ),
            })
    return results

def map_direct_router_end_devices(
    profiles: Dict[str, Dict[str, object]],
    cdp_links: List[Dict[str, object]],
    community: str,
    network_device_ips: Set[str],
    already_mapped: Optional[Set[Tuple[str, str]]] = None,
) -> List[Dict[str, object]]:
    """Find end devices connected directly to router interfaces.

    Evidence used:
    - Router ARP gives IP, MAC and ifIndex.
    - Router ifTable maps ifIndex to an interface name.
    - Interfaces used by CDP links are excluded, including parent interfaces
      of subinterfaces, so clients behind managed switches are not attached
      directly to the router.
    - Devices already correlated through Switch FDB are excluded.

    A single remaining ARP entry on an interface is considered a direct end
    device. Multiple entries are returned as an inferred shared/unmanaged
    segment and can be grouped by the graph builder.
    """
    mapped = already_mapped or set()
    router_arp = collect_router_arp(profiles, community)
    cdp_ports = infrastructure_ports(profiles, cdp_links)
    results: List[Dict[str, object]] = []

    for router_identity, entries in router_arp.items():
        profile = profiles.get(router_identity) or {}
        interfaces = profile.get("interfaces") or {}
        excluded_exact = cdp_ports.get(router_identity, set())
        excluded_base = {_base_interface_name(port) for port in excluded_exact}

        candidates_by_interface: Dict[str, List[Dict[str, object]]] = defaultdict(list)
        for entry in entries:
            ip_value = str(entry.get("ip") or "").strip()
            mac = normalize_mac(str(entry.get("mac") or ""))
            ifindex = str(entry.get("ifindex") or "").strip()
            interface = str(interfaces.get(ifindex) or "ifIndex {}".format(ifindex))
            normalized = normalize_interface_name(interface)
            base = _base_interface_name(interface)

            if not ip_value or not mac or ip_value in network_device_ips:
                continue
            if (ip_value, mac) in mapped:
                continue
            if normalized in excluded_exact or base in excluded_base:
                continue

            candidates_by_interface[interface].append({
                "ip": ip_value,
                "mac": mac,
                "router_identity": router_identity,
                "router_ifindex": ifindex,
                "interface": interface,
            })

        for interface, rows in candidates_by_interface.items():
            shared_segment = len(rows) > 1
            for row in rows:
                results.append({
                    **row,
                    "relation": "router_arp_direct" if not shared_segment else "router_arp_shared_segment",
                    "confidence": 90 if not shared_segment else 70,
                    "shared_segment": shared_segment,
                    "evidence": (
                        "Router ARP ifIndex mapped to a non-CDP interface"
                        if not shared_segment
                        else "Multiple Router ARP entries on one non-CDP interface; inferred unmanaged/shared segment"
                    ),
                })

    return results
