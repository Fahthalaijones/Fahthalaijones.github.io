"""Derived Internet nodes and hop layers; never evidence of Internet reachability."""

import re
from collections import deque


def nat_outside_ports(node):
    ports = {}
    interfaces = node.get("interface_details") or node.get("interfaces") or []
    if isinstance(interfaces, dict):
        interfaces = interfaces.values()
    for interface in interfaces:
        if not isinstance(interface, dict):
            continue
        name = str(interface.get("name") or interface.get("interface") or "").strip()
        role = str(interface.get("nat_role") or interface.get("nat") or "").strip().lower()
        description = " ".join(str(interface.get(key) or "") for key in ("name", "description", "alias"))
        inside_label = re.search(r"\bnat\s+inside\b", description, re.I)
        if name and role != "inside" and (role == "outside" or
                (not inside_label and re.search(r"\bnat\b", description, re.I))):
            ports[name] = interface.get("nat_evidence") or "NAT interface name/description: " + description.strip()
    return ports


def apply_layered_layout(payload):
    nodes = payload.setdefault("nodes", [])
    edges = payload.setdefault("edges", [])
    existing_ids = {node["id"] for node in nodes}
    edge_ids = {edge.get("id") for edge in edges}
    for node in list(nodes):
        if node.get("device_type") not in {"router", "layer3_switch", "network_device"}:
            continue
        for port, evidence in nat_outside_ports(node).items():
            cloud_id = "internet-inferred:{}:{}".format(node["id"], port)
            if cloud_id not in existing_ids:
                nodes.append({
                    "id": cloud_id, "device_type": "internet_cloud", "group": "router",
                    "display_name": "Internet (สมมติ)", "hostname": "Internet (สมมติ)",
                    "display_type": "Inferred Internet Cloud", "inferred": True,
                    "discovery": ["NAT inference"], "evidence": evidence,
                    "inference_note": "สมมติทางออก Internet จากพอร์ต NAT ยังไม่ได้ยืนยันการเชื่อมต่อจริง",
                    "confidence_percent": 60,
                })
                existing_ids.add(cloud_id)
            edge_id = "nat-uplink:{}:{}".format(node["id"], port)
            if edge_id not in edge_ids:
                edges.append({
                    "id": edge_id, "from": node["id"], "to": cloud_id,
                    "relation": "inferred_nat_uplink", "inferred": True, "dashes": True,
                    "local_interface": port, "remote_interface": "Internet (สมมติ)",
                    "local_device": node.get("hostname") or node["id"],
                    "remote_device": "Internet (สมมติ)", "discovery": "NAT inference",
                    "evidence": evidence, "confidence": 60, "arrows": "",
                })
                edge_ids.add(edge_id)

    if not nodes:
        return
    by_id = {node["id"]: node for node in nodes}
    adjacency = {node_id: set() for node_id in by_id}
    for edge in edges:
        source, target = edge.get("from"), edge.get("to")
        if source in by_id and target in by_id:
            adjacency[source].add(target)
            adjacency[target].add(source)
    metadata = payload.get("metadata") or {}
    root_ip = metadata.get("root_ip") or next(iter(metadata.get("requested_root_ips") or []), None)
    devices = [node for node in nodes if node.get("device_type") != "internet_cloud"]
    root = next((node for node in devices if root_ip and root_ip in
                 [node.get("ip"), node.get("management_ip"), str(node["id"])]), None)
    root = root or next((node for node in devices if node.get("is_root")), None)
    root = root or next((node for node in devices if node.get("level") == 0), None)
    root = root or next(iter(devices), None)
    levels = {}

    def walk(seeds, start):
        queue = deque()
        for node_id in seeds:
            levels[node_id] = start
            queue.append(node_id)
        while queue:
            current = queue.popleft()
            # Hosts must not become transit paths between network devices.
            if by_id[current].get("device_type") in {"end_device", "server", "printer", "pending_hop"}:
                continue
            for neighbor in sorted(adjacency[current], key=str):
                if neighbor not in levels:
                    levels[neighbor] = levels[current] + 1
                    queue.append(neighbor)

    clouds = [node["id"] for node in nodes if node.get("device_type") == "internet_cloud"]
    walk(clouds or ([root["id"]] if root else []), 0)
    for node in ([root] if root else []) + devices:
        if node["id"] not in levels:
            walk([node["id"]], max(levels.values(), default=-1) + 1)
    for node in nodes:
        node["level"] = levels.get(node["id"], 0)
        node["is_root"] = bool(root and node["id"] == root["id"])
    payload.setdefault("metadata", {})["layout_policy"] = "internet-then-network-hops"
