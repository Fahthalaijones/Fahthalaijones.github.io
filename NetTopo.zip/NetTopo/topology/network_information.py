"""Display LAN prefixes from measured interface addresses, not route guesses."""
import ipaddress


def lan_networks(profile):
    rows = list(profile.get('ip_addresses') or [])
    details = profile.get('interface_details') or profile.get('interfaces') or []
    if isinstance(details, dict):
        details = details.values()
    for interface in details:
        if isinstance(interface, dict):
            rows.extend(dict(row, interface=interface.get('name', '')) for row in interface.get('ip_addresses') or [])
    result = set()
    for row in rows:
        if str(row.get('interface') or row.get('name') or '').lower().startswith(('loopback', 'lo')):
            continue
        if not row.get('ip') or not row.get('netmask'):
            continue
        try:
            address = ipaddress.IPv4Address(str(row['ip']))
            network = ipaddress.IPv4Network(str(row['ip']) + '/' + str(row['netmask']), strict=False)
        except ValueError:
            continue
        # /30-/32 are transit/host links, not LAN segments in this view.
        if address.is_loopback or address.is_link_local or address.is_multicast or address.is_unspecified or network.prefixlen >= 30:
            continue
        result.add(str(network))
    return sorted(result, key=lambda value: (int(ipaddress.IPv4Network(value).network_address), ipaddress.IPv4Network(value).prefixlen))
