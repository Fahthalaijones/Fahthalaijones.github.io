"""V4 topology builder: evidence-only network graph."""

from collections import defaultdict, deque
import re
from typing import Dict, List, Set

from system_settings import (
    INFER_UNMANAGED_SWITCHES,
    INFER_TRUNK_SWITCHES,
    REQUIRE_RECIPROCAL_CDP,
    UNMANAGED_SWITCH_MIN_DEVICES,
)
from topology.device_identity import make_device_identity
from scanner.hardware_identity import model_from_profile, vendor_from_profile
from topology.end_device_mapper import normalize_interface_name
from topology.relationship_engine import (
    build_validated_cdp_links,
    map_direct_router_end_devices,
    map_end_devices_all_switches,
    map_end_devices_via_router_vlan_and_cdp,
    profile_ips,
)


def _type_name(value: str) -> str:
    return {
        "router": "Router",
        "switch": "Managed Switch",
        "layer3_switch": "Layer 3 Switch",
        "unmanaged_switch": "Unmanaged Switch",
        "inferred_trunk_switch": "Trunk Switch (Inferred)",
        "end_device": "PC / End Device",
    }.get(value, value.replace("_", " ").title())


def _node_id(identity: str) -> str:
    return "device:{}".format(identity)


def _friendly_model(profile: Dict[str, object]) -> str:
    return model_from_profile(profile)



def _interface_parent_display(name: object) -> str:
    """Return a physical parent interface while preserving readable casing.

    FastEthernet2/0.10 and FastEthernet2/0.20 both become FastEthernet2/0.
    """
    text = str(name or "").strip()
    return text.split(".", 1)[0].strip() if "." in text else text


def _interface_parent_key(name: object) -> str:
    # Normalize long/short interface aliases before comparing CDP/LLDP with
    # subinterfaces (GigabitEthernet0/1 == Gi0/1, FastEthernet == Fa, etc.).
    # Without this, a real trunk neighbor could be missed and an extra inferred
    # switch would be drawn beside the actual switch.
    return normalize_interface_name(_interface_parent_display(name))


def _subinterface_parents(profile: Dict[str, object]) -> Dict[str, Dict[str, object]]:
    """Group discovered subinterfaces by their physical parent interface.

    This is intentionally an inference signal, not proof of a switch.  The UI
    labels the generated node as Inferred so a router-on-a-stick segment can be
    visualised without drawing one edge for every VLAN subinterface.
    """
    grouped: Dict[str, Dict[str, object]] = {}
    details = profile.get("interface_details") or {}
    rows = details.values() if isinstance(details, dict) else details
    names = []
    for row in rows:
        if isinstance(row, dict) and row.get("name"):
            names.append(str(row.get("name")))
    if not names:
        names.extend(str(value) for value in (profile.get("interfaces") or {}).values())

    for name in names:
        if "." not in name:
            continue
        parent = _interface_parent_display(name)
        suffix = name.rsplit(".", 1)[-1].strip()
        # Cisco-style numeric subinterfaces are the intended signal here.
        if not parent or not suffix.isdigit():
            continue
        key = _interface_parent_key(parent)
        bucket = grouped.setdefault(key, {"parent": parent, "subinterfaces": []})
        if name not in bucket["subinterfaces"]:
            bucket["subinterfaces"].append(name)
    return grouped


def _linked_parent_interfaces(cdp_links: List[Dict[str, object]]) -> Set[tuple]:
    """Return endpoint/parent-interface pairs already proven by CDP/LLDP."""
    linked: Set[tuple] = set()
    for link in cdp_links:
        linked.add((str(link.get("source_identity") or ""), _interface_parent_key(link.get("local_interface"))))
        linked.add((str(link.get("target_identity") or ""), _interface_parent_key(link.get("remote_interface"))))
    return linked

def _calculate_levels(identities: Set[str], links: List[Dict[str, object]], root: str) -> Dict[str, int]:
    adjacency = defaultdict(set)
    for link in links:
        adjacency[link["source_identity"]].add(link["target_identity"])
        adjacency[link["target_identity"]].add(link["source_identity"])
    levels = {root: 0}
    queue = deque([root])
    while queue:
        current = queue.popleft()
        for neighbor in adjacency[current]:
            if neighbor not in levels:
                levels[neighbor] = levels[current] + 1
                queue.append(neighbor)
    fallback = max(levels.values(), default=0) + 1
    for identity in identities:
        levels.setdefault(identity, fallback)
    return levels


def build_recursive_topology(discovery: Dict[str, object], community: str = "", include_end_devices: bool = True):
    profiles: Dict[str, Dict[str, object]] = {}
    ip_index: Dict[str, str] = {}

    for index, profile in enumerate(discovery.get("profiles") or []):
        identity = make_device_identity(profile, fallback=str(index))
        # Identity is management-IP first. This intentionally keeps cloned
        # switches separate even when bridge MAC and sysObjectID are equal.
        profiles[identity] = profile
    from topology.relationship_engine import build_profile_ip_index
    ip_index, _ = build_profile_ip_index(profiles)

    active_roots = [str(ip) for ip in (discovery.get("root_ips") or []) if str(ip)]
    if not active_roots and discovery.get("root_ip"):
        active_roots = [str(discovery.get("root_ip"))]
    root_identity = next((ip_index.get(ip) for ip in active_roots if ip_index.get(ip)), None)
    if root_identity is None:
        raise RuntimeError("Root device from Web Settings was not present in discovery results")

    cdp_links = build_validated_cdp_links(
        profiles,
        ip_index,
        require_reciprocal=REQUIRE_RECIPROCAL_CDP,
        root_identity=root_identity,
    )
    levels = _calculate_levels(set(profiles), cdp_links, root_identity)
    network_device_ips = {ip for profile in profiles.values() for ip in profile_ips(profile)}
    network_device_ips.update(discovery.get("network_device_ips") or [])
    network_device_ips.update(str(row.get("ip")) for row in discovery.get("credential_required") or []
                              if row.get("ip") and row.get("neighbor_kind") != "endpoint")

    nodes: List[dict] = []
    edges: List[dict] = []
    for identity, profile in profiles.items():
        from topology.network_information import lan_networks
        device_type = str(profile.get("device_type") or "network_device")
        query_ip = str(profile.get("query_ip") or "")
        nodes.append({
            "id": _node_id(identity),
            "label": "",
            "display_name": profile.get("hostname") or "Unknown",
            "display_ip": query_ip or "No IP",
            "display_type": _type_name(device_type),
            "hostname": profile.get("hostname") or "Unknown",
            "ip": query_ip,
            "management_ip": query_ip,
            "management_ips": sorted(profile_ips(profile)),
            "identity_evidence": profile.get("identity_evidence") or [],
            "lan_networks": lan_networks(profile),
            "device_type": device_type,
            "group": "switch" if device_type in {"switch", "layer3_switch"} else ("router" if device_type == "network_device" else device_type),
            "level": levels[identity],
            "vendor": vendor_from_profile(profile),
            "model": _friendly_model(profile),
            "classification_source": profile.get("classification_source", "discovery"),
            "catalog_model": profile.get("catalog_model", ""),
            "l3_capable": profile.get("l3_capable"),
            "ip_forwarding": profile.get("ip_forwarding", ""),
            "routing_enabled": profile.get("routing_enabled"),
            "description": profile.get("description") or "",
            "cdp_neighbors": profile.get("cdp_neighbors") or [],
            "lldp_neighbors": profile.get("lldp_neighbors") or [],
            "bridge_address": profile.get("bridge_address") or "",
            "discovery": [str(profile.get("access_method") or "SNMP")]
                         + (["CDP/LLDP"] if profile.get("cdp_neighbors") or profile.get("lldp_neighbors") else [])
                         + (["ARP candidate"] if profile.get("discovered_by") == "arp-snmp" else []),
            "interfaces": sorted((profile.get("interface_details") or {}).values(), key=lambda row: int(str(row.get("ifindex") or "0")) if str(row.get("ifindex") or "0").isdigit() else 999999),
            "vlans": profile.get("vlan_database") or [],
            "interface_vlan_note": (
                "Access VLAN and trunk state are read through Cisco VLAN MIBs. "
                "A PC port is exact only when its MAC also appears in BRIDGE-MIB; "
                "otherwise the system shows the VLAN inferred from the router subinterface."
                if device_type in {"switch", "layer3_switch"} else ""
            ),
        })

    for sequence, link in enumerate(cdp_links, 1):
        edges.append({
            "id": "cdp:{}".format(sequence),
            "from": _node_id(str(link["source_identity"])),
            "to": _node_id(str(link["target_identity"])),
            # Port names are drawn beside their own endpoint in the browser.
            # A single middle label made local/remote ownership visually ambiguous.
            "label": "",
            "relation": str(link.get("relation") or "cdp"),
            "discovery": str(link.get("protocol") or "CDP"),
            "evidence": link["evidence"],
            "local_device": (profiles.get(str(link["source_identity"])) or {}).get("hostname") or str(link["source_identity"]),
            "remote_device": (profiles.get(str(link["target_identity"])) or {}).get("hostname") or str(link["target_identity"]),
            "local_interface": link["local_interface"],
            "remote_interface": link["remote_interface"],
            "confidence": link["confidence"],
            "arrows": "",
        })


    # Router-on-a-stick / subinterface inference.
    # If Fa2/0.10, Fa2/0.20, ... exist but CDP/LLDP has not already proven a
    # neighbor on Fa2/0, show ONE inferred trunk switch rather than many VLAN
    # edges.  The parent endpoint is labelled "Fa2/0 (Sub-IF)" so the map stays
    # readable and the inference remains explicit.
    inferred_trunk_count = 0
    linked_parents = _linked_parent_interfaces(cdp_links)
    for identity, profile in profiles.items():
        for parent_key, info in (sorted(_subinterface_parents(profile).items()) if INFER_TRUNK_SWITCHES else []):
            if (identity, parent_key) in linked_parents:
                continue
            parent = str(info.get("parent") or "Unknown")
            subinterfaces = list(info.get("subinterfaces") or [])
            # A single subinterface is not enough evidence to invent another
            # physical device. Require at least two VLAN subinterfaces on the
            # same parent before showing one inferred trunk switch.
            if len(subinterfaces) < 2:
                continue
            inferred_trunk_count += 1
            inferred_id = "trunk-inferred:{}:{}".format(
                identity,
                parent_key.replace("/", "-").replace(" ", ""),
            )
            nodes.append({
                "id": inferred_id,
                "label": "",
                "display_name": "Trunk Switch (Inferred)",
                "display_ip": "No management IP",
                "display_type": "Trunk Switch (Inferred)",
                "hostname": "Trunk Switch (Inferred)",
                "ip": "-",
                "device_type": "inferred_trunk_switch",
                "group": "switch",
                "level": levels.get(identity, 0) + 1,
                "discovery": ["Subinterface inference"],
                "connected_to": profile.get("hostname") or identity,
                "uplink_port": parent,
                "subinterfaces": subinterfaces,
                "inference_note": "Subinterfaces detected on {}: {}".format(parent, ", ".join(subinterfaces)),
            })
            edges.append({
                "id": "trunk-inferred:{}".format(inferred_trunk_count),
                "from": _node_id(identity),
                "to": inferred_id,
                "label": "",
                "relation": "inferred_trunk_switch",
                "discovery": "Subinterface inference",
                "evidence": "Subinterfaces detected on physical parent {}; trunk switch inferred".format(parent),
                "confidence": 60,
                "local_device": profile.get("hostname") or identity,
                "remote_device": "Trunk Switch (Inferred)",
                "local_interface": "{} (Sub-IF)".format(parent),
                "remote_interface": "Unknown",
                "arrows": "",
            })

    if not include_end_devices:
        metadata = {
            "root_ip": discovery.get("root_ip") or "",
            "visited_networks": discovery.get("visited_networks") or [],
            "scan_scope": discovery.get("scan_scope") or [],
            "inferred_unmanaged_switches": 0,
            "inferred_trunk_switches": inferred_trunk_count,
            "vlan_cdp_fallback_end_devices": 0,
            "scan_level": discovery.get("scan_level", "topology"),
            "connection_mode": discovery.get("connection_mode", "auto"),
        }
        return nodes, edges, metadata

    end_devices = map_end_devices_all_switches(
        profiles=profiles,
        cdp_links=cdp_links,
        community=community,
        network_device_ips=network_device_ips,
    )
    # Fallback for IOSvL2 images that do not expose Q-BRIDGE-MIB or
    # VLAN-indexed FDB contexts. It can still prove which managed switch owns
    # the VLAN segment by combining Router ARP/subinterface evidence with CDP.
    fdb_mapped = {(row["ip"], row["mac"]) for row in end_devices}
    fallback_end_devices = map_end_devices_via_router_vlan_and_cdp(
        profiles=profiles,
        cdp_links=cdp_links,
        community=community,
        network_device_ips=network_device_ips,
        already_mapped=fdb_mapped,
    )
    end_devices.extend(fallback_end_devices)

    by_switch_port = defaultdict(list)
    for row in end_devices:
        by_switch_port[(row["switch_identity"], row.get("interface") or "Unknown")].append(row)

    inferred_count = 0
    existing_end = set()
    endpoint_ids = set()
    vlan_cdp_fallback_count = 0
    for (switch_identity, port), rows in sorted(by_switch_port.items()):
        switch_id = _node_id(switch_identity)
        switch_level = levels.get(switch_identity, 0)
        infer = (
            INFER_UNMANAGED_SWITCHES
            and bool(re.match(r"^(?:Gi|GigabitEthernet|Te|TenGigabitEthernet|Fa|FastEthernet|Eth|Ethernet|Hu|HundredGigE|Twe|TwentyFiveGigE)\d", port, re.I))
            and all(row.get("relation") == "arp_fdb" and row.get("port_known", True) for row in rows)
            and len({row["mac"] for row in rows}) >= UNMANAGED_SWITCH_MIN_DEVICES
        )
        parent_id = switch_id
        child_level = switch_level + 1
        if infer:
            inferred_count += 1
            inferred_id = "inferred:{}:{}".format(
                switch_identity,
                str(port).lower().replace("/", "-").replace(" ", ""),
            )
            nodes.append({
                "id": inferred_id,
                "label": "",
                "display_name": "L2 ที่คาดว่าต่อพ่วง",
                "display_ip": "No management IP",
                "display_type": "Inferred L2 · Switch / AP / Bridge",
                "hostname": "L2 ที่คาดว่าต่อพ่วง",
                "ip": "-",
                "device_type": "unmanaged_switch",
                "group": "switch",
                "level": child_level,
                "discovery": ["FDB inference"],
                "inference_basis": "multiple-macs-one-physical-port",
                "evidence": "พบหลาย MAC บนพอร์ตจริงเดียวกันจาก FDB อาจเป็น Switch, AP หรือ Bridge",
                "confidence_percent": 75,
                "child_device_count": len({row["mac"] for row in rows}),
                "connected_to": profiles[switch_identity].get("hostname") or "Managed Switch",
                "uplink_port": port,
            })
            edges.append({
                "id": "inferred:{}".format(inferred_count),
                "from": switch_id,
                "to": inferred_id,
                "label": "",
                "local_interface": port,
                "remote_interface": "Unknown",
                "relation": "inferred_unmanaged_switch",
                "dashes": True,
                "discovery": "FDB inference",
                "confidence": 75,
                "arrows": "",
            })
            parent_id = inferred_id
            child_level += 1

        for row in rows:
            key = (row["ip"], row["mac"])
            if key in existing_end:
                continue
            existing_end.add(key)
            end_id = "end:{}".format(str(row["mac"]).replace(":", "").lower())
            # Proxy ARP and multi-address hosts can share a MAC across IPs.
            # Keep each observation while preserving the legacy ID when unique.
            if end_id in endpoint_ids:
                end_id = "{}:{}".format(end_id, row["ip"])
            endpoint_ids.add(end_id)
            nodes.append({
                "id": end_id,
                "label": "",
                "display_name": "Unknown",
                "display_ip": row["ip"],
                "display_type": "PC / End Device",
                "hostname": "Unknown",
                "ip": row["ip"],
                "mac": row["mac"],
                "device_type": "end_device",
                "group": "end_device",
                "level": child_level,
                "connected_to": profiles[switch_identity].get("hostname") or "Managed Switch",
                "switch_port": "Unknown" if infer else port,
                "observed_upstream_port": port if infer else None,
                "connection_status": "ทราบพอร์ตต้นทาง แต่ยังไม่ทราบพอร์ตของ L2 ที่คาดว่าต่อพ่วง" if infer else "",
                "vlan": row.get("vlan"),
                "port_known": row.get("port_known", True),
                "discovery": (["ARP", "FDB"] if row.get("relation") == "arp_fdb" else ["ARP", "CDP", "VLAN inference"]),
            })
            if row.get("relation") == "arp_vlan_cdp_fallback":
                vlan_cdp_fallback_count += 1
            edges.append({
                "id": "arp-fdb:{}:{}".format(switch_identity, end_id),
                "from": parent_id,
                "to": end_id,
                "label": "",
                "local_interface": ("Unknown" if infer else port),
                "remote_interface": "Unknown",
                "relation": ("unmanaged_downstream" if infer else row.get("relation", "arp_fdb")),
                "dashes": infer,
                "discovery": ("ARP + FDB" if row.get("relation") == "arp_fdb" else "Router ARP + VLAN + CDP"),
                "evidence": row["evidence"],
                "confidence": row["confidence"],
                "arrows": "",
            })

    # Discover PCs connected directly to router Layer-3 interfaces.
    # Entries already mapped through Switch FDB are excluded to prevent duplicates.
    direct_rows = map_direct_router_end_devices(
        profiles=profiles,
        cdp_links=cdp_links,
        community=community,
        network_device_ips=network_device_ips,
        already_mapped=set(existing_end),
    )
    by_router_interface = defaultdict(list)
    for row in direct_rows:
        by_router_interface[(row["router_identity"], row.get("interface") or "Unknown")].append(row)

    direct_count = 0
    for (router_identity, interface), rows in sorted(by_router_interface.items()):
        router_id = _node_id(router_identity)
        router_level = levels.get(router_identity, 0)
        shared = any(bool(row.get("shared_segment")) for row in rows)
        parent_id = router_id
        child_level = router_level + 1

        for row in rows:
            key = (row["ip"], row["mac"])
            if key in existing_end:
                continue
            existing_end.add(key)
            direct_count += 1
            end_id = "end:{}".format(str(row["mac"]).replace(":", "").lower())
            # Proxy ARP and multi-address hosts can share a MAC across IPs.
            # Keep each observation while preserving the legacy ID when unique.
            if end_id in endpoint_ids:
                end_id = "{}:{}".format(end_id, row["ip"])
            endpoint_ids.add(end_id)
            nodes.append({
                "id": end_id,
                "label": "",
                "display_name": "Unknown",
                "display_ip": row["ip"],
                "display_type": "PC / End Device",
                "hostname": "Unknown",
                "ip": row["ip"],
                "mac": row["mac"],
                "device_type": "end_device",
                "group": "end_device",
                "level": child_level,
                "connected_to": profiles[router_identity].get("hostname") or "Router",
                "router_interface": interface,
                "discovery": ["ARP", "ifIndex"],
            })
            edges.append({
                "id": "router-arp:{}:{}".format(router_identity, end_id),
                "from": parent_id,
                "to": end_id,
                "label": "",
                "local_interface": (interface),
                "remote_interface": "Unknown",
                "relation": row.get("relation", "router_arp_direct"),
                "discovery": "Router ARP + ifIndex",
                "evidence": row["evidence"],
                "confidence": row["confidence"],
                "arrows": "",
            })

    metadata = {
        "root_ip": discovery.get("root_ip") or "",
        "network_device_count": len(profiles),
        "end_device_count": len(existing_end),
        "direct_router_end_device_count": direct_count,
        "vlan_cdp_fallback_end_device_count": vlan_cdp_fallback_count,
        "inferred_switch_count": inferred_count,
        "inferred_trunk_switch_count": inferred_trunk_count,
        "cdp_link_count": len(cdp_links),
        "require_reciprocal_cdp": REQUIRE_RECIPROCAL_CDP,
        "scan_scope": discovery.get("scan_scope", []),
        "visited_networks": discovery.get("visited_networks", []),
    }
    return nodes, edges, metadata
