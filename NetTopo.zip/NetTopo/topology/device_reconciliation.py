"""Associate advertised/router-interface addresses with known network devices."""
import ipaddress
from topology.end_device_mapper import normalize_mac
from topology.relationship_engine import find_neighbor_identity, profile_ips, _profile_macs, _hostname_key, build_profile_ip_index


def reconcile_network_addresses(profiles, merge_profile=None):
    aliases = {}
    for _ in range(2):
        for source, profile in list(profiles.items()):
            if source not in profiles:
                continue
            for field, protocol in (('cdp_neighbors', 'CDP'), ('lldp_neighbors', 'LLDP')):
                for neighbor in list(profile.get(field) or []):
                    try:
                        address = ipaddress.IPv4Address(str(neighbor.get('management_ip') or ''))
                    except ValueError:
                        continue
                    if address.is_unspecified or address.is_multicast:
                        continue
                    ip = str(address)
                    # Resolve identity independently of the advertised address.
                    target = find_neighbor_identity(profiles, {}, dict(neighbor, management_ip=''))
                    if not target or target == source:
                        continue
                    owners = [key for key, p in profiles.items() if str(p.get('query_ip') or p.get('ip') or '') == ip]
                    if owners and owners != [target]:
                        if len(owners) != 1 or merge_profile is None:
                            continue
                        other = owners[0]
                        a, b = profiles[target], profiles[other]
                        same_name = _hostname_key(a.get('hostname')) == _hostname_key(b.get('hostname'))
                        fallback_name = str(b.get('hostname') or '') in {'', 'Unknown', 'unknown', ip}
                        shared_macs = _profile_macs(a) & _profile_macs(b)
                        shared_macs.discard('00:00:00:00:00:00')
                        mutual_ip = ip in profile_ips(a) and str(a.get('query_ip') or a.get('ip') or '') in profile_ips(b)
                        if a.get('device_type') != 'router' or b.get('device_type') != 'router' or not shared_macs or not (same_name or fallback_name) or not mutual_ip:
                            continue
                        merge_profile(a, b)
                        aliases[other] = target
                        del profiles[other]
                    owner = profiles[target]
                    owner['management_ips'] = sorted(profile_ips(owner) | {ip})
                    record = {'ip': ip, 'source': protocol, 'neighbor_name': neighbor.get('remote_device') or '', 'chassis': neighbor.get('chassis') or ''}
                    evidence = owner.setdefault('identity_evidence', [])
                    if record not in evidence:
                        evidence.append(record)
        # ARP cannot classify a host, but a MAC already read from a network
        # device's own interface table can identify another IP of that box.
        mac_owners = {}
        for identity, profile in profiles.items():
            for mac in _profile_macs(profile) - {'00:00:00:00:00:00'}:
                mac_owners.setdefault(mac, set()).add(identity)
        primary = {str(p.get('query_ip') or p.get('ip') or ''): key for key, p in profiles.items()}
        for profile in profiles.values():
            for row in profile.get('_arp_scan_cache', profile.get('arp_entries') or []) or []:
                owners = mac_owners.get(normalize_mac(str(row.get('mac') or '')), set())
                if len(owners) != 1:
                    continue
                target = next(iter(owners))
                ip = str(row.get('ip') or '')
                try:
                    address = ipaddress.IPv4Address(ip)
                except ValueError:
                    continue
                if address.is_unspecified or address.is_multicast or (ip in primary and primary[ip] != target):
                    continue
                owner = profiles[target]
                owner['management_ips'] = sorted(profile_ips(owner) | {ip})
                record = {'ip': ip, 'source': 'ARP + SNMP interface MAC'}
                if record not in owner.setdefault('identity_evidence', []):
                    owner['identity_evidence'].append(record)
    index, ambiguous = build_profile_ip_index(profiles)
    return index, ambiguous, aliases
