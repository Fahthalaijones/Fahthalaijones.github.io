@echo off
setlocal
cd /d "%~dp0"
if errorlevel 1 goto failed

echo NetTopo setup
if not exist "requirements.txt" (
    echo requirements.txt is missing. Extract the entire project before running setup.
    goto failed
)

if exist ".venv\Scripts\python.exe" goto check_venv

rem Prefer the Python Launcher; fall back to Python on PATH.
py -3.11 -c "import sys; sys.exit(0 if sys.version_info[:2] == (3, 11) else 1)" >nul 2>&1
if not errorlevel 1 goto create_with_launcher
python -c "import sys; sys.exit(0 if sys.version_info[:2] == (3, 11) else 1)" >nul 2>&1
if not errorlevel 1 goto create_with_python

echo Python 3.11 was not found.
echo Install Python 3.11 from https://www.python.org/downloads/windows/
echo Include the Python Launcher or enable Add Python to PATH, then run setup again.
goto failed

:create_with_launcher
py -3.11 -m venv .venv
if errorlevel 1 goto failed
goto check_venv

:create_with_python
python -m venv .venv
if errorlevel 1 goto failed

:check_venv
".venv\Scripts\python.exe" -c "import sys; sys.exit(0 if sys.version_info[:2] == (3, 11) else 1)"
if errorlevel 1 (
    echo The existing .venv cannot run Python 3.11.
    echo Rename .venv to .venv-backup and run setup again. No files were deleted.
    goto failed
)

echo Installing Python packages...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip check
if errorlevel 1 goto failed

echo Preparing local dashboard assets...
".venv\Scripts\python.exe" tools\localize_assets.py
if errorlevel 1 goto failed

echo.
echo Setup complete. Double-click start_windows.bat to launch NetTopo.
echo Nmap and Npcap must be installed separately for network scanning.
pause
exit /b 0

:failed
echo.
echo Setup failed. Review the message above. Package and asset downloads need Internet access.
pause
exit /b 1
