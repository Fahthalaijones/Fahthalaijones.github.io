const state = {
    payload: null,
    allNodes: [],
    allEdges: [],
    nodes: new vis.DataSet([]),
    edges: new vis.DataSet([]),
    network: null,
    chart: null,
    hasSavedLayout: false,
    layoutMode: "auto",
    scanLevel: "topology",
    labelBoxes: new Map(),
    labelDrag: null,
    searchTimer: null,
    discoverySettings: {
        connectionMode: "auto",
        snmpCommunity: "public",
        sshEnabled: false,
        sshUsername: "",
        sshPassword: "",
        sshPort: 22,
        sshDeviceType: "auto",
        rootNodeIps: "",
    },
    credentialQueue: [],
};

const $ = (id) => document.getElementById(id);
const SWITCH_ICON_SIZE = 29;
const L3_SWITCH_ICON_SIZE = 43;

function cssVar(name, fallback) {
    const value = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
    return value || fallback;
}

function currentTheme() {
    return document.documentElement.dataset.theme || "pastel";
}

function themedIconPath(type, theme = currentTheme()) {
    const base = {
        internet_cloud: "cloud",
        router: "router",
        switch: "switch",
        layer3_switch: "switch_l3",
        unmanaged_switch: "switch",
        inferred_trunk_switch: "switch",
        end_device: "pc",
        server: "server",
        printer: "printer",
        unknown: "unknown",
    }[type] || "unknown";
    const suffix = theme === "dark" ? "_dark" : (theme === "blue" ? "_blue" : "");
    return `/static/icons/${base}${suffix}.svg`;
}

function nodeIconType(node) {
    const type = node.device_type || node.group || "unknown";
    if (type === "internet_cloud") return "internet_cloud";
    // Hardware evidence takes precedence over an older endpoint/service icon.
    if (["router", "switch", "layer3_switch", "unmanaged_switch", "inferred_trunk_switch"].includes(type)) return type;
    if (type === "pending_hop") return "unknown";
    if (["server", "printer"].includes(type)) return type;
    if (type === "end_device") {
        if (["server", "printer"].includes(node.icon_type)) return node.icon_type;
        if (node.service_role || node.services?.length) return /print/i.test(node.service_role || "") ? "printer" : "server";
        return "end_device";
    }
    return node.icon_type || type;
}

function isRootNode(node) {
    return node.is_root === true;
}

function nodeAppearance(node) {
    const icon = nodeIconType(node);
    const isSwitch = ["switch", "layer3_switch", "unmanaged_switch", "inferred_trunk_switch"].includes(icon);
    return { icon_type: icon, shape: "image", image: themedIconPath(icon),
        group: isSwitch ? (icon === "layer3_switch" ? "layer3_switch" : "switch") : (node.device_type === "network_device" ? "router" : icon),
        shadow: { enabled: isRootNode(node), color: "#f59e0b", size: 22, x: 0, y: 0 },
        size: isSwitch ? (icon === "layer3_switch" ? L3_SWITCH_ICON_SIZE : SWITCH_ICON_SIZE) : (node.device_type === "pending_hop" ? 40 : icon === "router" ? 35 : 44) };
}

function nodeCategory(node) {
    const type = node.device_type || node.group;
    if (type === "internet_cloud") return "router";
    if (["end_device", "server", "printer"].includes(type)) return "end_device";
    if (["switch", "layer3_switch", "unmanaged_switch", "inferred_trunk_switch"].includes(type)) return "switch";
    if (["router", "pending_hop", "network_device"].includes(type)) return "router";
    return node.group;
}

function refreshThemeIcons() {
    const theme = currentTheme();
    if (state.nodes) {
        state.allNodes = state.allNodes.map(node => ({ ...node, ...nodeAppearance(node) }));
        const updates = state.nodes.get().map((node) => ({ id: node.id, ...nodeAppearance(node) }));
        if (updates.length) state.nodes.update(updates);
    }
    document.querySelectorAll("img[data-icon-type]").forEach((img) => {
        img.src = themedIconPath(img.dataset.iconType, theme);
    });
    const detail = $("deviceIcon")?.querySelector("img[data-device-type]");
    if (detail) detail.src = themedIconPath(detail.dataset.deviceType, theme);
}

function applyTheme(theme, persist = true) {
    const positions = currentVisiblePositions();
    const viewPosition = state.network?.getViewPosition?.();
    const viewScale = state.network?.getScale?.();
    const allowed = new Set(["pastel", "dark", "blue"]);
    const selected = allowed.has(theme) ? theme : "pastel";
    document.documentElement.dataset.theme = selected;
    if ($("themeSelect")) $("themeSelect").value = selected;
    if (persist) localStorage.setItem("netmap-theme", selected);
    refreshThemeIcons();
    if (state.network) {
        // Theme changes affect artwork/colors only. Reapplying layout options
        // resets vis' hierarchical coordinates and can discard manual work.
        const options = networkOptions(state.layoutMode);
        state.network.setOptions({ edges: options.edges, groups: options.groups });
        state.allNodes = state.allNodes.map(node => positions[node.id] ? { ...node, ...positions[node.id] } : node);
        for (const [id, position] of Object.entries(positions)) {
            if (state.network.moveNode) state.network.moveNode(id, position.x, position.y);
            else state.nodes.update([{ id, x: position.x, y: position.y }]);
        }
        if (viewPosition && Number.isFinite(viewScale)) state.network.moveTo?.({ position: viewPosition, scale: viewScale, animation: false });
        state.network.redraw();
    }
    if (state.payload) updateChart(state.payload.summary || {});
}

function escapeHtml(value) {
    return String(value ?? "-").replace(/[&<>'"]/g, (char) => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;"
    }[char]));
}

function toast(message) {
    const el = $("toast");
    el.textContent = message;
    el.classList.remove("hidden");
    window.setTimeout(() => el.classList.add("hidden"), 2600);
}


function setOperationStatus(text, kind = "ready") {
    const badge = $("scanBadge");
    if (!badge) return;
    const statusKind = ["ready", "working", "success", "imported", "error"].includes(kind) ? kind : "ready";
    badge.className = `operation-status status-${statusKind}`;
    badge.setAttribute("aria-busy", String(statusKind === "working"));
    $("scanStatusIcon").textContent = ({ready: "○", working: "⌕", success: "✓", imported: "✓", error: "!"})[statusKind];
    $("scanStatusText").textContent = statusKind === "error" ? `Error · ${text}` : text;
}

function setDiscoveryStatus(data) {
    const pending = pendingHopRows(data);
    if (pending.length) setOperationStatus(`Success · ${pending.length} Hop รอสแกนต่อ`, "success");
    else setOperationStatus("Success", "success");
}

function networkOptions(mode = "auto") {
    const auto = mode === "auto";
    return {
        autoResize: true,
        layout: auto ? {
            hierarchical: {
                enabled: true,
                direction: "UD",
                sortMethod: "directed",
                shakeTowards: "roots",
                levelSeparation: 215,
                nodeSpacing: 220,
                treeSpacing: 330,
                blockShifting: true,
                edgeMinimization: true,
                parentCentralization: true,
            }
        } : {
            hierarchical: { enabled: false }
        },
        physics: { enabled: false },
        nodes: {
            borderWidth: 0,
            shadow: { enabled: false },
            font: { size: 1, color: "rgba(0,0,0,0)" },
            fixed: { x: false, y: false },
        },
        edges: {
            width: 1.8,
            color: { color: cssVar("--edge", "#97859D"), highlight: cssVar("--edge-highlight", "#556C8E"), hover: cssVar("--edge-highlight", "#556C8E") },
            smooth: { enabled: true, type: "cubicBezier", forceDirection: auto ? "vertical" : "none", roundness: .18 },
            font: {
                size: 10, align: "middle", background: cssVar("--label-bg", "rgba(255,250,248,.96)"),
                color: cssVar("--text", "#556C8E"), strokeWidth: 0
            },
        },
        groups: {
            router: { shape: "image", image: themedIconPath("router"), size: 35 },
            switch: { shape: "image", image: themedIconPath("switch"), size: SWITCH_ICON_SIZE },
            layer3_switch: { shape: "image", image: themedIconPath("layer3_switch"), size: L3_SWITCH_ICON_SIZE },
            unmanaged_switch: { shape: "image", image: themedIconPath("unmanaged_switch"), size: SWITCH_ICON_SIZE },
            end_device: { shape: "image", image: themedIconPath("end_device"), size: 44 },
            server: { shape: "image", image: themedIconPath("server"), size: 44 },
            printer: { shape: "image", image: themedIconPath("printer"), size: 44 },
            unknown: { shape: "image", image: themedIconPath("unknown"), size: 44 },
        },
        interaction: {
            hover: true,
            navigationButtons: true,
            keyboard: { enabled: true, bindToWindow: false },
            dragNodes: true,
            dragView: true,
            zoomView: true,
            selectConnectedEdges: true,
        },
    };
}

function updateLayoutButtons() {
    const manual = $("manualLayoutButton");
    const auto = $("autoLayoutButton");
    if (!manual || !auto) return;
    manual.classList.toggle("primary", state.layoutMode === "manual");
    manual.classList.toggle("light", state.layoutMode !== "manual");
    auto.classList.toggle("primary", state.layoutMode === "auto");
    auto.classList.toggle("light", state.layoutMode !== "auto");
}

function currentVisiblePositions() {
    if (!state.network) return {};
    return state.network.getPositions(state.nodes.getIds());
}

function setManualLayout({ keepCurrentPositions = true, notify = true } = {}) {
    const positions = keepCurrentPositions ? currentVisiblePositions() : {};
    state.layoutMode = "manual";
    state.network.setOptions(networkOptions("manual"));
    const updates = state.nodes.getIds().map((id) => {
        const pos = positions[id];
        const node = state.nodes.get(id);
        return { id, ...nodeAppearance(node), ...(pos ? { x: pos.x, y: pos.y } : {}),
            fixed: { x: false, y: false }, physics: false };
    });
    if (updates.length) state.nodes.update(updates);
    updateLayoutButtons();
    if (notify) toast("Manual Layout: ลากอุปกรณ์ได้อิสระทั้งขึ้น-ลงและซ้าย-ขวา");
}

function runAutoLayout({ notify = true } = {}) {
    state.layoutMode = "auto";
    // Remove stored coordinates from the in-memory DataSet so hierarchical
    // layout can calculate a fresh position from the topology levels.
    const fresh = state.allNodes.map((node) => {
        const copy = { ...node };
        delete copy.x;
        delete copy.y;
        delete copy.fixed;
        delete copy.physics;
        return copy;
    });
    state.allNodes = fresh;
    state.network.setOptions(networkOptions("auto"));
    applyFilters(false);
    updateLayoutButtons();
    window.setTimeout(() => state.network.fit({ animation: true }), 120);
    if (notify) toast("Auto Layout applied");
}

function roundedRect(ctx, x, y, width, height, radius) {
    const r = Math.min(radius, width / 2, height / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + width, y, x + width, y + height, r);
    ctx.arcTo(x + width, y + height, x, y + height, r);
    ctx.arcTo(x, y + height, x, y, r);
    ctx.arcTo(x, y, x + width, y, r);
    ctx.closePath();
}

function drawNodeLabels(ctx) {
    if (!state.network) return;
    const positions = state.network.getPositions();
    const visibleIds = new Set(state.nodes.getIds());
    state.labelBoxes.clear();

    state.allNodes.forEach((node) => {
        if (!visibleIds.has(node.id) || !positions[node.id]) return;
        const pos = positions[node.id];
        const baseName = String(node.display_name || node.hostname || node.ip || "Unknown");
        const name = node.credential_pending ? `${baseName} · กรอกข้อมูลเพิ่มเติม` :
            node.device_type === "layer3_switch" ? `${baseName} · L3` : baseName;
        const fontSize = 13;
        const offsetX = Number.isFinite(Number(node.label_offset_x)) ? Number(node.label_offset_x) : 0;
        const offsetY = Number.isFinite(Number(node.label_offset_y)) ? Number(node.label_offset_y) : -64;

        ctx.save();
        ctx.font = `600 ${fontSize}px Arial`;
        const textWidth = ctx.measureText(name).width;
        const cardWidth = textWidth + 16;
        const cardHeight = 24;
        const centerX = pos.x + offsetX;
        const centerY = pos.y + offsetY;
        const x = centerX - cardWidth / 2;
        const y = centerY - cardHeight / 2;

        roundedRect(ctx, x, y, cardWidth, cardHeight, 6);
        ctx.fillStyle = node.credential_pending ? "#fff3d6" : cssVar("--label-bg", "rgba(255,250,248,.94)");
        ctx.fill();
        ctx.strokeStyle = node.credential_pending ? "#e88a14" : cssVar("--label-border", "rgba(151,133,157,.30)");
        ctx.lineWidth = node.credential_pending ? 3 : 1;
        ctx.stroke();

        ctx.fillStyle = node.credential_pending ? "#8a4600" : cssVar("--text", "#556C8E");
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(name, centerX, centerY + .5);
        ctx.restore();

        // Canvas/network coordinates used for Draw.io-style label dragging.
        state.labelBoxes.set(String(node.id), { x, y, width: cardWidth, height: cardHeight });
    });
}

function validPortLabel(value) {
    const text = String(value || "").trim();
    return text && !["unknown", "none", "0", "-"].includes(text.toLowerCase());
}

function drawPortCard(ctx, text, x, y) {
    ctx.save();
    ctx.font = "600 10px Arial";
    const width = ctx.measureText(text).width + 10;
    const height = 18;
    roundedRect(ctx, x - width / 2, y - height / 2, width, height, 5);
    ctx.fillStyle = cssVar("--label-bg", "rgba(255,250,248,.96)");
    ctx.fill();
    ctx.strokeStyle = cssVar("--label-border", "rgba(85,108,142,.38)");
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.fillStyle = cssVar("--text", "#556C8E");
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(text, x, y + .5);
    ctx.restore();
}

function drawEdgePortLabels(ctx) {
    if (!state.network) return;
    const positions = state.network.getPositions();
    const visibleEdgeIds = new Set(state.edges.getIds().map(String));
    const visibleNodeIds = new Set(state.nodes.getIds().map(String));
    const drawnEndpointPorts = new Set();

    state.allEdges.forEach((edge) => {
        if (!visibleEdgeIds.has(String(edge.id))) return;
        if (!visibleNodeIds.has(String(edge.from)) || !visibleNodeIds.has(String(edge.to))) return;
        const from = positions[edge.from];
        const to = positions[edge.to];
        if (!from || !to) return;

        const dx = to.x - from.x;
        const dy = to.y - from.y;
        const length = Math.hypot(dx, dy);
        if (length < 1) return;
        const ux = dx / length;
        const uy = dy / length;
        const endpointDistance = Math.min(64, Math.max(46, length * 0.18));

        // Draw a device/port pair only once. Several ARP/FDB endpoints may
        // legitimately share the same physical switch port; repeating the same
        // interface card on every edge makes the map look like extra links.
        const localText = String(edge.local_interface || "").trim();
        const localKey = `${edge.from}|${localText.toLowerCase().replace(/\s+/g, "")}`;
        if (validPortLabel(localText) && !drawnEndpointPorts.has(localKey)) {
            drawnEndpointPorts.add(localKey);
            drawPortCard(ctx, localText, from.x + ux * endpointDistance, from.y + uy * endpointDistance);
        }

        const remoteText = String(edge.remote_interface || "").trim();
        const remoteKey = `${edge.to}|${remoteText.toLowerCase().replace(/\s+/g, "")}`;
        if (validPortLabel(remoteText) && !drawnEndpointPorts.has(remoteKey)) {
            drawnEndpointPorts.add(remoteKey);
            drawPortCard(ctx, remoteText, to.x - ux * endpointDistance, to.y - uy * endpointDistance);
        }
    });
}

function nodeById(id) {
    return state.allNodes.find((node) => String(node.id) === String(id));
}

function labelAtCanvasPoint(point) {
    const entries = Array.from(state.labelBoxes.entries()).reverse();
    for (const [id, box] of entries) {
        if (point.x >= box.x && point.x <= box.x + box.width && point.y >= box.y && point.y <= box.y + box.height) {
            return id;
        }
    }
    return null;
}

function installLabelDragging() {
    const canvas = $("network").querySelector("canvas");
    if (!canvas) return;

    const toCanvas = (event) => {
        const rect = canvas.getBoundingClientRect();
        return state.network.DOMtoCanvas({ x: event.clientX - rect.left, y: event.clientY - rect.top });
    };

    canvas.addEventListener("pointerdown", (event) => {
        if (state.layoutMode !== "manual") return;
        const point = toCanvas(event);
        const id = labelAtCanvasPoint(point);
        if (!id) return;
        const node = nodeById(id);
        if (!node) return;
        state.labelDrag = {
            id,
            start: point,
            startX: Number.isFinite(Number(node.label_offset_x)) ? Number(node.label_offset_x) : 0,
            startY: Number.isFinite(Number(node.label_offset_y)) ? Number(node.label_offset_y) : -64,
        };
        canvas.setPointerCapture?.(event.pointerId);
        event.preventDefault();
        event.stopImmediatePropagation();
    }, true);

    canvas.addEventListener("pointermove", (event) => {
        if (!state.labelDrag) return;
        const point = toCanvas(event);
        const node = nodeById(state.labelDrag.id);
        if (!node) return;
        node.label_offset_x = state.labelDrag.startX + (point.x - state.labelDrag.start.x);
        node.label_offset_y = state.labelDrag.startY + (point.y - state.labelDrag.start.y);
        state.network.redraw();
        event.preventDefault();
        event.stopImmediatePropagation();
    }, true);

    const finish = (event) => {
        if (!state.labelDrag) return;
        const drag = state.labelDrag;
        state.labelDrag = null;
        if (event.type === "pointerup") {
            const point = toCanvas(event);
            if (Math.hypot(point.x - drag.start.x, point.y - drag.start.y) < 5) showNode(drag.id);
        }
        canvas.releasePointerCapture?.(event.pointerId);
        event.preventDefault();
        event.stopImmediatePropagation();
    };
    canvas.addEventListener("pointerup", finish, true);
    canvas.addEventListener("pointercancel", finish, true);
}

function initNetwork() {
    state.network = new vis.Network($("network"), { nodes: state.nodes, edges: state.edges }, networkOptions("auto"));
    state.network.on("selectNode", (params) => showNode(params.nodes[0]));
    // Names are canvas cards, outside the icon hit area managed by vis.
    state.network.on("click", (params) => {
        if (params.nodes.length || !params.pointer?.canvas) return;
        const id = labelAtCanvasPoint(params.pointer.canvas);
        if (id !== null) {
            state.network.selectNodes([id]);
            showNode(id);
        }
    });
    state.network.on("selectEdge", (params) => {
        if (!params.nodes.length) showEdge(params.edges[0]);
    });
    state.network.on("deselectNode", () => clearSelection());
    state.network.on("afterDrawing", (ctx) => {
        drawEdgePortLabels(ctx);
        drawNodeLabels(ctx);
    });
    installLabelDragging();
}

function splitSummaryItems(value) {
    if (Array.isArray(value)) return value.map((item) => String(item).trim()).filter(Boolean);
    return String(value || "").split(",").map((item) => item.trim()).filter(Boolean);
}

function setSummarizedText(elementId, value, singularLabel = "Network", pluralLabel = "Networks", maxVisible = 2) {
    const el = $(elementId);
    const items = splitSummaryItems(value);
    if (!items.length) {
        el.textContent = "-";
        el.removeAttribute("title");
        return;
    }
    if (items.length <= maxVisible) {
        el.textContent = items.join(", ");
    } else {
        el.textContent = `${items.length} ${items.length === 1 ? singularLabel : pluralLabel}`;
    }
    el.title = items.join("\n");
}

function updateSummary(summary = {}) {
    $("routerCount").textContent = summary.router_count ?? 0;
    $("switchCount").textContent = summary.switch_count ?? 0;
    $("endDeviceCount").textContent = summary.end_device_count ?? 0;
    $("linkCount").textContent = summary.link_count ?? 0;
    $("filterRouterCount").textContent = summary.router_count ?? 0;
    $("filterSwitchCount").textContent = summary.switch_count ?? 0;
    $("filterEndCount").textContent = summary.end_device_count ?? 0;
    setSummarizedText("targetNetwork", summary.lan_networks ?? summary.target_network, "Network", "Networks", 2);
    const lanList = $("lanNetworkList");
    if (lanList) {
        lanList.replaceChildren(...splitSummaryItems(summary.lan_networks ?? summary.target_network).map(network => {
            const row = document.createElement("div");
            row.textContent = network;
            return row;
        }));
    }
    $("gatewayIp").textContent = summary.gateway_ip || "-";

    const networks = splitSummaryItems(summary.lan_networks ?? summary.target_network);
    $("targetBadge").textContent = networks.length > 2 ? `Networks: ${networks.length}` : `Network: ${networks.join(", ") || "-"}`;
    $("targetBadge").title = networks.join("\n");
    $("scanTime").textContent = summary.scan_time ? new Date(summary.scan_time).toLocaleString("th-TH") : "-";
    $("scanDuration").textContent = `${summary.scan_duration_seconds ?? 0}s`;
    $("cdpLinks").textContent = summary.cdp_links ?? 0;
    $("arpFdbLinks").textContent = summary.arp_fdb_links ?? 0;
}

function updateTable(devices) {
    const query = $("tableSearch").value.trim().toLowerCase();
    const filtered = devices.filter((row) => Object.values(row).join(" ").toLowerCase().includes(query));
    $("deviceTableBody").innerHTML = filtered.map((row) => `
        <tr data-node-id="${escapeHtml(row.id)}">
            <td>${escapeHtml(row.ip)}</td><td>${escapeHtml(row.hostname)}</td>
            <td>${escapeHtml(row.device_type)}</td><td>${escapeHtml(row.mac)}</td>
            <td>${escapeHtml(row.connected_to)}</td><td>${escapeHtml(row.port)}</td>
            <td>${escapeHtml(row.discovery)}</td>
        </tr>`).join("");

    document.querySelectorAll("#deviceTableBody tr").forEach((row) => {
        row.addEventListener("click", () => {
            const nodeId = row.dataset.nodeId;
            state.network.selectNodes([nodeId]);
            state.network.focus(nodeId, { scale: 1.15, animation: false });
            showNode(nodeId);
        });
    });
}

function updateChart(summary = {}) {
    const ctx = $("deviceChart");
    // Count both switch types in one slice. switch_count already includes L3
    // in server summaries, so never add layer3_switch_count to it again.
    const switchCount = Array.isArray(state.payload?.nodes)
        ? state.payload.nodes.filter(node => ["switch", "layer3_switch", "unmanaged_switch", "inferred_trunk_switch"].includes(node.device_type)).length
        : (summary.switch_count || 0);
    if (state.chart) state.chart.destroy();
    state.chart = new Chart(ctx, {
        type: "doughnut",
        data: {
            labels: ["Router", "Switch (L2 + L3)", "End Device"],
            datasets: [{ data: [summary.router_count || 0, switchCount, summary.end_device_count || 0], backgroundColor: [cssVar("--accent", "#556C8E"), cssVar("--mauve", "#97859D"), cssVar("--coral", "#FAA890")], borderColor: cssVar("--surface", "#fffaf8"), borderWidth: 3 }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: "right", labels: { color: cssVar("--text", "#556C8E"), boxWidth: 12, font: { size: 10 } } } },
            cutout: "58%",
        }
    });
}

function renderListView() {
    const target = $("listView");
    if (!target) return;
    target.innerHTML = (state.payload?.devices || []).map((row) => `
        <div class="device-list-card" data-node-id="${escapeHtml(row.id)}">
            <b>${escapeHtml(row.ip)}</b><span>${escapeHtml(row.hostname)}</span>
            <span>${escapeHtml(row.device_type)}</span><span>${escapeHtml(row.discovery)}</span>
        </div>`).join("");
}

function applyFilters(shouldFit = true) {
    const allowed = new Set([...document.querySelectorAll("[data-group]")].filter((el) => el.checked).map((el) => el.dataset.group));
    const query = $("nodeSearch").value.trim().toLowerCase();
    const visibleNodes = state.allNodes.filter((node) => {
        const group = nodeCategory(node);
        const matchesGroup = allowed.has(group);
        const matchesQuery = !query || JSON.stringify(node).toLowerCase().includes(query);
        return matchesGroup && matchesQuery;
    });
    const visibleIds = new Set(visibleNodes.map((node) => node.id));
    const visibleEdges = state.allEdges.filter((edge) => visibleIds.has(edge.from) && visibleIds.has(edge.to));
    const positions = state.layoutMode === "manual" ? currentVisiblePositions() : {};
    state.nodes.clear(); state.edges.clear();
    state.nodes.add(visibleNodes.map((node) => ({ ...node, ...nodeAppearance(node),
        ...(positions[node.id] ? { ...positions[node.id], physics: false } : {}) })));
    state.edges.add(visibleEdges);
    if (shouldFit) state.network.fit({ animation: false });
}

function detailRows(node) {
    const common = [
        ["Hostname", node.hostname], ["Device Type", node.display_type || node.device_type], ["IP Address", node.ip || node.management_ip],
        ["MAC Address", node.mac], ["Vendor", node.vendor], ["Model", node.model],
    ];
    if (node.inference_note) common.push(["Inference", node.inference_note]);
    if (node.catalog_model) common.push(["Catalog Model", node.catalog_model]);
    if (node.classification_source) common.push(["Device Classification", node.classification_source]);
    if (node.l3_capable) common.push(["L3 Capable", "Yes"]);
    if (["switch", "layer3_switch"].includes(node.device_type)) {
        common.push(["Routing", node.routing_enabled === true ? "Enabled" : (node.routing_enabled === false ? "Disabled" : "Unknown")]);
    }
    if (node.device_type === "router") common.push(["LAN Gateway", node.lan_ip]);
    if (["switch", "layer3_switch"].includes(node.device_type)) common.push(["Management Interface", node.management_interface], ["Uplink Port", node.uplink_port]);
    if (node.device_type === "unmanaged_switch") common.push(["Upstream Port", node.uplink_port], ["Downstream Devices", node.child_device_count]);
    if (node.device_type === "end_device") {
        common.push(["Connected Switch", node.connected_to], ["VLAN", node.vlan], ["Switch Port", node.port_known === false ? "Not available from SNMP" : node.switch_port]);
        if (node.observed_upstream_port) common.push(["Observed Upstream Port", node.observed_upstream_port], ["Connection", node.connection_status]);
        if (node.service_role) common.push(["Service Role", node.service_role]);
        if (node.service_identification) common.push(["Service Evidence", node.service_identification === "nmap-probe" ? "Nmap application probe" : "Open-port hint (ยังไม่ยืนยัน application)"]);
        if (Array.isArray(node.services) && node.services.length) {
            common.push(["Services", node.services.map((row) => `${row.port}/${row.protocol || "tcp"} ${row.service || "unknown"}`).join(", ")]);
        }
    }
    common.push(["Discovery", (node.discovery || []).join(" + ")]);
    return common.filter(([, value]) => value && value !== "-");
}

function showNode(nodeId) {
    const node = state.allNodes.find((item) => String(item.id) === String(nodeId));
    if (!node) return;
    if (node.credential_pending) {
        openCredentialPopup(node.credential_pending);
        return;
    }
    $("selectedEmpty").classList.add("hidden");
    $("selectedDevice").classList.remove("hidden");
    $("deviceName").textContent = node.hostname || node.ip || "Unknown";
    $("deviceSubtitle").textContent = node.ip || node.management_ip || node.device_type;
    const iconType = nodeIconType(node);
    const iconPath = themedIconPath(iconType);
    $("deviceIcon").innerHTML = `<img data-device-type="${escapeHtml(iconType)}" src="${iconPath}" alt="${escapeHtml(node.device_type)}">`;
    $("deviceDetails").innerHTML = detailRows(node).map(([key, value]) => `
        <div class="detail-row"><span>${escapeHtml(key)}</span><span>${escapeHtml(value)}</span></div>`).join("");

    const inventory = $("interfaceInventory");
    const interfaces = Array.isArray(node.interfaces) ? node.interfaces : [];
    if (interfaces.length && (["switch", "layer3_switch", "router"].includes(node.device_type))) {
        inventory.classList.remove("hidden");
        inventory.innerHTML = `<details class="info-block interface-details">
            <summary><small>Interfaces · กดดูทั้งหมด</small><strong>${interfaces.length} Interfaces</strong></summary>
            <div class="interface-list">${interfaces.map((intf) => {
            const ips = (intf.ip_addresses || []).map((row) => `${row.ip}${row.netmask ? " / " + row.netmask : ""}`).join("<br>") || "No IP";
            const mode = intf.switchport_mode && intf.switchport_mode !== "unknown" ? intf.switchport_mode : "";
            const vlan = intf.access_vlan ? `VLAN ${intf.access_vlan}${intf.access_vlan_name ? " (" + intf.access_vlan_name + ")" : ""}` : "";
            return `<div class="interface-row">
                <div><b>${escapeHtml(intf.name)}</b><small>ifIndex ${escapeHtml(intf.ifindex)}</small></div>
                <div><span>Admin: ${escapeHtml(intf.admin_status)}</span><span>Oper: ${escapeHtml(intf.status)}</span>${intf.nat_role ? `<span>NAT: ${escapeHtml(intf.nat_role)}</span>` : ""}${mode ? `<span>Mode: ${escapeHtml(mode)}</span>` : ""}${vlan ? `<span>Access: ${escapeHtml(vlan)}</span>` : ""}<span>${ips}</span></div>
            </div>`;
        }).join("")}
        ${(node.vlans || []).length ? `<h4>VLAN Database</h4><div class="interface-note">${(node.vlans || []).map((row) => `VLAN ${escapeHtml(row.vlan_id)} — ${escapeHtml(row.name)}`).join("<br>")}</div>` : ""}
        <p class="interface-note">${escapeHtml(node.interface_vlan_note || "Interface IP and status retrieved through IF-MIB/IP-MIB.")}</p>
            </div></details>`;
    } else {
        inventory.classList.add("hidden");
        inventory.innerHTML = "";
    }

    const evidence = node.evidence || (node.discovery || []).join(" + ");
    const confidence = node.confidence_percent || (node.device_type === "end_device" ? 95 : 100);
    $("evidencePanel").innerHTML = `<div class="evidence-card">
        <b>Source:</b> ${escapeHtml(evidence)}<br>
        <b>Confidence:</b> <span class="confidence">${escapeHtml(confidence)}%</span><br>
        <b>Reason:</b> ${node.inference_note ? escapeHtml(node.inference_note) : node.device_type === "end_device" ? "IP/MAC from Router ARP matched MAC/port from Switch FDB." : (node.device_type === "unmanaged_switch" ? "Multiple MAC addresses were learned on the same managed-switch port, so a downstream L2 device (switch, AP or bridge) is inferred; its type and downstream ports are unconfirmed." : "Device information retrieved through SNMP and neighbor relationship through CDP.")}
    </div>`;
}

function showEdge(edgeId) {
    const edge = state.allEdges.find((item) => String(item.id) === String(edgeId));
    if (!edge) return;
    $("evidencePanel").innerHTML = `<div class="evidence-card">
        <b>Relationship:</b> ${escapeHtml(edge.discovery)}<br>
        <b>${escapeHtml(edge.local_device || "Local")}:</b> ${escapeHtml(edge.local_interface)}<br>
        <b>${escapeHtml(edge.remote_device || "Remote")}:</b> ${escapeHtml(edge.remote_interface)}<br>
        <b>Confidence:</b> <span class="confidence">${escapeHtml(edge.confidence)}%</span>
    </div>`;
}

function clearSelection() {
    $("selectedEmpty").classList.remove("hidden");
    $("selectedDevice").classList.add("hidden");
}

function nodesWithSavedPositions(nodes, payload) {
    const positions = payload?.layout?.saved_positions || {};
    return nodes.map((node) => {
        const saved = positions[String(node.id)] || ((node.x !== undefined && node.y !== undefined) ? { x: node.x, y: node.y } : null);
        if (!saved) return { ...node };
        return {
            ...node,
            x: Number(saved.x),
            y: Number(saved.y),
            label_offset_x: saved.label_x === null || saved.label_x === undefined ? (node.label_offset_x ?? 0) : Number(saved.label_x),
            label_offset_y: saved.label_y === null || saved.label_y === undefined ? (node.label_offset_y ?? -64) : Number(saved.label_y),
            physics: false
        };
    });
}

function updateCredentialRequired(rows = state.credentialQueue) {
    state.credentialQueue = rows;
    const devices = new Set((state.payload?.nodes || [])
        .filter(node => node.device_type !== "pending_hop" && !node.credential_pending)
        .map(node => node.id));
    $("totalDevices").textContent = devices.size + rows.length;
    $("summaryHopCount").textContent = rows.length;
    if ($("credentialAlertButton")) {
        $("credentialAlertButton").classList.toggle("hidden", !rows.length);
        $("credentialAlertCount").textContent = rows.length;
        $("credentialAlertButton").title = `${rows.length} อุปกรณ์รอข้อมูลเพิ่มเติม — ใช้ SNMP หรือ SSH เพื่อสแกนต่อ`;
    }
    if ($("credentialRequiredCount")) $("credentialRequiredCount").textContent = rows.length;
    const target = $("credentialRequiredList");
    if (target) {
        if (!rows.length) {
            target.className = "credential-required-list empty-state";
            target.textContent = "ไม่มี Hop ที่รอสแกนต่อ";
        } else {
            target.className = "credential-required-list";
            target.innerHTML = rows.map((row, index) => `
                <button class="credential-required-item credential-open" type="button" data-credential-index="${index}">
                    <b>${escapeHtml(row.hostname || row.ip)}</b>
                    <span>${escapeHtml(row.ip || "No management IP")}</span>
                    <small>${escapeHtml(row.protocol || "Neighbor")} · from ${escapeHtml(row.source_device || "-")}</small>
                    <small>พอร์ต ${escapeHtml(row.local_interface || "-")} · กรอกข้อมูลเพิ่มเติม (SNMP / SSH)</small>
                </button>`).join("");
            target.querySelectorAll("[data-credential-index]").forEach((button) => {
                button.addEventListener("click", () => openCredentialPopup(rows[Number(button.dataset.credentialIndex)]));
            });
        }
    }
}

function updateUnlocatedServices(metadata = {}) {
    const rows = [...new Map([...(metadata.unlocated_endpoints || []), ...(metadata.unlocated_services || [])]
        .map(row => [row.ip || row.id, row])).values()];
    if ($("unlocatedServiceCount")) $("unlocatedServiceCount").textContent = rows.length;
    const target = $("unlocatedServiceList");
    if (!target) return;
    target.className = rows.length ? "unlocated-service-list" : "empty-state";
    target.innerHTML = rows.length ? rows.map(row => `<div class="info-block">
        <strong>${escapeHtml(row.ip)}</strong><small>${escapeHtml(row.mac || "")}</small><div>${escapeHtml(row.role || "ยังระบุพอร์ตเชื่อมต่อไม่ได้")}</div>
        <small>${escapeHtml((row.services || []).map(service => `${service.port}/${service.protocol || "tcp"}`).join(", "))}</small>
        </div>`).join("") : "ไม่มีรายการ";
}

function openCredentialPopup(row) {
    if (!row) return;
    $("credentialHopSelect").innerHTML = state.credentialQueue.map((item) =>
        `<option value="${escapeHtml(item.key || item.ip)}">${escapeHtml(item.hostname || item.ip)} · ${escapeHtml(item.ip || "ต้องระบุ IP")} · จาก ${escapeHtml(item.source_device || "-")}</option>`
    ).join("");
    $("credentialHopSelect").value = row.key || row.ip;
    $("credentialTargetIp").value = row.address_conflict ? "" : (row.ip || "");
    $("credentialTargetName").textContent = row.hostname || row.ip;
    $("credentialTargetMeta").textContent = `${row.ip} · ${row.protocol || "Neighbor"} · from ${row.source_device || "-"}`;
    $("credentialTargetReason").textContent = row.reason || "กรอก IP และ Credential ของ Hop นี้เพื่อค้นหาอุปกรณ์ถัดไป";
    $("hopSnmpCommunity").value = "";
    $("hopSshEnabled").checked = false;
    $("hopSshUsername").value = "";
    $("hopSshPassword").value = "";
    $("hopSshPort").value = 22;
    $("hopSshDeviceType").value = "auto";
    $("credentialQueueSummary").textContent = `${state.credentialQueue.length} device${state.credentialQueue.length === 1 ? "" : "s"} waiting`;
    $("credentialModal").classList.remove("hidden");
    $("credentialModal").setAttribute("aria-hidden", "false");
    $(row.ip && !row.address_conflict ? "hopSnmpCommunity" : "credentialTargetIp").focus();
}

function closeCredentialPopup() {
    $("credentialModal").classList.add("hidden");
    $("credentialModal").setAttribute("aria-hidden", "true");
}

async function continueCredentialHop() {
    const ip = $("credentialTargetIp").value.trim();
    const community = $("hopSnmpCommunity").value.trim();
    const sshEnabled = $("hopSshEnabled").checked;
    const username = $("hopSshUsername").value.trim();
    if (!ip) { toast("กรอก Management IP ของ Hop ก่อนสแกนต่อ"); return; }
    if (!community && !(sshEnabled && username)) {
        toast("กรอก SNMP Community หรือเปิด SSH พร้อม Username ก่อน");
        return;
    }
    const button = $("credentialContinueButton");
    button.disabled = true;
    setOperationStatus("กำลังสแกน Hop ต่อไป...", "working");
    try {
        const response = await fetch("/api/scan/continue", {
            method: "POST",
            cache: "no-store",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                scan_level: state.scanLevel,
                root_ip: ip,
                neighbor_key: $("credentialHopSelect").value,
                connection_mode: "auto",
                snmp: { community },
                ssh: {
                    enabled: sshEnabled, username, password: $("hopSshPassword").value,
                    port: Number($("hopSshPort").value || 22), device_type: $("hopSshDeviceType").value || "auto",
                },
            }),
        });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.error || "Cannot continue discovery");
        closeCredentialPopup();
        setDiscoveryStatus(data);
        try {
            loadPayload(data);
        } catch (renderError) {
            console.error("Continued topology render warning:", renderError);
            toast("สแกนต่อสำเร็จ แต่บางส่วนของ Dashboard แสดงผลไม่ครบ");
            return;
        }
        toast(`Discovery continued from ${ip}`);
    } catch (error) {
        console.error(error);
        setOperationStatus("ตรวจสอบข้อมูลเพิ่มเติม", "error");
        toast(error.message);
    } finally { button.disabled = false; }
}

// Pending hops are presentation nodes, replaced by actual discovery on resume.
function pendingHopRows(payload) {
    const nodes = payload.nodes || [];
    const seen = new Set();
    const rows = Array.isArray(payload.metadata?.credential_required) ? payload.metadata.credential_required : [];
    return rows.filter(row => {
        if (row.neighbor_kind === "endpoint") return false;
        const resolved = nodes.some(node => !node.credential_pending && node.device_type !== "pending_hop"
            && row.ip && [node.ip, node.management_ip, ...(node.management_ips || [])].includes(row.ip));
        if (resolved && !row.address_conflict) return false;
        const key = row.address_conflict ? (row.key || row.ip) : (row.ip || row.key);
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
    });
}

function withPendingHops(payload, pendingRows = pendingHopRows(payload)) {
    // Older exports may contain repeated IDs; vis.DataSet rejects the whole
    // batch in that case, leaving the map blank until endpoints are hidden.
    const nodes = [...new Map((payload.nodes || []).map(node => [node.id, node])).values()];
    const edges = [...new Map((payload.edges || []).map((edge, index) => [edge.id ?? `edge:${index}`, edge])).values()];
    for (const row of pendingRows) {
        if (row.neighbor_kind === "endpoint") continue;
        const matchesIp = (node, ip) => ip && [node.ip, node.management_ip, ...(node.management_ips || [])].includes(ip);
        const existing = nodes.find((node) => matchesIp(node, row.ip));
        if (existing && !existing.credential_pending && !row.address_conflict) continue;
        const sources = nodes.filter((node) => !node.credential_pending && (row.source_ip ? matchesIp(node, row.source_ip) :
            node.hostname === row.source_device || matchesIp(node, row.source_device)));
        const source = sources.length === 1 ? sources[0] : null;
        const id = existing?.credential_pending && !row.address_conflict ? existing.id : `pending-hop:${row.key || row.ip}`;
        if (!nodes.some(node => node.id === id)) nodes.push({ id, ip: row.ip, hostname: row.hostname || row.ip,
            display_name: row.hostname || row.ip, display_type: "Hop รอสแกนต่อ",
            device_type: "pending_hop", group: "unknown", icon_type: "unknown", shape: "image", size: 40,
            level: source ? (source.level || 0) + 1 : Number(row.hop_depth || 0),
            discovery: [row.protocol || "Neighbor"], credential_pending: row,
            title: `${row.ip} · ${row.protocol || "Neighbor"} · กรอกข้อมูลเพิ่มเติมด้วย SNMP หรือ SSH เพื่อสแกนต่อ` });
        // A route next hop proves reachability information, not a physical link.
        if (source && /^(cdp|lldp)$/i.test(row.protocol || "")) edges.push({
            id: `pending-link:${row.key || row.ip}`, from: source.id, to: id,
            relation: "pending_neighbor", discovery: row.protocol,
            local_interface: row.local_interface, remote_interface: row.remote_interface,
            dashes: true, width: 3, color: { color: "#e88a14", highlight: "#e88a14" }, label: "",
        });
    }
    return { nodes, edges };
}

function loadPayload(payload) {
    state.payload = payload;
    const pendingRows = pendingHopRows(payload);
    // Update every hop counter and the list from one snapshot, before graph
    // rendering can fail or a layout operation can update other summaries.
    updateCredentialRequired(pendingRows);
    updateSummary(payload.summary || {});
    state.hasSavedLayout = Boolean(payload?.layout?.has_saved_layout) || (payload.nodes || []).some((node) => node.x !== undefined && node.y !== undefined);
    const graph = withPendingHops(payload, pendingRows);
    // vis hierarchical layout requires a level on either every node or none.
    const lastLevel = Math.max(0, ...graph.nodes.map((node) => Number.isFinite(node.level) ? node.level : 0));
    graph.nodes = graph.nodes.map((node) => ({ ...node,
        level: Number.isFinite(node.level) ? node.level : lastLevel + 1 }));
    const rootIp = payload.metadata?.root_ip || payload.metadata?.requested_root_ips?.[0];
    const rootNode = graph.nodes.find((node) => node.is_root === true)
        || graph.nodes.find((node) => rootIp && node.device_type !== "internet_cloud" &&
        [node.ip, node.management_ip, String(node.id)].includes(rootIp))
        || graph.nodes.find((node) => node.level === 0 && node.device_type !== "internet_cloud")
        || graph.nodes.find((node) => node.device_type !== "internet_cloud");
    graph.nodes = graph.nodes.map((node) => ({ ...node, is_root: node.id === rootNode?.id }));
    state.allNodes = nodesWithSavedPositions(graph.nodes, payload).map((node) => ({
        ...node,
        ...nodeAppearance(node),
        label_offset_x: node.label_offset_x ?? 0,
        label_offset_y: node.label_offset_y ?? -64,
    }));
    // V4.20: never render text in the middle of a link. Port ownership is
    // shown only by the endpoint cards drawn beside each device.
    state.allEdges = graph.edges.map((edge) => ({ ...edge, label: "" }));

    state.layoutMode = state.hasSavedLayout ? "manual" : "auto";
    state.network.setOptions(networkOptions(state.layoutMode));
    state.nodes.clear(); state.edges.clear();
    applyFilters(false);
    updateLayoutButtons();
    window.setTimeout(() => state.network.fit({ animation: true }), 150);

    updateSummary(payload.summary || {});
    updateUnlocatedServices(payload.metadata || {});
    updateTable(payload.devices || []);
    updateChart(payload.summary || {});
    renderListView();
    const serviceStatus = $("serviceScanStatus");
    if (serviceStatus) {
        const meta = payload.metadata || {};
        const report = meta.service_scan || {};
        serviceStatus.textContent = meta.service_target_count === undefined ? "" :
            `Service Scan: ${meta.service_target_count} IP · พบ ${meta.service_endpoint_count || 0} อุปกรณ์` +
            (meta.service_target_count === 0 ? " · ไม่มี IP จาก ARP/Neighbor ให้ตรวจสอบ service" : "") +
            (report.errors?.length ? ` · ${report.errors.join("; ")}` : "");
    }

}

async function saveCurrentLayout({ silent = false } = {}) {
    if (!state.network || !state.allNodes.length) return;
    const ids = state.allNodes.map((node) => node.id).filter((id) => state.nodes.get(id));
    const positions = state.network.getPositions(ids);
    state.allNodes.forEach((node) => {
        if (!positions[node.id]) return;
        positions[node.id] = {
            ...positions[node.id],
            label_x: Number.isFinite(Number(node.label_offset_x)) ? Number(node.label_offset_x) : 0,
            label_y: Number.isFinite(Number(node.label_offset_y)) ? Number(node.label_offset_y) : -64,
        };
    });
    try {
        const response = await fetch("/api/layout", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ positions })
        });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.error || "Cannot save layout");
        state.hasSavedLayout = true;
        // Keep current coordinates in local node objects as well, so filtering does not lose them.
        state.allNodes = state.allNodes.map((node) => positions[node.id] ? { ...node, ...positions[node.id], physics: false } : node);
        // Change the real network mode now, not only the toolbar state.
        setManualLayout({ notify: false });
        if (!silent) toast(`Layout saved (${data.saved} nodes)`);
    } catch (error) {
        console.error(error);
        if (!silent) toast(error.message);
    }
}

async function resetLayout() {
    try {
        const response = await fetch("/api/layout", { method: "DELETE" });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.error || "Cannot reset layout");

        state.hasSavedLayout = false;
        state.allNodes = state.allNodes.map((node) => {
            const copy = { ...node };
            delete copy.x;
            delete copy.y;
            delete copy.fixed;
            delete copy.physics;
            delete copy.layout_saved;
            copy.label_offset_x = 0;
            copy.label_offset_y = -64;
            return copy;
        });
        runAutoLayout({ notify: false });
        toast("Layout reset และจัด Topology ใหม่แล้ว");
    } catch (error) {
        console.error(error);
        toast(error.message);
    }
}

async function importTopology(file) {
    if (!file) return;
    const form = new FormData();
    form.append("file", file);
    setOperationStatus("Importing...", "working");
    try {
        const response = await fetch("/api/import", { method: "POST", body: form });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.error || "Cannot import topology");
        setOperationStatus("Imported", "imported");
        // Import is complete once the API accepts the file. A rendering error
        // must not misreport an already imported topology as an import failure.
        try {
            loadPayload(data);
        } catch (renderError) {
            console.error("Imported topology render warning:", renderError);
            toast("Import สำเร็จ แต่บางส่วนของ Dashboard แสดงผลไม่ครบ");
            return;
        }
        toast(`Imported: ${data.filename}`);
    } catch (error) {
        console.error(error);
        setOperationStatus("Import Failed", "error");
        toast(error.message);
    } finally {
        $("importTopologyFile").value = "";
    }
}

function scanLevelLabel(level) {
    return ({ topology: "Topology", full: "Full Scan" })[level] || "Full Scan";
}

function buildScanRequest() {
    const settings = state.discoverySettings;
    const body = {
        scan_level: state.scanLevel,
        connection_mode: settings.connectionMode,
        root_ips: [String(settings.rootNodeIps || "").trim()],
        ssh: {
            enabled: Boolean(settings.sshEnabled),
            username: settings.sshUsername,
            password: settings.sshPassword,
            port: Number(settings.sshPort || 22),
            device_type: settings.sshDeviceType || "auto",
        },
    };
    body.snmp = { community: settings.snmpCommunity || "" };
    return body;
}

async function fetchDashboard(scan = false) {
    const button = $("scanStartButton");
    button.disabled = true;
    setOperationStatus(scan ? `${scanLevelLabel(state.scanLevel)}...` : "Loading...", "working");
    if (scan) {
        // A fresh scan must never appear to reuse an old topology, including
        // when a new scan fails or takes a long time to complete.
        try { loadPayload({nodes: [], edges: [], metadata: {source: "idle", credential_required: []}, summary: {}}); }
        catch (error) { console.warn("Could not clear previous topology", error); }
    }
    try {
        const response = await fetch(scan ? "/api/scan" : "/api/dashboard", {
            method: scan ? "POST" : "GET",
            cache: "no-store",
            headers: scan ? { "Content-Type": "application/json" } : {},
            body: scan ? JSON.stringify(buildScanRequest()) : undefined,
        });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.error || "Cannot load dashboard");

        // The HTTP/API result is the scan result. Rendering is a separate UI
        // concern: a chart/list exception must never turn a completed network
        // scan into the red "Scan Failed" badge after the topology is visible.
        if (scan) setDiscoveryStatus(data);
        else if (data.metadata?.source === "import") setOperationStatus("Imported", "imported");
        else if (data.metadata?.credential_required?.length) setDiscoveryStatus(data);
        else setOperationStatus(data.summary?.total_devices ? "Loaded" : "Ready", data.summary?.total_devices ? "success" : "ready");

        try {
            loadPayload(data);
        } catch (renderError) {
            console.error("Dashboard render warning:", renderError);
            if (scan) toast("Scan completed; some dashboard widgets could not refresh");
            else toast("Topology loaded; some dashboard widgets could not refresh");
            return;
        }
        if (scan) {
            toast(data.metadata?.credential_required?.length ? "เลือก Hop เพื่อกรอกข้อมูลเพิ่มเติมด้วย SNMP หรือ SSH แล้วสแกนต่อ" : "Scan completed successfully");
        }
    } catch (error) {
        console.error(error);
        setOperationStatus(scan ? "Scan Failed" : "Load Failed", "error");
        toast(error.message);
    } finally { button.disabled = false; }
}

function updateScanLevel(level) {
    state.scanLevel = level;
    document.querySelectorAll("[data-scan-level]").forEach((button) => {
        button.classList.toggle("active", button.dataset.scanLevel === level);
    });
    const hints = {
        topology: "Topology Scan จะเน้น Router / Switch และ Neighbor ก่อน เพื่อลดเวลาสแกน",
        full: "Full Scan ตรวจ Service เฉพาะ IP จาก ARP/FDB และ Neighbor โดยไม่ไล่สแกนทั้ง Subnet",
    };
    $("scanModeHint").textContent = hints[level] || hints.full;
    if ($("scanSelectionSummary")) $("scanSelectionSummary").textContent = `${scanLevelLabel(level)} · Ready`;
}

function updateSettingsSummary() {
    const s = state.discoverySettings;
    const parts = [s.connectionMode.toUpperCase()];
    parts.push(s.snmpCommunity ? "SNMP configured" : "SNMP not set");
    if (s.sshEnabled) parts.push(`SSH ${s.sshUsername || "enabled"}`);
    $("settingsSummary").textContent = parts.join(" · ");
}

function openSettings() {
    const s = state.discoverySettings;
    $("snmpCommunity").value = s.snmpCommunity;
    $("sshEnabled").checked = s.sshEnabled;
    $("sshUsername").value = s.sshUsername;
    $("sshPassword").value = s.sshPassword;
    $("sshPort").value = s.sshPort;
    $("sshDeviceType").value = s.sshDeviceType;
    document.querySelectorAll("[data-connection-mode]").forEach((button) => {
        button.classList.toggle("active", button.dataset.connectionMode === s.connectionMode);
    });
    $("settingsModal").classList.remove("hidden");
    $("settingsModal").setAttribute("aria-hidden", "false");
}

function closeSettings() {
    $("settingsModal").classList.add("hidden");
    $("settingsModal").setAttribute("aria-hidden", "true");
}

function applySettings() {
    const activeMode = document.querySelector("[data-connection-mode].active")?.dataset.connectionMode || "auto";
    state.discoverySettings = {
        connectionMode: activeMode,
        snmpCommunity: $("snmpCommunity").value.trim(),
        sshEnabled: $("sshEnabled").checked,
        sshUsername: $("sshUsername").value.trim(),
        sshPassword: $("sshPassword").value,
        sshPort: Number($("sshPort").value || 22),
        sshDeviceType: $("sshDeviceType").value || "auto",
        rootNodeIps: state.discoverySettings.rootNodeIps,
    };
    if (state.discoverySettings.connectionMode === "ssh" && !state.discoverySettings.sshUsername) {
        toast("SSH mode requires a username");
        return;
    }
    updateSettingsSummary();
    closeSettings();
    toast("Discovery settings applied for the next scan");
}

function openScanOptions() {
    const root = state.allNodes.find((node) => node.is_root);
    $("rootNodeIps").value = state.discoverySettings.rootNodeIps
        || state.payload?.metadata?.requested_root_ips?.[0]
        || state.payload?.metadata?.root_ip
        || root?.ip || root?.management_ip || "";
    $("scanModal").classList.remove("hidden");
    $("scanModal").setAttribute("aria-hidden", "false");
    $("rootNodeIps").focus();
}

async function useGatewayAsRoot() {
    const button = $("useGatewayButton");
    button.disabled = true;
    $("rootGatewayHint").textContent = "กำลังค้นหา Default Gateway…";
    try {
        const response = await fetch("/api/network/gateway");
        const data = await response.json();
        if (!response.ok || !data.gateway_ip) throw new Error(data.error || "ไม่พบ Default Gateway กรุณาระบุ Root IP เอง");
        $("rootNodeIps").value = data.gateway_ip;
        $("rootGatewayHint").textContent = `อิงจาก Default Gateway: ${data.gateway_ip} · กด Start Discovery เพื่อเริ่มค้นหา`;
    } catch (error) {
        $("rootGatewayHint").textContent = error.message;
    } finally {
        button.disabled = false;
    }
}

function closeScanOptions() {
    $("scanModal").classList.add("hidden");
    $("scanModal").setAttribute("aria-hidden", "true");
}

function scheduleSearchFilter() {
    window.clearTimeout(state.searchTimer);
    state.searchTimer = window.setTimeout(() => {
        state.searchTimer = null;
        applyFilters();
    }, 200);
}


applyTheme(localStorage.getItem("netmap-theme") || "pastel", false);
if ($("themeSelect")) $("themeSelect").addEventListener("change", (event) => applyTheme(event.target.value));
initNetwork();
document.querySelectorAll("[data-scan-level]").forEach((button) => button.addEventListener("click", () => updateScanLevel(button.dataset.scanLevel)));
$("scanOptionsButton").addEventListener("click", openScanOptions);
$("credentialAlertButton").addEventListener("click", () => {
    const first = state.credentialQueue[0];
    if (first) openCredentialPopup(first);
});
$("credentialHopSelect").addEventListener("change", (event) => {
    const row = state.credentialQueue.find((item) => (item.key || item.ip) === event.target.value);
    if (row) openCredentialPopup(row);
});
$("useGatewayButton").addEventListener("click", useGatewayAsRoot);
$("scanCloseButton").addEventListener("click", closeScanOptions);
$("scanCancelButton").addEventListener("click", closeScanOptions);
$("scanStartButton").addEventListener("click", async () => {
    const roots = $("rootNodeIps").value.trim();
    if (!/^(?:0|[1-9]\d{0,2})(?:\.(?:0|[1-9]\d{0,2})){3}$/.test(roots)
        || roots.split(".").some((part) => Number(part) > 255)) {
        toast("กรุณากรอก Root / Seed IPv4 ให้ถูกต้องเพียง 1 IP");
        $("rootNodeIps").focus();
        return;
    }
    state.discoverySettings.rootNodeIps = roots;
    closeScanOptions();
    await fetchDashboard(true);
});
$("scanModal").addEventListener("click", (event) => { if (event.target === $("scanModal")) closeScanOptions(); });
$("saveLayoutButton").addEventListener("click", () => saveCurrentLayout());
$("resetLayoutButton").addEventListener("click", resetLayout);
$("manualLayoutButton").addEventListener("click", () => setManualLayout());
$("autoLayoutButton").addEventListener("click", () => runAutoLayout());
$("importButton").addEventListener("click", () => $("importTopologyFile").click());
$("importTopologyFile").addEventListener("change", (event) => importTopology(event.target.files[0]));
$("tableSearch").addEventListener("input", () => updateTable(state.payload?.devices || []));

$("nodeSearch").addEventListener("input", scheduleSearchFilter);
document.querySelectorAll("[data-group]").forEach((el) => el.addEventListener("change", () => {
    window.clearTimeout(state.searchTimer);
    state.searchTimer = null;
    applyFilters();
}));
$("settingsButton").addEventListener("click", openSettings);
$("settingsCloseButton").addEventListener("click", closeSettings);
$("settingsCancelButton").addEventListener("click", closeSettings);
$("settingsApplyButton").addEventListener("click", applySettings);
$("settingsModal").addEventListener("click", (event) => { if (event.target === $("settingsModal")) closeSettings(); });
$("credentialCloseButton").addEventListener("click", closeCredentialPopup);
$("credentialSkipButton").addEventListener("click", closeCredentialPopup);
$("credentialContinueButton").addEventListener("click", continueCredentialHop);
$("credentialModal").addEventListener("click", (event) => { if (event.target === $("credentialModal")) closeCredentialPopup(); });
document.querySelectorAll("[data-connection-mode]").forEach((button) => button.addEventListener("click", () => {
    document.querySelectorAll("[data-connection-mode]").forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
}));
document.querySelectorAll("[data-reveal]").forEach((button) => button.addEventListener("click", () => {
    const input = $(button.dataset.reveal);
    const reveal = input.type === "password";
    input.type = reveal ? "text" : "password";
    button.textContent = reveal ? "Hide" : "Show";
}));
document.addEventListener("keydown", (event) => {
    if (event.key !== "Escape") return;
    if (!$("settingsModal").classList.contains("hidden")) closeSettings();
    if (!$("scanModal").classList.contains("hidden")) closeScanOptions();
    if (!$("credentialModal").classList.contains("hidden")) closeCredentialPopup();
});
updateScanLevel("topology");
updateSettingsSummary();
fetchDashboard(false);
