"""V4 BFS discovery core.

The queue contains only SNMP network devices. CDP/LLDP recursively discover direct
neighbors. Router interfaces/routes only expand scan scope; they never create
edges. Full Scan obtains endpoint candidates from device tables and never
performs a subnet sweep.
"""

import ipaddress
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, Set
from time import perf_counter

from system_settings import (
    DISCOVERY_WORKERS,
    MAX_DISCOVERED_NETWORKS,
    MAX_DISCOVERY_DEPTH,
    MAX_HOSTS_PER_NETWORK,
    PRIVATE_NETWORKS_ONLY,
)
from scanner.device_profiler import build_device_profile
from scanner.network_expander import networks_from_profile
from scanner.snmp_probe import responds_to_snmp
from scanner.ssh_collector import build_ssh_device_profile, _tcp_port_open
from scanner.infrastructure_discovery import find_arp_snmp_candidates
from topology.device_identity import make_device_identity


def _identity(profile: Dict[str, object]) -> str:
    """Use management IP as the primary identity.

    Cloned GNS3 IOSvL2 nodes can share sysObjectID and bridge MAC, so neither
    value may be used alone for deduplication.
    """
    return make_device_identity(profile)


def _safe_network(text: str) -> bool:
    try:
        network = ipaddress.ip_network(text, strict=False)
    except ValueError:
        return False
    if network.version != 4:
        return False
    if PRIVATE_NETWORKS_ONLY and not network.is_private:
        return False
    return network.num_addresses <= MAX_HOSTS_PER_NETWORK




def _point_to_point_peer_ips(profile: Dict[str, object]):
    """Return the opposite host on directly connected /30 or /31 links.

    This is a cheap discovery fallback for routed point-to-point links.  It
    avoids an Nmap subnet sweep and is especially useful when CDP/LLDP omits a
    management address.  The returned IP is only queued for SNMP/SSH probing;
    it is NOT used as topology-link evidence.  Physical edges still require
    CDP/LLDP.
    """
    peers = set()
    for row in profile.get("ip_addresses") or []:
        ip_value = str(row.get("ip") or "").strip()
        netmask = str(row.get("netmask") or "").strip()
        if not ip_value or not netmask:
            continue
        try:
            interface = ipaddress.ip_interface("{}/{}".format(ip_value, netmask))
            network = interface.network
        except ValueError:
            continue
        if network.version != 4 or network.prefixlen not in {30, 31}:
            continue
        if PRIVATE_NETWORKS_ONLY and not network.is_private:
            continue
        for host in network.hosts():
            candidate = str(host)
            if candidate != ip_value:
                peers.add(candidate)
    return sorted(peers)

def _merge_profile(existing: Dict[str, object], new: Dict[str, object]) -> None:
    """Merge observations that belong to the same logical device.

    This is especially important for routers: the same router may be probed
    through several interface IP addresses discovered from route/network scans.
    """
    ips = set(existing.get("management_ips") or [])
    ips.update(new.get("management_ips") or [])
    for profile in (existing, new):
        if profile.get("query_ip"):
            ips.add(str(profile["query_ip"]))
        for row in profile.get("ip_addresses") or []:
            if row.get("ip"):
                ips.add(str(row["ip"]))
    existing["management_ips"] = sorted(ips)
    for field in ("interfaces", "interface_details"):
        if isinstance(existing.get(field), dict) and isinstance(new.get(field), dict):
            existing[field] = {**new[field], **existing[field]}

    # Keep the richest identity text seen across aliases. A device can be
    # reached through several interface IPs; one partial response must not
    # leave Vendor/Model as Unknown when another response had sysDescr/OID.
    for field in ("hostname", "description", "object_id", "model", "hardware_model", "platform"):
        old = str(existing.get(field) or "").strip()
        fresh = str(new.get(field) or "").strip()
        if (not old or old.lower() in {"unknown", "none", "n/a", "-"}) and fresh:
            existing[field] = new.get(field)

    def merge_rows(field: str, key_fields):
        merged = {}
        for row in list(existing.get(field) or []) + list(new.get(field) or []):
            key = tuple(str(row.get(name) or "") for name in key_fields)
            if field in {"cdp_neighbors", "lldp_neighbors"}:
                key += (str(row.get("local_port") or row.get("local_interface") or ""),
                        str(row.get("remote_port") or row.get("remote_interface") or ""))
            merged[key] = row
        existing[field] = list(merged.values())

    merge_rows("cdp_neighbors", ("local_ifindex", "remote_device", "management_ip"))
    merge_rows("lldp_neighbors", ("local_ifindex", "remote_device", "management_ip"))
    merge_rows("ip_addresses", ("ip", "netmask", "ifindex"))
    merge_rows("route_networks", ("network", "next_hop", "ifindex"))
    merge_rows("arp_entries", ("ip", "mac", "ifindex"))

    # Preserve the configured/root query IP as the preferred display address.
    if existing.get("discovered_by") != "configured-root" and new.get("discovered_by") == "configured-root":
        existing["query_ip"] = new.get("query_ip")
        existing["discovered_by"] = "configured-root"


def discover_recursive(
    scan_level: str = "full",
    community: str = "",
    connection_mode: str = "auto",
    ssh: Dict[str, object] = None,
    root_ips=None,
    credential_profiles=None,
    known_devices=None,
    resume=False,
    skip_ips=None,
) -> Dict[str, object]:
    """Discover network devices using SNMP first with optional SSH fallback.

    scan_level:
      topology - fastest; follows CDP/LLDP neighbor relationships and avoids
                 broad subnet host sweeps plus end-device enrichment.
      full     - topology discovery plus ARP/FDB endpoint candidates and
                 targeted service scans; never sweep whole subnets.
    """
    scan_level = str(scan_level or "full").strip().lower()
    if scan_level not in {"topology", "full"}:
        scan_level = "full"
    connection_mode = str(connection_mode or "auto").strip().lower()
    if connection_mode not in {"auto", "snmp", "ssh"}:
        connection_mode = "auto"
    ssh = dict(ssh or {})
    ssh_enabled = bool(ssh.get("enabled") and ssh.get("username"))

    # One credential set per scan branch. A different community requires
    # selecting that neighbor and entering its information explicitly.
    # Ignore legacy credential_profiles payloads rather than auto-interleaving.
    profiles = [{"name": "Current hop", "snmp_community": community, "ssh": ssh}]

    # Deduplicate secrets and try SNMP profiles before SSH fallback. This
    # avoids repeating slow SSH negotiations for every wrong SNMP community.
    snmp_profiles = []
    ssh_profiles = []
    seen_snmp, seen_ssh = set(), set()
    for credential in profiles:
        secret = str(credential.get("snmp_community") or "").strip()
        if secret and secret not in seen_snmp:
            snmp_profiles.append((secret, credential))
            seen_snmp.add(secret)
        account = dict(credential.get("ssh") or {})
        ssh_key = tuple(str(account.get(k) or "") for k in ("username", "password", "port", "device_type"))
        if account.get("enabled") and account.get("username") and ssh_key not in seen_ssh:
            ssh_profiles.append((account, credential))
            seen_ssh.add(ssh_key)

    collection_timings = {}

    def collect_profile(ip: str):
        started = perf_counter()
        try:
            return collect_device(ip)
        finally:
            collection_timings[ip] = round(perf_counter() - started, 3)

    def collect_device(ip: str):
        from scanner.snmp import snmp_session
        last_ssh_error = None
        with snmp_session(retries=0 if resume else None):
            if connection_mode in {"auto", "snmp"}:
                for secret, credential in snmp_profiles:
                    try:
                        if not responds_to_snmp(ip, secret):
                            continue
                        result = build_device_profile(ip, secret, scan_level=scan_level, **({"neighbor_only": True} if resume else {}))
                        result["access_method"] = "SNMP"
                        result["credential_profile"] = credential.get("name") or "SNMP profile"
                        result["_snmp_community"] = secret
                        return result
                    except Exception:
                        continue
            if connection_mode in {"auto", "ssh"}:
                for account, credential in ssh_profiles:
                    # When SNMP fails on a neighbor and TCP/SSH is closed,
                    # avoid a full Netmiko negotiation + legacy fallback.
                    # SSH-only mode keeps its original connection behavior.
                    if connection_mode == "auto" and not _tcp_port_open(
                            ip, int(account.get("port") or 22), timeout=0.6):
                        continue
                    try:
                        result = build_ssh_device_profile(ip, account, scan_level=scan_level, **({"neighbor_only": True} if resume else {}))
                        result["access_method"] = "SSH"
                        result["credential_profile"] = credential.get("name") or "SSH profile"
                        return result
                    except Exception as exc:
                        last_ssh_error = exc
        if connection_mode == "ssh" and last_ssh_error is not None:
            raise last_ssh_error
        return None

    requested_roots = []
    for value in list(root_ips or []):
        value = str(value or "").strip()
        if value and value not in requested_roots:
            requested_roots.append(value)
    if not requested_roots:
        raise ValueError("Root / Seed IP is required. Enter it in Scan Options before scanning.")

    root_entries = []
    root_errors = []
    for root_ip in requested_roots:
        try:
            root_profile = collect_profile(root_ip)
        except Exception as exc:
            root_profile = None
            root_errors.append("{}: {}".format(root_ip, exc))
        if root_profile is not None:
            root_entries.append((root_ip, 0, "configured-root", root_profile))
        else:
            root_errors.append("{}: inaccessible".format(root_ip))

    if not root_entries:
        detail = "; ".join(root_errors) if root_errors else "no reachable root device"
        if connection_mode == "snmp":
            raise RuntimeError("None of the Root IPs answer SNMP with the supplied community ({})".format(detail))
        if connection_mode == "ssh":
            raise RuntimeError("None of the Root IPs could be accessed by SSH ({})".format(detail))
        raise RuntimeError("None of the Root IPs are accessible by SNMP or the supplied SSH credentials ({})".format(detail))

    active_root_ips = [entry[0] for entry in root_entries]
    skipped_ips = set(str(ip) for ip in (skip_ips or [])) - set(active_root_ips)
    device_queue = deque(root_entries)
    queued_device_ips: Set[str] = set(active_root_ips)
    visited_query_ips: Set[str] = set()
    visited_networks: Set[str] = set()
    profiles_by_identity: Dict[str, Dict[str, object]] = {}
    identity_by_ip: Dict[str, str] = {}
    ambiguous_ips: Set[str] = set()
    scan_scope: Dict[str, Dict[str, object]] = {}
    discovered_hosts: Dict[str, Dict[str, str]] = {}
    credential_required: Dict[str, Dict[str, object]] = {}
    candidate_hints: Dict[str, Dict[str, object]] = {}
    arp_checked_ips = set()
    for root_ip in requested_roots:
        if root_ip not in active_root_ips:
            credential_required[root_ip] = {
                "ip": root_ip, "hostname": root_ip, "source_device": "Configured Root",
                "protocol": "ROOT", "neighbor_kind": "network", "hop_depth": 0,
                "local_interface": "-", "reason": "Configured root is inaccessible with the supplied credentials",
            }

    def queue_device(ip: str, depth: int, evidence: str, prefetched=None) -> None:
        ip = str(ip or "").strip()
        # If this address is already known as an interface/management address
        # of a discovered device, do not probe it again as a second device.
        # This is critical for L3 switches and routers with several SVIs or
        # routed interfaces: one physical device must remain one topology node.
        owner = profiles_by_identity.get(identity_by_ip.get(ip)) or {}
        neighbor_alias = ((candidate_hints.get(ip) or {}).get("protocol") in {"CDP", "LLDP"}
                          and str(owner.get("query_ip") or "") != ip)
        if not ip or ip in skipped_ips or ip in visited_query_ips or ip in queued_device_ips or (ip in identity_by_ip and not neighbor_alias):
            return
        if depth > MAX_DISCOVERY_DEPTH:
            return
        device_queue.append((ip, depth, evidence, prefetched))
        queued_device_ips.add(ip)

    def queue_network(network: str, depth: int, source: str, evidence: str) -> None:
        if scan_level != "full":
            return
        if not _safe_network(network):
            return
        if network in visited_networks:
            return
        if len(visited_networks) >= MAX_DISCOVERED_NETWORKS:
            return
        visited_networks.add(network)
        scan_scope[network] = {
            "network": network,
            "source_device": source,
            "scope_evidence": evidence,
            "subnet_scanned": False,
        }

    # Retry concrete IPs previously observed under the same configured roots.
    # These are candidates, not retained devices or proof of a physical link.
    for row in list(known_devices or []):
        ip = str(row.get("ip") or "").strip()
        try:
            ip = str(ipaddress.IPv4Address(ip))
        except ValueError:
            continue
        candidate_hints.setdefault(ip, {
            "hostname": row.get("hostname") or ip, "neighbor_kind": row.get("neighbor_kind") or "network",
            "source_device": "Previous discovery", "protocol": "KNOWN-IP",
        })
        queue_device(ip, 1, "previously-discovered")

    collected = {}
    while device_queue:
        # Collect a bounded frontier concurrently; merge profiles in queue order
        # below so identity resolution and topology mutations remain serial.
        batch = []
        for ip, hop, _, ready in device_queue:
            if (ready is None and ip not in collected and ip not in visited_query_ips
                    and ip not in identity_by_ip and hop <= MAX_DISCOVERY_DEPTH):
                batch.append(ip)
            if len(batch) >= DISCOVERY_WORKERS:
                break
        if batch:
            with ThreadPoolExecutor(max_workers=DISCOVERY_WORKERS) as executor:
                futures = {ip: executor.submit(collect_profile, ip) for ip in batch}
                for ip, future in futures.items():
                    try:
                        collected[ip] = future.result()
                    except Exception:
                        collected[ip] = None
        if device_queue:
            query_ip, depth, discovered_by, prefetched = device_queue.popleft()
            queued_device_ips.discard(query_ip)
            if query_ip in visited_query_ips or depth > MAX_DISCOVERY_DEPTH:
                continue
            # The IP may have entered the queue before another probe revealed
            # that it belongs to an already discovered multi-interface device.
            # Re-check the alias index at dequeue time to prevent duplicates.
            if query_ip in identity_by_ip:
                existing = profiles_by_identity.get(identity_by_ip[query_ip]) or {}
                known_candidate = (candidate_hints.get(query_ip) or {}).get("protocol") in {"KNOWN-IP", "CDP", "LLDP"}
                if not known_candidate or str(existing.get("query_ip") or "") == query_ip:
                    visited_query_ips.add(query_ip)
                    continue
            visited_query_ips.add(query_ip)

            try:
                profile = prefetched or (collected.pop(query_ip) if query_ip in collected else collect_profile(query_ip))
            except Exception:
                profile = None
            if not profile:
                hint = dict(candidate_hints.get(query_ip) or {})
                # Route peers/subnet hosts may be ordinary servers. Only known
                # infrastructure neighbors and explicit roots belong in the queue.
                if not hint and discovered_by != "configured-root":
                    continue
                if hint.get("neighbor_kind") == "endpoint":
                    discovered_hosts.setdefault(query_ip, {"ip": query_ip, "hostname": hint.get("hostname", "")})
                    continue
                credential_required[query_ip] = {
                    "ip": query_ip,
                    "hop_depth": depth,
                    "hostname": hint.get("hostname") or "Unknown neighbor",
                    "source_device": hint.get("source_device") or "-",
                    "source_ip": hint.get("source_ip") or "",
                    "remote_interface": hint.get("remote_interface") or "-",
                    "protocol": hint.get("protocol") or discovered_by,
                    "local_interface": hint.get("local_interface") or "-",
                    "neighbor_kind": hint.get("neighbor_kind", "unknown"),
                    "reason": "Discovered hop is unreachable with the supplied credentials; check SNMP/SSH credentials, ACLs, and connectivity",
                }
                continue

            credential_required.pop(query_ip, None)
            if profile.get("device_type") not in {"router", "switch", "layer3_switch", "network_device"}:
                if profile.get("device_type") in {"end_device", "server", "printer"}:
                    discovered_hosts.setdefault(query_ip, {"ip": query_ip, "hostname": profile.get("hostname") or ""})
                continue

            profile["discovered_by"] = discovered_by
            profile["management_ips"] = sorted({
                query_ip,
                *[
                    str(row.get("ip"))
                    for row in profile.get("ip_addresses") or []
                    if row.get("ip")
                ],
            })
            # Resolve the profile to an existing logical device before creating
            # a new identity. Any IP already advertised by a previous profile is
            # strong evidence that this is another SNMP view of the same box.
            candidate_ips = {str(query_ip)}
            candidate_ips.update(str(value) for value in (profile.get("management_ips") or []) if value)
            candidate_ips.update(
                str(row.get("ip")) for row in (profile.get("ip_addresses") or [])
                if row.get("ip")
            )
            alias_identities = {
                identity_by_ip[ip]
                for ip in candidate_ips
                if ip in identity_by_ip and ip not in ambiguous_ips
            }

            # V4.24: a successfully probed router is identified by sysName first.
            # Do NOT merge two different routers merely because one address in
            # their IP-MIB overlaps.  In routed GNS3 labs a stale/duplicate
            # address on any secondary interface used to swallow the complete
            # router profile even though SNMP returned a different hostname.
            proposed_identity = _identity(profile)
            device_type = str(profile.get("device_type") or "").strip().lower()
            hostname = str(profile.get("hostname") or "").strip().lower().rstrip(".")
            generic_names = {"", "unknown", "router", "switch", "localhost", "device"}

            if device_type in {"switch", "layer3_switch", "network_device"} or (device_type == "router" and hostname not in generic_names):
                identity = proposed_identity
                if device_type in {"switch", "layer3_switch"} and len(alias_identities) == 1 and hostname not in generic_names:
                    alias_identity = next(iter(alias_identities))
                    existing = profiles_by_identity.get(alias_identity) or {}
                    if (str(existing.get("hostname") or "").lower().rstrip(".") == hostname
                            and str(existing.get("query_ip") or "") in candidate_ips
                            and query_ip in set(existing.get("management_ips") or [])):
                        identity = alias_identity
            else:
                identity = next(iter(alias_identities), None) if len(alias_identities) == 1 else proposed_identity

            # Defensive hostname merge for a device reached through an address
            # that was not exposed in its first SNMP IP-MIB response. Only use a
            # non-generic exact sysName and only when it matches one device.
            if identity not in profiles_by_identity:
                if device_type == "router" and hostname not in generic_names:
                    hostname_matches = [
                        key for key, existing in profiles_by_identity.items()
                        if str(existing.get("hostname") or "").strip().lower().rstrip(".") == hostname
                    ]
                    if len(hostname_matches) == 1:
                        identity = hostname_matches[0]

            if identity in profiles_by_identity:
                _merge_profile(profiles_by_identity[identity], profile)
                profile = profiles_by_identity[identity]
            else:
                profiles_by_identity[identity] = profile

            source_name = str(profile.get("hostname") or query_ip)
            from topology.relationship_engine import build_profile_ip_index
            identity_by_ip, ambiguous_ips = build_profile_ip_index(profiles_by_identity)
            for network in networks_from_profile(
                profile,
                private_only=PRIVATE_NETWORKS_ONLY,
                max_hosts=MAX_HOSTS_PER_NETWORK,
            ):
                queue_network(network, depth + 1, source_name, "interface-network")

            for route in ([] if resume or scan_level == "topology" else profile.get("route_networks") or []):
                if route.get("network"):
                    queue_network(str(route["network"]), depth + 1, source_name, "route-table")

                # An indirect route's next hop is already a concrete router IP.
                # Probe it directly instead of waiting for a broad Nmap sweep.
                # This improves both speed and completeness while route data is
                # still NEVER used as proof of a physical topology edge.
                next_hop = str(route.get("next_hop") or "").strip()
                if next_hop not in {"", "0.0.0.0", "127.0.0.1"}:
                    try:
                        next_hop_addr = ipaddress.ip_address(next_hop)
                    except ValueError:
                        next_hop_addr = None
                    if next_hop_addr is not None and next_hop_addr.version == 4:
                        if (not PRIVATE_NETWORKS_ONLY) or next_hop_addr.is_private:
                            candidate_hints.setdefault(next_hop, {
                                "hostname": next_hop, "source_device": source_name,
                                "source_ip": query_ip,
                                "protocol": "ROUTE", "neighbor_kind": "network",
                                "local_interface": str(route.get("ifindex") or "-"),
                            })
                            queue_device(next_hop, depth + 1, "route-next-hop")

            # Direct routed links in labs are commonly /30.  If CDP has no
            # management address, the opposite /30 host would otherwise be
            # missed in Topology mode.  Probe only that one peer IP -- no Nmap
            # sweep and no inferred edge.
            for peer_ip in ([] if resume or scan_level == "topology" else _point_to_point_peer_ips(profile)):
                queue_device(peer_ip, depth + 1, "point-to-point-peer")

            for neighbor in list(profile.get("cdp_neighbors") or []) + list(profile.get("lldp_neighbors") or []):
                from scanner.neighbor_kind import neighbor_kind
                neighbor_ip = str(neighbor.get("management_ip") or "").strip()
                protocol = str(neighbor.get("protocol") or "neighbor").lower()
                if neighbor_ip:
                    candidate_hints[neighbor_ip] = {
                        "hostname": neighbor.get("remote_device") or neighbor.get("system_name") or "Unknown neighbor",
                        "source_device": source_name,
                        "source_ip": query_ip,
                        "remote_interface": neighbor.get("remote_interface") or neighbor.get("remote_port") or "-",
                        "protocol": protocol.upper(),
                        "local_interface": neighbor.get("local_interface") or neighbor.get("local_port") or neighbor.get("local_ifname") or "-",
                        "neighbor_kind": neighbor_kind(neighbor),
                    }
                    if neighbor_kind(neighbor) == "endpoint":
                        discovered_hosts.setdefault(neighbor_ip, {"ip": neighbor_ip, "hostname": neighbor.get("remote_device") or ""})
                        continue
                    queue_device(neighbor_ip, depth + 1, protocol + "-neighbor")

            # ARP supplies concrete management-IP candidates, not cables.
            # CDP/LLDP neighbors above remain first in the discovery queue.
            # ARP tables may contain hundreds/thousands of client IPs. Even a
            # bounded SNMP probe per client dominates real-world scan time.
            # Topology mode follows only CDP/LLDP; ARP is Full Scan only.
            candidates = [] if resume or scan_level == "topology" else find_arp_snmp_candidates(
                profile, profiles,
                set(identity_by_ip) | visited_query_ips | queued_device_ips | arp_checked_ips | skipped_ips)
            arp_checked_ips.update(str(row.get("ip")) for row in profile.get("_arp_scan_cache") or [])
            for candidate_ip in candidates:
                candidate_hints.setdefault(candidate_ip, {
                    "hostname": candidate_ip, "source_device": source_name, "source_ip": query_ip,
                    "protocol": "ARP-SNMP", "neighbor_kind": "unknown",
                })
                queue_device(candidate_ip, depth + 1, "arp-snmp")
            continue

    from topology.device_reconciliation import reconcile_network_addresses
    identity_by_ip, ambiguous_ips, _ = reconcile_network_addresses(profiles_by_identity, _merge_profile)

    # Rebuild pending neighbors directly from CDP/LLDP, not service roles or
    # accepted link lists (a port conflict must not hide the credential hop).
    from services.neighbor_inventory import pending_neighbor_hops
    credential_required = {key: row for key, row in credential_required.items()
                           if key not in identity_by_ip and str(row.get("protocol") or "").upper() not in {"CDP", "LLDP"}}
    for row in pending_neighbor_hops(profiles_by_identity, identity_by_ip):
        credential_required.pop(row["ip"], None)
        credential_required[row["key"]] = row

    from topology.relationship_engine import profile_ips
    network_device_ips = {ip for profile in profiles_by_identity.values() for ip in profile_ips(profile)}
    network_device_ips.update(skipped_ips)
    for row in known_devices or []:
        network_device_ips.update(str(ip) for ip in [row.get("ip"), *(row.get("management_ips") or [])] if ip)

    return {
        "root_ip": active_root_ips[0],
        "root_ips": active_root_ips,
        "requested_root_ips": requested_roots,
        "profiles": list(profiles_by_identity.values()),
        "identity_by_ip": identity_by_ip,
        "ambiguous_ips": sorted(ambiguous_ips),
        "network_device_ips": sorted(network_device_ips),
        "visited_networks": sorted(visited_networks),
        "scan_scope": [scan_scope[key] for key in sorted(scan_scope)],
        "discovered_hosts": list(discovered_hosts.values()),
        "routes": [],
        "scan_level": scan_level,
        "connection_mode": connection_mode,
        "credential_required": list(credential_required.values()),
        "credential_profile_count": len(profiles),
        "collection_timings": [{"ip": ip, "seconds": seconds}
                               for ip, seconds in sorted(collection_timings.items(), key=lambda row: -row[1])],
        "discovery_workers": DISCOVERY_WORKERS,
        "probed_ip_count": len(collection_timings),
        "fresh_scan": not resume and not bool(known_devices),
    }
