from collections import Counter
from datetime import datetime
from uuid import uuid4
from time import perf_counter
from typing import Dict, List, Optional

from services.recursive_discovery_service import discover_recursive
from topology.recursive_graph_builder import build_recursive_topology
from scanner.service_discovery import discover_common_services
from topology.relationship_engine import collect_router_arp
from topology.device_identity import make_device_identity


def _device_rows(nodes: List[dict]) -> List[dict]:
    rows = []
    for node in nodes:
        rows.append({
            "id": node.get("id", ""),
            "ip": node.get("ip") or node.get("management_ip") or "-",
            "hostname": node.get("hostname") or "Unknown",
            "mac": node.get("mac") or "-",
            "device_type": node.get("device_type") or "unknown",
            "vendor": node.get("vendor") or "Unknown",
            "connected_to": node.get("connected_to") or "-",
            "port": node.get("switch_port") or node.get("uplink_port") or "-",
            "discovery": " + ".join(node.get("discovery") or []),
        })
    return rows


def run_discovery(options: Optional[Dict[str, object]] = None) -> Dict[str, object]:
    options = dict(options or {})
    scan_level = str(options.get("scan_level") or "full").strip().lower()
    if scan_level not in {"topology", "full"}:
        scan_level = "full"

    connection_mode = str(options.get("connection_mode") or "auto").strip().lower()
    if connection_mode not in {"auto", "snmp", "ssh"}:
        connection_mode = "auto"

    supplied_community = options.get("snmp_community")
    community = str(supplied_community or "").strip()
    ssh = dict(options.get("ssh") or {})
    root_ips = list(options.get("root_ips") or [])

    started = perf_counter()
    scan_started_at = datetime.now().astimezone().isoformat(timespec="seconds")
    scan_id = uuid4().hex
    discovery = discover_recursive(
        scan_level=scan_level,
        community=community,
        connection_mode=connection_mode,
        ssh=ssh,
        root_ips=root_ips,
        known_devices=options.get("known_devices") or [],
        resume=bool(options.get("resume")),
        skip_ips=options.get("skip_ips") or [],
    )
    discovery_finished = perf_counter()
    nodes, edges, metadata = build_recursive_topology(
        discovery,
        community=community,
        include_end_devices=(scan_level == "full"),
    )

    graph_finished = perf_counter()
    metadata["collection_timings"] = discovery.get("collection_timings") or []
    metadata["discovery_workers"] = discovery.get("discovery_workers", 1)
    metadata["probed_ip_count"] = discovery.get("probed_ip_count", 0)
    metadata["fresh_scan"] = discovery.get("fresh_scan", False)

    # V4.27: Full Scan is service-focused.  ARP/FDB first maps candidate end
    # devices to the correct access port; one fast Nmap TCP pass then
    # enriches endpoints with useful common network/application services.
    # Service timeouts/closed ports must not erase established topology.
    # This avoids expensive -sV/-O/-sC scans and keeps the topology readable.
    if scan_level == "full":
        endpoint_ips = [
            str(node.get("ip") or "").strip()
            for node in nodes
            if node.get("device_type") == "end_device" and node.get("ip")
        ]
        network_ips = {str(ip) for node in nodes if node.get("device_type") != "end_device"
                       for ip in [node.get("ip"), *(node.get("management_ips") or [])] if ip}
        from topology.relationship_engine import profile_ips
        network_ips.update(ip for profile in discovery.get("profiles") or [] for ip in profile_ips(profile))
        network_ips.update(discovery.get("network_device_ips") or [])
        pending_network_ips = {str(row.get("ip")) for row in discovery.get("credential_required") or []
                               if row.get("neighbor_kind") == "network" or row.get("protocol") == "ROOT"
                               or (str(row.get("protocol") or "").upper() in {"CDP", "LLDP"}
                                   and row.get("neighbor_kind") != "endpoint")}
        # ARP/FDB can map an inaccessible router's MAC as an endpoint. That
        # does not prove it is a server and must not consume its credential hop.
        unresolved_endpoint_ids = {str(node["id"]) for node in nodes
                                   if node.get("device_type") == "end_device" and str(node.get("ip")) in network_ips | pending_network_ips}
        nodes = [node for node in nodes if str(node.get("id")) not in unresolved_endpoint_ids]
        edges = [edge for edge in edges if str(edge.get("from")) not in unresolved_endpoint_ids
                 and str(edge.get("to")) not in unresolved_endpoint_ids]
        endpoint_ips = [ip for ip in endpoint_ips if ip not in pending_network_ips and ip not in network_ips]
        endpoint_ips.extend(str(row.get("ip")) for row in discovery.get("discovered_hosts") or []
                            if row.get("ip") and str(row["ip"]) not in network_ips
                            and str(row["ip"]) not in pending_network_ips)
        endpoint_ips.extend(str(row["ip"]) for row in discovery.get("credential_required") or []
                            if row.get("ip") and row.get("neighbor_kind") == "unknown"
                            and str(row["ip"]) not in network_ips and str(row["ip"]) not in pending_network_ips)
        profiles = {make_device_identity(profile): profile for profile in discovery.get("profiles") or []}
        arp_tables = collect_router_arp(profiles, community, include_switches=True)
        endpoint_ips.extend(str(row.get("ip")) for rows in arp_tables.values() for row in rows
                            if row.get("ip") and str(row["ip"]) not in network_ips
                            and str(row["ip"]) not in pending_network_ips)
        endpoint_ips.extend(str(ip) for ip in options.get("service_target_ips") or []
                            if str(ip) not in network_ips and str(ip) not in pending_network_ips)
        targets = list(dict.fromkeys(endpoint_ips))
        service_map = discover_common_services(targets, verify=True) if options.get("verify_services") else discover_common_services(targets)
        mapped_ips = {str(node.get("ip")) for node in nodes}
        service_level = max((int(n.get("level") or 0) for n in nodes), default=0) + 1
        # ARP observations remain useful even when no application port responds.
        # Keep them in the unlocated list without inventing physical links.
        for rows in arp_tables.values():
            for row in rows:
                ip = str(row.get("ip") or "")
                if not ip or ip in mapped_ips or ip in network_ips or ip in pending_network_ips:
                    continue
                nodes.append({"id": "arp:" + ip, "ip": ip, "mac": row.get("mac"),
                              "hostname": "Unknown", "device_type": "end_device",
                              "group": "end_device", "level": service_level,
                              "discovery": ["ARP"], "port_known": False})
                mapped_ips.add(ip)
        for ip, service_info in service_map.items():
            if ip in mapped_ips or ip in network_ips or ip in pending_network_ips:
                continue
            # Service discovery proves the host exists, not its physical port.
            # Show unlocated endpoints without inventing a topology edge.
            nodes.append({"id": "service:" + ip, "ip": ip, "hostname": "Unknown",
                          "level": service_level,
                          "device_type": "end_device", "group": "end_device",
                          "display_type": "Service Endpoint", "display_name": service_info.get("service_role", ip),
                          "discovery": ["Nmap Fast Service"], "port_known": False,
                          "connection_status": "Physical connection not yet identified"})
        service_endpoint_ids = set()
        for node in nodes:
            if node.get("device_type") != "end_device":
                continue
            service_info = service_map.get(str(node.get("ip") or "").strip())
            if not service_info:
                continue
            node["services"] = service_info.get("services", [])
            node["service_role"] = service_info.get("service_role", "Network Service")
            node["service_identification"] = service_info.get("classification_source", "nmap-port-hint")
            node["icon_type"] = "printer" if "print" in node["service_role"].lower() else "server"
            node["display_name"] = node.get("hostname") if node.get("hostname") not in {None, "", "Unknown"} else node["service_role"]
            node["discovery"] = list(dict.fromkeys(list(node.get("discovery") or []) + ["Nmap Fast Service"]))
            service_endpoint_ids.add(str(node.get("id")))

        metadata["service_endpoint_count"] = len(service_endpoint_ids)
        metadata["filtered_end_device_count"] = 0
        metadata["endpoint_policy"] = "preserve-topology-add-application-services"
        metadata["endpoint_discovery"] = "arp-fdb-neighbors-targeted"
        metadata["service_target_count"] = len(set(endpoint_ips))
        metadata["service_scan"] = getattr(service_map, "diagnostics", {})
    from topology.evidence_policy import physical_topology, network_ips as hardware_ips
    reserved_ips = hardware_ips(nodes) | set(discovery.get("network_device_ips") or [])
    all_service_rows = [
        {"ip": node.get("ip"), "hostname": node.get("hostname"), "role": node.get("service_role"), "services": node.get("services", [])}
        for node in nodes if node.get("device_type") == "end_device" and node.get("services") and str(node.get("ip")) not in reserved_ips
    ]
    nodes, edges, unlocated = physical_topology(nodes, edges, discovery.get("network_device_ips") or [])
    placed_ips = {str(n.get("ip")) for n in nodes if n.get("device_type") == "end_device"}
    for row in all_service_rows:
        row["connection_known"] = str(row.get("ip")) in placed_ips
    metadata["unlocated_services"] = [row for row in all_service_rows if not row["connection_known"]]
    metadata["unlocated_endpoints"] = unlocated
    metadata["located_service_endpoint_count"] = sum(row["connection_known"] for row in all_service_rows)
    metadata["service_endpoint_count"] = len(all_service_rows)
    metadata["endpoint_policy"] = "physical-map-with-separate-unlocated-services"
    metadata["source"] = "scan"
    metadata["scan_id"] = scan_id
    metadata["scan_started_at"] = scan_started_at
    metadata["requested_root_ips"] = root_ips
    metadata["neighbor_sources"] = [
        {"ip": p.get("query_ip"), "hostname": p.get("hostname"),
         "cdp_count": len(p.get("cdp_neighbors") or []), "lldp_count": len(p.get("lldp_neighbors") or [])}
        for p in discovery.get("profiles") or []
    ]
    metadata["arp_snmp_target_count"] = sum(p.get("_arp_snmp_target_count", 0) for p in discovery.get("profiles") or [])
    metadata["arp_snmp_device_count"] = sum(p.get("discovered_by") == "arp-snmp" for p in discovery.get("profiles") or [])
    endpoint_ips = {str(node.get("ip")) for node in nodes if node.get("device_type") == "end_device"} | {str(row["ip"]) for row in all_service_rows}
    metadata["credential_required"] = [row for row in discovery.get("credential_required", [])
                                       if row.get("neighbor_kind") != "endpoint"
                                       and (str(row.get("protocol") or "").upper() in {"CDP", "LLDP"}
                                            or str(row.get("ip")) not in endpoint_ips)]
    metadata["credential_profile_count"] = discovery.get("credential_profile_count", 1)
    metadata["discovery_complete"] = not bool(metadata["credential_required"])
    finished = perf_counter()
    metadata["scan_phase_seconds"] = {
        "discovery": round(discovery_finished - started, 3),
        "graph": round(graph_finished - discovery_finished, 3),
        "enrichment": round(finished - graph_finished, 3),
    }
    duration = round(finished - started, 2)
    scanned_at = datetime.now().astimezone().isoformat(timespec="seconds")
    metadata["scan_finished_at"] = scanned_at

    counts = Counter(node.get("device_type", "unknown") for node in nodes)
    relation_counts = Counter(edge.get("relation", "unknown") for edge in edges)
    from topology.network_information import lan_networks
    observed_lans = sorted({network for profile in discovery.get("profiles") or [] for network in lan_networks(profile)})

    summary = {
        "total_devices": len(nodes),
        "router_count": counts.get("router", 0),
        "switch_count": counts.get("switch", 0) + counts.get("layer3_switch", 0) + counts.get("unmanaged_switch", 0) + counts.get("inferred_trunk_switch", 0),
        "managed_switch_count": counts.get("switch", 0) + counts.get("layer3_switch", 0),
        "layer3_switch_count": counts.get("layer3_switch", 0),
        "unmanaged_switch_count": counts.get("unmanaged_switch", 0),
        "end_device_count": counts.get("end_device", 0),
        "link_count": len(edges),
        "cdp_links": relation_counts.get("cdp", 0) + relation_counts.get("lldp", 0) + relation_counts.get("cdp_lldp", 0),
        "lldp_links": relation_counts.get("lldp", 0) + relation_counts.get("cdp_lldp", 0),
        "arp_fdb_links": relation_counts.get("arp_fdb", 0)
        + relation_counts.get("unmanaged_downstream", 0),
        "inferred_switch_links": relation_counts.get("inferred_unmanaged_switch", 0) + relation_counts.get("inferred_trunk_switch", 0),
        "scan_time": scanned_at,
        "scan_started_at": scan_started_at,
        "scan_duration_seconds": duration,
        "scan_level": scan_level,
        "connection_mode": connection_mode,
        "target_network": ", ".join(discovery.get("visited_networks", [])),
        "lan_networks": observed_lans,
        "management_network": discovery.get("visited_networks", [""])[0]
        if discovery.get("visited_networks")
        else "",
        "gateway_ip": ", ".join(discovery.get("root_ips") or [metadata.get("root_ip", "")]).strip(", "),
        "switch_management_ips": [
            node.get("ip")
            for node in nodes
            if node.get("device_type") in {"switch", "layer3_switch"}
        ],
    }

    return {
        "nodes": nodes,
        "edges": edges,
        "metadata": metadata,
        "summary": summary,
        "devices": _device_rows(nodes),
        "services": all_service_rows,
    }
