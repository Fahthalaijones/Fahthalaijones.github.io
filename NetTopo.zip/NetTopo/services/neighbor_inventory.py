"""Credential hops come from raw neighbor evidence, independently of services/edges."""
from scanner.neighbor_kind import neighbor_kind
from topology.end_device_mapper import normalize_interface_name
from topology.relationship_engine import find_neighbor_identity


def pending_neighbor_hops(profiles, ip_index):
    rows = {}
    for source_identity, profile in profiles.items():
        source_ip = str(profile.get('query_ip') or profile.get('ip') or '')
        for field, default_protocol in (('cdp_neighbors', 'CDP'), ('lldp_neighbors', 'LLDP')):
            for neighbor in profile.get(field) or []:
                kind = neighbor_kind(neighbor)
                if kind == 'endpoint':
                    continue
                ip = str(neighbor.get('management_ip') or '').strip()
                target = ip_index.get(ip) if ip else find_neighbor_identity(profiles, ip_index, neighbor)
                # An advertisement pointing back to the source is not evidence
                # that the remote hop was collected. Keep it editable.
                conflict = bool(target == source_identity)
                if target and not conflict:
                    continue
                hostname = str(neighbor.get('remote_device') or neighbor.get('system_name') or 'Unknown neighbor')
                local = str(neighbor.get('local_port') or neighbor.get('local_interface') or '-')
                key = 'neighbor:{}:{}:{}'.format(source_ip, normalize_interface_name(local), ip or hostname.lower())
                protocol = str(neighbor.get('protocol') or default_protocol).upper()
                if protocol not in {'CDP', 'LLDP'}:
                    protocol = default_protocol
                reason = ('Advertised management IP belongs to the source device; enter a distinct reachable management IP'
                          if conflict else 'Supply management IP and credentials' if not ip else
                          'CDP/LLDP neighbor not collected; check credentials, reachability, and discovery depth')
                row = dict(key=key, ip=ip, hostname=hostname, source_ip=source_ip,
                           source_device=profile.get('hostname') or source_ip, protocol=protocol,
                           local_interface=local,
                           remote_interface=neighbor.get('remote_port') or neighbor.get('remote_interface') or '-',
                           neighbor_kind=kind, address_conflict=conflict, reason=reason)
                if key in rows:
                    protocols = set(rows[key]['protocols']) | {protocol}
                    row['protocols'] = sorted(protocols)
                    row['protocol'] = 'CDP' if 'CDP' in protocols else 'LLDP'
                else:
                    row['protocols'] = [protocol]
                rows[key] = row
    return list(rows.values())
