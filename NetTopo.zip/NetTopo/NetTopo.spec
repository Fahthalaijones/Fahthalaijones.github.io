# Build on Windows with Python 3.11 (pysnmp 4 requires asyncore).
from pathlib import Path
from PyInstaller.utils.hooks import collect_all

root = Path(SPECPATH)
datas = [(str(root / 'templates'), 'templates'), (str(root / 'static'), 'static')]
binaries = []
hiddenimports = []
# SNMP MIBs and SSH drivers are loaded dynamically.
for package in ('pysnmp', 'pyasn1', 'netmiko'):
    package_data, package_binaries, package_imports = collect_all(package)
    datas += package_data
    binaries += package_binaries
    hiddenimports += package_imports

a = Analysis([str(root / 'desktop_launcher.py')], pathex=[str(root)],
             binaries=binaries, datas=datas, hiddenimports=hiddenimports,
             hookspath=[], runtime_hooks=[], excludes=[])
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name='NetTopo',
          debug=False, strip=False, upx=False, console=True)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name='NetTopo')
