# V4.29 — Fresh Topology Scan + SNMP Timeout Reduction

Based on the uploaded V4.28 project. This is a source-level optimization, **not** a claim that 50 live devices have been benchmarked.

## What was actually slow

- `/api/scan` reused `_cache` nodes and credential-required IPs as `known_devices` on every new scan of the same roots. This caused old addresses to be re-probed even when no longer advertised by neighbors.
- Topology mode still called `find_arp_snmp_candidates` for **every** discovered device. It probed each concrete ARP IP with SNMP even if the IP was an ordinary client or used a different community. This was especially costly with many ARP entries.
- Topology mode fetched a five-column routing table on routers and then probed next-hop IPs and /30-/31 peers. None of these IPs is proof of a CDP/LLDP cable.
- Missing CDP/LLDP MIBs could trigger repeated SNMP walks against absent columns. Wrong community strings and auto SSH fallback also add delays.

## New behavior

- **Start Scan always starts from only the configured Root/Seed IPs**. It clears the previous server scan cache and old graph before starting. No previous IPs or pending hops seed a new scan. `Continue This Hop` intentionally keeps/merges the current topology (unchanged).
- **Topology** now follows CDP/LLDP management IPs only; no ARP SNMP fan-out, no routing table walk, no route-next-hop probe, no /30-/31 peer probe, no Nmap. If CDP/LLDP is disabled or advertises no management IP, add a Root IP or use the existing hop correction popup; this is a speed-vs-coverage tradeoff.
- **Full Scan** retains its broader discovery/endpoint behavior. The Topology changes do not promise to accelerate Full Scan by the same amount.
- If CDP has neither a Device ID nor a management address, the collector skips three other CDP columns. If LLDP has no chassis entries, it skips the other LLDP remote columns. Nonstandard agents that expose only partial neighbor columns might need a more permissive setting.
- SNMP default timeout reduced from 2s with 1 retry to 1.5s with 0 retries. This reduces latency for wrong communities, but can miss high-latency/overloaded devices. To restore reliability, increase `SNMP_TIMEOUT` or `SNMP_RETRIES` in `system_settings.py`.
- In Auto mode, if SNMP fails, a 0.6s TCP port check skips the expensive SSH handshake if the SSH port is closed. SSH-only mode remains unchanged.
- Metadata includes `scan_id`, `scan_started_at`, `scan_finished_at`, `scan_phase_seconds`, `collection_timings`, `probed_ip_count`, and `fresh_scan`. `summary.scan_duration_seconds` is measured using `perf_counter()` for each new scan.

## Freshness vs saved layout

No discovered topology is persisted to the database by Start Scan. Every Start Scan clears the previous scan cache and all saved node/label positions in SQLite `database/network.db` before collecting new data, even when the Root IPs and device IDs are unchanged. The resulting graph uses automatic layout. Save Layout explicitly saves positions for the current run; export JSON before starting another scan if you want to keep the previous topology and arrangement. Continue This Hop still extends the current run. The hardware catalog `database/device_catalog.db` is kept.

## Testing on Ubuntu

1. Back up the existing project, extract this ZIP into a new directory and install requirements in a virtual environment.
2. Start Flask, select **Topology**, enter Root/Seed and SNMP/SSH credentials, and start scan. Wait for the result.
3. Export JSON and inspect `metadata.scan_phase_seconds`, `metadata.collection_timings` (slowest IPs first), `metadata.probed_ip_count`, and `summary.scan_duration_seconds`.
4. Scan again without changing the network: check `metadata.scan_id` changes and `metadata.fresh_scan` is true; old IPs that are no longer in CDP/LLDP must not appear as probed candidates.
5. Run offline regression tests with the installed dependencies:
   `python3 -m unittest test_fresh_fast_topology test_discovery_recovery test_scan_performance test_mixed_communities test_neighbor_links test_topology_sources -v`

## Caveats

- No live-network benchmark was available to this patch. An estimate such as "50 devices in X minutes" cannot be verified here.
- A 50-hop *chain* must discover each next hop sequentially. A star/fanout can use `DISCOVERY_WORKERS` parallel workers.
- Missing CDP/LLDP management addresses can still require manual hop IP entry. IP routing information is no longer an implicit discovery path in Topology mode.
- A successful SNMP connection may still take time if the agent's interface/neighbor MIBs are large or slow.
- Changing settings for SNMP timeouts changes both Topology and Full Scan.
