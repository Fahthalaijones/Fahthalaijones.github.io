from scanner.snmp import snmp_walk

from scanner.mib_parser import parse_walk

OID = "1.3.6.1.2.1.2.2.1.2"

raw = snmp_walk(

    "192.168.56.125",

    OID

)

table = parse_walk(

    raw,

    OID

)

print(table)