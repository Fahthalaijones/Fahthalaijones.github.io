from unittest.mock import patch

from topology.relationship_engine import map_end_devices_via_router_vlan_and_cdp


def test_router_vlan_cdp_fallback():
    profiles = {
        "router-name:r2": {
            "device_type": "router",
            "query_ip": "192.168.0.6",
            "interfaces": {
                "21": "FastEthernet2/1.10",
                "22": "FastEthernet2/1.20",
                "23": "FastEthernet2/1.30",
            },
        },
        "ip:172.9.0.2": {
            "device_type": "switch",
            "query_ip": "172.9.0.2",
        },
    }
    links = [{
        "source_identity": "router-name:r2",
        "target_identity": "ip:172.9.0.2",
        "local_interface": "FastEthernet2/1",
        "remote_interface": "Ethernet0/0",
    }]
    arp = [{
        "ip": "172.16.0.10", "mac": "00:50:79:66:68:03", "ifindex": "21"
    }, {
        "ip": "172.16.1.10", "mac": "00:50:79:66:68:04", "ifindex": "22"
    }, {
        "ip": "172.16.2.10", "mac": "00:50:79:66:68:09", "ifindex": "23"
    }]
    with patch("topology.relationship_engine.collect_router_arp", return_value={"router-name:r2": arp}):
        rows = map_end_devices_via_router_vlan_and_cdp(
            profiles, links, "public", {"192.168.0.6", "172.9.0.2"}
        )
    assert len(rows) == 3
    assert {r["vlan"] for r in rows} == {10, 20, 30}
    assert all(r["switch_identity"] == "ip:172.9.0.2" for r in rows)
    assert all(r["port_known"] is False for r in rows)


if __name__ == "__main__":
    test_router_vlan_cdp_fallback()
    print("PASS: Router ARP + subinterface VLAN + CDP fallback")
