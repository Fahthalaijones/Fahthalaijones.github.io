from pprint import pprint

from services.recursive_discovery_service import discover_recursive
from topology.recursive_graph_builder import build_recursive_topology


def main():
    discovery = discover_recursive()

    print("=== SCAN SCOPE (NOT TOPOLOGY LINKS) ===")
    pprint(discovery.get("scan_scope", []))

    print("\n=== VISITED NETWORKS ===")
    pprint(discovery.get("visited_networks", []))

    print("\n=== NETWORK DEVICE PROFILES ===")
    for profile in discovery.get("profiles", []):
        print(
            profile.get("hostname"),
            profile.get("query_ip"),
            profile.get("device_type"),
            "routes=", len(profile.get("route_networks", [])),
            "cdp=", len(profile.get("cdp_neighbors", [])),
        )

    nodes, edges, metadata = build_recursive_topology(discovery)
    print("\n=== TOPOLOGY EDGES (EVIDENCE ONLY) ===")
    for edge in edges:
        print(
            edge.get("relation"),
            edge.get("from"),
            "->",
            edge.get("to"),
            edge.get("label", ""),
        )

    print("\n=== METADATA ===")
    pprint(metadata)


if __name__ == "__main__":
    main()
