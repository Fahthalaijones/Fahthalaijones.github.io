"""Unit-style test for direct Router -> PC discovery logic."""
from unittest.mock import patch

from topology.relationship_engine import map_direct_router_end_devices

profiles = {
    "router-name:r1": {
        "hostname": "R1",
        "device_type": "router",
        "query_ip": "192.168.56.125",
        "interfaces": {"1": "FastEthernet0/0", "2": "FastEthernet1/0", "3": "FastEthernet2/1.10"},
    },
    "ip:192.168.10.2": {
        "hostname": "SW1",
        "device_type": "switch",
        "query_ip": "192.168.10.2",
    },
}
cdp_links = [{
    "source_identity": "router-name:r1",
    "target_identity": "ip:192.168.10.2",
    "local_interface": "FastEthernet2/1",
    "remote_interface": "Ethernet0/0",
}]
arp = [
    {"ip": "172.30.0.10", "mac": "00:50:79:66:68:01", "ifindex": "1"},
    {"ip": "172.16.0.10", "mac": "00:50:79:66:68:02", "ifindex": "3"},
]

with patch("topology.relationship_engine.get_arp_table", return_value=arp):
    rows = map_direct_router_end_devices(
        profiles, cdp_links, "public", {"192.168.56.125", "192.168.10.2"}
    )

assert len(rows) == 1, rows
assert rows[0]["ip"] == "172.30.0.10", rows
assert rows[0]["interface"] == "FastEthernet0/0", rows
assert rows[0]["relation"] == "router_arp_direct", rows
print("PASS: direct Router -> PC discovered; clients behind CDP trunk excluded")
