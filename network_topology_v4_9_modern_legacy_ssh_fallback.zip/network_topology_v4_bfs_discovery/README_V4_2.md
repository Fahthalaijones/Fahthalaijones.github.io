# V4.2 Router Alias Deduplication

This version fixes duplicate R1/R2 nodes caused by probing the same router via multiple interface IP addresses.

Identity policy:

- Router: merge by SNMP hostname (for example all R1 interface IPs become one `router-name:r1` node).
- Managed switch: keep separate by management/query IP, even if cloned switches share bridge MAC and sysObjectID.

Examples:

- `192.168.56.125`, `192.168.0.1`, `192.168.10.1` reporting hostname R1 become one R1 node.
- `192.168.10.2` SW-Ubon, `192.168.20.2` SW-Amnat, and `192.168.30.2` SW-Sisaket remain separate.

Run:

```bash
python3 test_v4_identity.py
python3 test_v4_router_aliases.py
python3 app.py
```
