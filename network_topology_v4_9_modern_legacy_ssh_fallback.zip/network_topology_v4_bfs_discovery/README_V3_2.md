# Network Topology Recursive Discovery V3.2

V3.2 fixes the important distinction between **reachable scan scope** and
**actual topology links**.

## Configuration

Only R1 is configured:

```python
ROOT_DEVICE_IP = "192.168.56.125"
SNMP_COMMUNITY = "public"
```

R2, managed switches and their LAN networks are not configured.

## Discovery behavior

1. Read R1 with SNMP.
2. Read R1 interface networks.
3. Read R1 route table to find remote LANs behind R2.
4. Scan those networks for SNMP devices.
5. Recursively profile R2 and switches.
6. Create network-device links only from CDP evidence.
7. Create end-device links only from Router ARP + Switch FDB evidence.
8. Infer an unmanaged switch when multiple downstream MAC addresses share one
   non-uplink managed-switch port.

A route, shared subnet or successful ping is never used to draw a physical
link. Therefore SW1 will not be linked to R2 unless CDP actually reports that
relationship.

## Existing host routing

This version does not modify Linux routes. The discovery host must already be
able to reach the GNS3 networks. Check a destination with:

```bash
ip route get 192.168.20.2
```

## Test

```bash
source venv/bin/activate
python3 test_recursive_discovery.py
```

The output has two separate sections:

- `SCAN SCOPE`: networks learned from interfaces/routes; these are not links.
- `TOPOLOGY EDGES`: only CDP and ARP+FDB relationships.

Run the dashboard:

```bash
python3 app.py
```
