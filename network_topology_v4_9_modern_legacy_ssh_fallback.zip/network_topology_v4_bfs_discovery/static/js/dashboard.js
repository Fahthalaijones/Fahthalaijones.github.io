const state = {
    payload: null,
    allNodes: [],
    allEdges: [],
    nodes: new vis.DataSet([]),
    edges: new vis.DataSet([]),
    network: null,
    chart: null,
    hasSavedLayout: false,
    scanLevel: "topology",
    discoverySettings: {
        connectionMode: "auto",
        snmpCommunity: "",
        sshEnabled: false,
        sshUsername: "",
        sshPassword: "",
        sshPort: 22,
        sshDeviceType: "auto",
        rootNodeIps: "",
    },
};

const $ = (id) => document.getElementById(id);

function escapeHtml(value) {
    return String(value ?? "-").replace(/[&<>'"]/g, (char) => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;"
    }[char]));
}

function toast(message) {
    const el = $("toast");
    el.textContent = message;
    el.classList.remove("hidden");
    window.setTimeout(() => el.classList.add("hidden"), 2600);
}

function networkOptions(useSavedLayout = false) {
    return {
        autoResize: true,
        layout: useSavedLayout ? {
            hierarchical: { enabled: false }
        } : {
            hierarchical: {
                enabled: true,
                direction: "UD",
                sortMethod: "directed",
                shakeTowards: "roots",
                levelSeparation: 215,
                nodeSpacing: 220,
                treeSpacing: 330,
                blockShifting: true,
                edgeMinimization: true,
                parentCentralization: true,
            }
        },
        physics: { enabled: false },
        nodes: {
            borderWidth: 0,
            shadow: { enabled: true, size: 9, x: 2, y: 4 },
            font: { size: 1, color: "rgba(0,0,0,0)" },
        },
        edges: {
            width: 1.8,
            color: { color: "#97859D", highlight: "#556C8E", hover: "#556C8E" },
            smooth: { enabled: true, type: "cubicBezier", forceDirection: useSavedLayout ? "none" : "vertical", roundness: .18 },
            font: {
                size: 10, align: "middle", background: "rgba(255,250,248,.96)",
                color: "#556C8E", strokeWidth: 0
            },
        },
        groups: {
            router: { shape: "image", image: "/static/icons/router.svg", size: 50 },
            switch: { shape: "image", image: "/static/icons/switch.svg", size: 50 },
            unmanaged_switch: { shape: "image", image: "/static/icons/unmanaged_switch.svg", size: 48 },
            end_device: { shape: "image", image: "/static/icons/pc.svg", size: 44 },
            server: { shape: "image", image: "/static/icons/server.svg", size: 44 },
            printer: { shape: "image", image: "/static/icons/printer.svg", size: 44 },
            unknown: { shape: "image", image: "/static/icons/unknown.svg", size: 44 },
        },
        interaction: {
            hover: true, navigationButtons: true, keyboard: true,
            dragNodes: true, dragView: true, zoomView: true, selectConnectedEdges: true
        },
    };
}

function roundedRect(ctx, x, y, width, height, radius) {
    const r = Math.min(radius, width / 2, height / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + width, y, x + width, y + height, r);
    ctx.arcTo(x + width, y + height, x, y + height, r);
    ctx.arcTo(x, y + height, x, y, r);
    ctx.arcTo(x, y, x + width, y, r);
    ctx.closePath();
}

function drawNodeLabels(ctx) {
    if (!state.network) return;
    const positions = state.network.getPositions();
    const visibleIds = new Set(state.nodes.getIds());

    state.allNodes.forEach((node) => {
        if (!visibleIds.has(node.id) || !positions[node.id]) return;
        const pos = positions[node.id];
        const lines = [node.display_name, node.display_ip, node.display_type].filter(Boolean);
        const isEnd = node.device_type === "end_device";
        const isUnmanaged = node.device_type === "unmanaged_switch";
        const fontSize = isEnd ? 12 : 13;
        const lineHeight = fontSize + 4;

        ctx.save();
        ctx.font = `${isEnd ? 500 : 600} ${fontSize}px Arial`;
        const textWidth = Math.max(...lines.map((line) => ctx.measureText(line).width));
        const cardWidth = textWidth + 18;
        const cardHeight = lines.length * lineHeight + 10;
        let x;
        let y;

        if (isEnd) {
            x = pos.x - cardWidth / 2;
            y = pos.y + 48;
        } else {
            x = pos.x + 58;
            y = pos.y - cardHeight / 2;
        }

        roundedRect(ctx, x, y, cardWidth, cardHeight, 7);
        ctx.fillStyle = isUnmanaged ? "rgba(254,207,171,.96)" : "rgba(255,250,248,.96)";
        ctx.fill();
        ctx.strokeStyle = isUnmanaged ? "rgba(250,168,144,.90)" : "rgba(151,133,157,.36)";
        ctx.lineWidth = 1;
        ctx.stroke();

        lines.forEach((line, index) => {
            ctx.fillStyle = index === 0 ? "#556C8E" : "#7e7483";
            ctx.textAlign = "left";
            ctx.textBaseline = "top";
            ctx.fillText(line, x + 9, y + 5 + index * lineHeight);
        });
        ctx.restore();
    });
}

function initNetwork() {
    state.network = new vis.Network($("network"), { nodes: state.nodes, edges: state.edges }, networkOptions(false));
    state.network.on("selectNode", (params) => showNode(params.nodes[0]));
    state.network.on("selectEdge", (params) => {
        if (!params.nodes.length) showEdge(params.edges[0]);
    });
    state.network.on("deselectNode", () => clearSelection());
    state.network.on("afterDrawing", (ctx) => drawNodeLabels(ctx));

    // Auto-save the arrangement whenever the user finishes moving node(s).
    state.network.on("dragEnd", (params) => {
        if (params.nodes && params.nodes.length) {
            saveCurrentLayout({ silent: true });
        }
    });
}

function splitSummaryItems(value) {
    if (Array.isArray(value)) return value.map((item) => String(item).trim()).filter(Boolean);
    return String(value || "").split(",").map((item) => item.trim()).filter(Boolean);
}

function setSummarizedText(elementId, value, singularLabel = "Network", pluralLabel = "Networks") {
    const el = $(elementId);
    const items = splitSummaryItems(value);
    if (!items.length) {
        el.textContent = "-";
        el.removeAttribute("title");
        return;
    }
    if (items.length <= 2) {
        el.textContent = items.join(", ");
    } else {
        el.textContent = `${items.length} ${items.length === 1 ? singularLabel : pluralLabel}`;
    }
    el.title = items.join("\n");
}

function updateSummary(summary = {}) {
    $("totalDevices").textContent = summary.total_devices ?? 0;
    $("routerCount").textContent = summary.router_count ?? 0;
    $("switchCount").textContent = summary.switch_count ?? 0;
    $("endDeviceCount").textContent = summary.end_device_count ?? 0;
    $("linkCount").textContent = summary.link_count ?? 0;
    $("filterRouterCount").textContent = summary.router_count ?? 0;
    $("filterSwitchCount").textContent = summary.switch_count ?? 0;
    $("filterEndCount").textContent = summary.end_device_count ?? 0;
    setSummarizedText("managementNetwork", summary.management_network);
    setSummarizedText("targetNetwork", summary.target_network);
    $("gatewayIp").textContent = summary.gateway_ip || "-";
    setSummarizedText("switchManagement", summary.switch_management_ips || [], "Switch", "Switches");

    const networks = splitSummaryItems(summary.target_network);
    $("targetBadge").textContent = networks.length > 2 ? `Networks: ${networks.length}` : `Network: ${networks.join(", ") || "-"}`;
    $("targetBadge").title = networks.join("\n");
    $("scanTime").textContent = summary.scan_time ? new Date(summary.scan_time).toLocaleString("th-TH") : "-";
    $("scanDuration").textContent = `${summary.scan_duration_seconds ?? 0}s`;
    $("cdpLinks").textContent = summary.cdp_links ?? 0;
    $("arpFdbLinks").textContent = summary.arp_fdb_links ?? 0;
}

function updateTable(devices) {
    const query = $("tableSearch").value.trim().toLowerCase();
    const filtered = devices.filter((row) => Object.values(row).join(" ").toLowerCase().includes(query));
    $("deviceTableBody").innerHTML = filtered.map((row) => `
        <tr data-node-id="${escapeHtml(row.id)}">
            <td>${escapeHtml(row.ip)}</td><td>${escapeHtml(row.hostname)}</td>
            <td>${escapeHtml(row.device_type)}</td><td>${escapeHtml(row.mac)}</td>
            <td>${escapeHtml(row.connected_to)}</td><td>${escapeHtml(row.port)}</td>
            <td>${escapeHtml(row.discovery)}</td>
        </tr>`).join("");

    document.querySelectorAll("#deviceTableBody tr").forEach((row) => {
        row.addEventListener("click", () => {
            const nodeId = row.dataset.nodeId;
            state.network.selectNodes([nodeId]);
            state.network.focus(nodeId, { scale: 1.15, animation: true });
            showNode(nodeId);
        });
    });
}

function updateChart(summary = {}) {
    const ctx = $("deviceChart");
    if (state.chart) state.chart.destroy();
    state.chart = new Chart(ctx, {
        type: "doughnut",
        data: {
            labels: ["Router", "Switch", "End Device"],
            datasets: [{ data: [summary.router_count || 0, summary.switch_count || 0, summary.end_device_count || 0], backgroundColor: ["#556C8E", "#97859D", "#FAA890"], borderColor: "#fffaf8", borderWidth: 3 }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: "right", labels: { color: "#556C8E", boxWidth: 12, font: { size: 10 } } } },
            cutout: "58%",
        }
    });
}

function renderListView() {
    $("listView").innerHTML = (state.payload?.devices || []).map((row) => `
        <div class="device-list-card" data-node-id="${escapeHtml(row.id)}">
            <b>${escapeHtml(row.ip)}</b><span>${escapeHtml(row.hostname)}</span>
            <span>${escapeHtml(row.device_type)}</span><span>${escapeHtml(row.discovery)}</span>
        </div>`).join("");
}

function applyFilters() {
    const allowed = new Set([...document.querySelectorAll("[data-group]")].filter((el) => el.checked).map((el) => el.dataset.group));
    const query = $("nodeSearch").value.trim().toLowerCase();
    const visibleNodes = state.allNodes.filter((node) => {
        const group = node.group === "unmanaged_switch" ? "switch" : node.group;
        const matchesGroup = allowed.has(group);
        const matchesQuery = !query || JSON.stringify(node).toLowerCase().includes(query);
        return matchesGroup && matchesQuery;
    });
    const visibleIds = new Set(visibleNodes.map((node) => node.id));
    const visibleEdges = state.allEdges.filter((edge) => visibleIds.has(edge.from) && visibleIds.has(edge.to));
    state.nodes.clear(); state.edges.clear();
    state.nodes.add(visibleNodes); state.edges.add(visibleEdges);
    state.network.fit({ animation: true });
}

function detailRows(node) {
    const common = [
        ["Hostname", node.hostname], ["Device Type", node.device_type], ["IP Address", node.ip || node.management_ip],
        ["MAC Address", node.mac], ["Vendor", node.vendor], ["Model", node.model],
    ];
    if (node.device_type === "router") common.push(["LAN Gateway", node.lan_ip]);
    if (node.device_type === "switch") common.push(["Management Interface", node.management_interface], ["Uplink Port", node.uplink_port]);
    if (node.device_type === "unmanaged_switch") common.push(["Upstream Port", node.uplink_port], ["Downstream Devices", node.child_device_count]);
    if (node.device_type === "end_device") common.push(["Connected Switch", node.connected_to], ["VLAN", node.vlan], ["Switch Port", node.port_known === false ? "Not available from SNMP" : node.switch_port]);
    common.push(["Discovery", (node.discovery || []).join(" + ")]);
    return common.filter(([, value]) => value && value !== "-");
}

function showNode(nodeId) {
    const node = state.allNodes.find((item) => String(item.id) === String(nodeId));
    if (!node) return;
    $("selectedEmpty").classList.add("hidden");
    $("selectedDevice").classList.remove("hidden");
    $("deviceName").textContent = node.hostname || node.ip || "Unknown";
    $("deviceSubtitle").textContent = node.ip || node.management_ip || node.device_type;
    const iconMap = {
        router: "/static/icons/router.svg",
        switch: "/static/icons/switch.svg",
        unmanaged_switch: "/static/icons/unmanaged_switch.svg",
        end_device: "/static/icons/pc.svg",
        server: "/static/icons/server.svg",
        printer: "/static/icons/printer.svg",
        unknown: "/static/icons/unknown.svg",
    };
    const iconPath = iconMap[node.device_type] || iconMap.unknown;
    $("deviceIcon").innerHTML = `<img src="${iconPath}" alt="${escapeHtml(node.device_type)}">`;
    $("deviceDetails").innerHTML = detailRows(node).map(([key, value]) => `
        <div class="detail-row"><span>${escapeHtml(key)}</span><span>${escapeHtml(value)}</span></div>`).join("");

    const inventory = $("interfaceInventory");
    const interfaces = Array.isArray(node.interfaces) ? node.interfaces : [];
    if (interfaces.length && (node.device_type === "switch" || node.device_type === "router")) {
        inventory.classList.remove("hidden");
        inventory.innerHTML = `<h4>Interfaces</h4>${interfaces.map((intf) => {
            const ips = (intf.ip_addresses || []).map((row) => `${row.ip}${row.netmask ? " / " + row.netmask : ""}`).join("<br>") || "No IP";
            const mode = intf.switchport_mode && intf.switchport_mode !== "unknown" ? intf.switchport_mode : "";
            const vlan = intf.access_vlan ? `VLAN ${intf.access_vlan}${intf.access_vlan_name ? " (" + intf.access_vlan_name + ")" : ""}` : "";
            return `<div class="interface-row">
                <div><b>${escapeHtml(intf.name)}</b><small>ifIndex ${escapeHtml(intf.ifindex)}</small></div>
                <div><span>Admin: ${escapeHtml(intf.admin_status)}</span><span>Oper: ${escapeHtml(intf.status)}</span>${mode ? `<span>Mode: ${escapeHtml(mode)}</span>` : ""}${vlan ? `<span>Access: ${escapeHtml(vlan)}</span>` : ""}<span>${ips}</span></div>
            </div>`;
        }).join("")}
        ${(node.vlans || []).length ? `<h4>VLAN Database</h4><div class="interface-note">${(node.vlans || []).map((row) => `VLAN ${escapeHtml(row.vlan_id)} — ${escapeHtml(row.name)}`).join("<br>")}</div>` : ""}
        <p class="interface-note">${escapeHtml(node.interface_vlan_note || "Interface IP and status retrieved through IF-MIB/IP-MIB.")}</p>`;
    } else {
        inventory.classList.add("hidden");
        inventory.innerHTML = "";
    }

    const evidence = node.evidence || (node.discovery || []).join(" + ");
    const confidence = node.confidence_percent || (node.device_type === "end_device" ? 95 : 100);
    $("evidencePanel").innerHTML = `<div class="evidence-card">
        <b>Source:</b> ${escapeHtml(evidence)}<br>
        <b>Confidence:</b> <span class="confidence">${escapeHtml(confidence)}%</span><br>
        <b>Reason:</b> ${node.device_type === "end_device" ? "IP/MAC from Router ARP matched MAC/port from Switch FDB." : (node.device_type === "unmanaged_switch" ? "Multiple MAC addresses were learned on the same managed-switch port, so an unmanaged switch is inferred." : "Device information retrieved through SNMP and neighbor relationship through CDP.")}
    </div>`;
}

function showEdge(edgeId) {
    const edge = state.allEdges.find((item) => String(item.id) === String(edgeId));
    if (!edge) return;
    $("evidencePanel").innerHTML = `<div class="evidence-card">
        <b>Relationship:</b> ${escapeHtml(edge.discovery)}<br>
        <b>Local Interface:</b> ${escapeHtml(edge.local_interface)}<br>
        <b>Remote Interface:</b> ${escapeHtml(edge.remote_interface)}<br>
        <b>Confidence:</b> <span class="confidence">${escapeHtml(edge.confidence)}%</span>
    </div>`;
}

function clearSelection() {
    $("selectedEmpty").classList.remove("hidden");
    $("selectedDevice").classList.add("hidden");
}

function nodesWithSavedPositions(nodes, payload) {
    const positions = payload?.layout?.saved_positions || {};
    return nodes.map((node) => {
        const saved = positions[String(node.id)] || ((node.x !== undefined && node.y !== undefined) ? { x: node.x, y: node.y } : null);
        if (!saved) return { ...node };
        return { ...node, x: Number(saved.x), y: Number(saved.y), physics: false };
    });
}

function loadPayload(payload) {
    state.payload = payload;
    state.hasSavedLayout = Boolean(payload?.layout?.has_saved_layout) || (payload.nodes || []).some((node) => node.x !== undefined && node.y !== undefined);
    state.allNodes = nodesWithSavedPositions(payload.nodes || [], payload);
    state.allEdges = payload.edges || [];

    state.network.setOptions(networkOptions(state.hasSavedLayout));
    state.nodes.clear(); state.edges.clear();
    state.nodes.add(state.allNodes); state.edges.add(state.allEdges);

    updateSummary(payload.summary || {});
    updateTable(payload.devices || []);
    updateChart(payload.summary || {});
    renderListView();

    window.setTimeout(() => state.network.fit({ animation: true }), 150);
}

async function saveCurrentLayout({ silent = false } = {}) {
    if (!state.network || !state.allNodes.length) return;
    const ids = state.allNodes.map((node) => node.id).filter((id) => state.nodes.get(id));
    const positions = state.network.getPositions(ids);
    try {
        const response = await fetch("/api/layout", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ positions })
        });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.error || "Cannot save layout");
        state.hasSavedLayout = true;
        // Keep current coordinates in local node objects as well, so filtering does not lose them.
        state.allNodes = state.allNodes.map((node) => positions[node.id] ? { ...node, ...positions[node.id], physics: false } : node);
        if (!silent) toast(`Layout saved (${data.saved} nodes)`);
    } catch (error) {
        console.error(error);
        if (!silent) toast(error.message);
    }
}

async function resetLayout() {
    try {
        const response = await fetch("/api/layout", { method: "DELETE" });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.error || "Cannot reset layout");

        state.hasSavedLayout = false;
        state.allNodes = state.allNodes.map((node) => {
            const copy = { ...node };
            delete copy.x;
            delete copy.y;
            delete copy.physics;
            delete copy.layout_saved;
            return copy;
        });
        state.network.setOptions(networkOptions(false));
        state.nodes.clear();
        state.nodes.add(state.allNodes);
        state.network.fit({ animation: true });
        toast("Layout reset to Auto Layout");
    } catch (error) {
        console.error(error);
        toast(error.message);
    }
}

async function importTopology(file) {
    if (!file) return;
    const form = new FormData();
    form.append("file", file);
    $("scanBadge").textContent = "Importing...";
    $("scanBadge").className = "badge badge-orange";
    try {
        const response = await fetch("/api/import", { method: "POST", body: form });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.error || "Cannot import topology");
        loadPayload(data);
        $("scanBadge").textContent = "Imported";
        $("scanBadge").className = "badge badge-green";
        toast(`Imported: ${data.filename}`);
    } catch (error) {
        console.error(error);
        $("scanBadge").textContent = "Error";
        $("scanBadge").className = "badge badge-orange";
        toast(error.message);
    } finally {
        $("importTopologyFile").value = "";
    }
}

function scanLevelLabel(level) {
    return ({ topology: "Topology", end_devices: "End Devices", full: "Full Scan" })[level] || "Full Scan";
}

function buildScanRequest() {
    const settings = state.discoverySettings;
    const body = {
        scan_level: state.scanLevel,
        connection_mode: settings.connectionMode,
        root_ips: String(settings.rootNodeIps || "")
            .split(/[\n,;]+/)
            .map((item) => item.trim())
            .filter(Boolean),
        ssh: {
            enabled: Boolean(settings.sshEnabled),
            username: settings.sshUsername,
            password: settings.sshPassword,
            port: Number(settings.sshPort || 22),
            device_type: settings.sshDeviceType || "auto",
        },
    };
    // Empty means: keep using the server's config.py SNMP community.
    if (settings.snmpCommunity) body.snmp = { community: settings.snmpCommunity };
    return body;
}

async function fetchDashboard(scan = false) {
    const button = $("scanStartButton");
    button.disabled = true;
    $("scanBadge").textContent = scan ? `${scanLevelLabel(state.scanLevel)}...` : "Loading...";
    $("scanBadge").className = "badge badge-orange";
    try {
        const response = await fetch(scan ? "/api/scan" : "/api/dashboard", {
            method: scan ? "POST" : "GET",
            cache: "no-store",
            headers: scan ? { "Content-Type": "application/json" } : {},
            body: scan ? JSON.stringify(buildScanRequest()) : undefined,
        });
        const data = await response.json();
        if (!response.ok || !data.success) throw new Error(data.error || "Cannot load dashboard");
        loadPayload(data);
        $("scanBadge").textContent = scan ? "Completed" : (data.summary?.total_devices ? "Loaded" : "Ready");
        $("scanBadge").className = "badge badge-green";
        if (scan) toast("Scan completed");
    } catch (error) {
        console.error(error);
        $("scanBadge").textContent = "Error";
        $("scanBadge").className = "badge badge-orange";
        toast(error.message);
    } finally { button.disabled = false; }
}

function updateScanLevel(level) {
    state.scanLevel = level;
    document.querySelectorAll("[data-scan-level]").forEach((button) => {
        button.classList.toggle("active", button.dataset.scanLevel === level);
    });
    const hints = {
        topology: "Topology Scan จะเน้น Router / Switch และ Neighbor ก่อน เพื่อลดเวลาสแกน",
        end_devices: "End Devices Scan จะเพิ่ม ARP / FDB เพื่อค้นหา PC และอุปกรณ์ปลายทาง",
        full: "Full Scan จะใช้กระบวนการค้นหาเครือข่ายและข้อมูลประกอบทั้งหมดของระบบ",
    };
    $("scanModeHint").textContent = hints[level] || hints.full;
    if ($("scanSelectionSummary")) $("scanSelectionSummary").textContent = `${scanLevelLabel(level)} · Ready`;
}

function updateSettingsSummary() {
    const s = state.discoverySettings;
    const parts = [s.connectionMode.toUpperCase()];
    parts.push(s.snmpCommunity ? "Custom SNMP" : "Server SNMP");
    if (s.sshEnabled) parts.push(`SSH ${s.sshUsername || "enabled"}`);
    const roots = String(s.rootNodeIps || "").split(/[\n,;]+/).map((x) => x.trim()).filter(Boolean);
    parts.push(roots.length ? `${roots.length} Root IP${roots.length > 1 ? "s" : ""}` : "Default Root IP");
    $("settingsSummary").textContent = parts.join(" · ");
}

function openSettings() {
    const s = state.discoverySettings;
    $("snmpCommunity").value = s.snmpCommunity;
    $("sshEnabled").checked = s.sshEnabled;
    $("sshUsername").value = s.sshUsername;
    $("sshPassword").value = s.sshPassword;
    $("sshPort").value = s.sshPort;
    $("sshDeviceType").value = s.sshDeviceType;
    $("rootNodeIps").value = s.rootNodeIps || "";
    document.querySelectorAll("[data-connection-mode]").forEach((button) => {
        button.classList.toggle("active", button.dataset.connectionMode === s.connectionMode);
    });
    $("settingsModal").classList.remove("hidden");
    $("settingsModal").setAttribute("aria-hidden", "false");
}

function closeSettings() {
    $("settingsModal").classList.add("hidden");
    $("settingsModal").setAttribute("aria-hidden", "true");
}

function applySettings() {
    const activeMode = document.querySelector("[data-connection-mode].active")?.dataset.connectionMode || "auto";
    state.discoverySettings = {
        connectionMode: activeMode,
        snmpCommunity: $("snmpCommunity").value.trim(),
        sshEnabled: $("sshEnabled").checked,
        sshUsername: $("sshUsername").value.trim(),
        sshPassword: $("sshPassword").value,
        sshPort: Number($("sshPort").value || 22),
        sshDeviceType: $("sshDeviceType").value || "auto",
        rootNodeIps: $("rootNodeIps").value.trim(),
    };
    if (state.discoverySettings.connectionMode === "ssh" && !state.discoverySettings.sshUsername) {
        toast("SSH mode requires a username");
        return;
    }
    updateSettingsSummary();
    closeSettings();
    toast("Discovery settings applied for the next scan");
}

function openScanOptions() {
    $("scanModal").classList.remove("hidden");
    $("scanModal").setAttribute("aria-hidden", "false");
}

function closeScanOptions() {
    $("scanModal").classList.add("hidden");
    $("scanModal").setAttribute("aria-hidden", "true");
}

initNetwork();
document.querySelectorAll("[data-scan-level]").forEach((button) => button.addEventListener("click", () => updateScanLevel(button.dataset.scanLevel)));
$("scanOptionsButton").addEventListener("click", openScanOptions);
$("scanCloseButton").addEventListener("click", closeScanOptions);
$("scanCancelButton").addEventListener("click", closeScanOptions);
$("scanStartButton").addEventListener("click", async () => {
    closeScanOptions();
    await fetchDashboard(true);
});
$("scanModal").addEventListener("click", (event) => { if (event.target === $("scanModal")) closeScanOptions(); });
$("fitButton").addEventListener("click", () => state.network.fit({ animation: true }));
$("saveLayoutButton").addEventListener("click", () => saveCurrentLayout());
$("resetLayoutButton").addEventListener("click", resetLayout);
$("autoLayoutButton").addEventListener("click", async () => {
    await resetLayout();
});
$("importButton").addEventListener("click", () => $("importTopologyFile").click());
$("importTopologyFile").addEventListener("change", (event) => importTopology(event.target.files[0]));
$("tableSearch").addEventListener("input", () => updateTable(state.payload?.devices || []));
$("nodeSearch").addEventListener("input", applyFilters);
document.querySelectorAll("[data-group]").forEach((el) => el.addEventListener("change", applyFilters));
$("mapViewButton").addEventListener("click", () => { $("network").classList.remove("hidden"); $("listView").classList.add("hidden"); });
$("listViewButton").addEventListener("click", () => { $("network").classList.add("hidden"); $("listView").classList.remove("hidden"); });
$("settingsButton").addEventListener("click", openSettings);
$("settingsCloseButton").addEventListener("click", closeSettings);
$("settingsCancelButton").addEventListener("click", closeSettings);
$("settingsApplyButton").addEventListener("click", applySettings);
$("settingsModal").addEventListener("click", (event) => { if (event.target === $("settingsModal")) closeSettings(); });
document.querySelectorAll("[data-connection-mode]").forEach((button) => button.addEventListener("click", () => {
    document.querySelectorAll("[data-connection-mode]").forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
}));
document.querySelectorAll("[data-reveal]").forEach((button) => button.addEventListener("click", () => {
    const input = $(button.dataset.reveal);
    const reveal = input.type === "password";
    input.type = reveal ? "text" : "password";
    button.textContent = reveal ? "Hide" : "Show";
}));
document.addEventListener("keydown", (event) => {
    if (event.key !== "Escape") return;
    if (!$("settingsModal").classList.contains("hidden")) closeSettings();
    if (!$("scanModal").classList.contains("hidden")) closeScanOptions();
});
updateScanLevel("topology");
updateSettingsSummary();
fetchDashboard(false);
