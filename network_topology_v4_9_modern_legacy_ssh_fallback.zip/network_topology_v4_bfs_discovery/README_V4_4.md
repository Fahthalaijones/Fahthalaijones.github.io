# V4.4 Router + Switch VLAN Fallback

This version supports managed IOSvL2 switches whose SNMP agent does not expose
Q-BRIDGE-MIB and does not accept VLAN-indexed communities.

Evidence chain:

1. Router ARP: client IP, MAC and ifIndex.
2. Router ifTable: ifIndex to subinterface, e.g. FastEthernet2/1.10.
3. Subinterface suffix: VLAN 10.
4. CDP: FastEthernet2/1 is connected to the managed switch trunk.
5. Graph: attach the client to that switch with `VLAN 10 (port unavailable)`.

The exact access port is intentionally not claimed because the switch does not
expose per-VLAN FDB through SNMP. If standard FDB works, the existing ARP + FDB
mapping remains preferred and reports the exact switch port.

Before scanning, each PC should ping its default gateway so the router ARP table
contains a current entry.
