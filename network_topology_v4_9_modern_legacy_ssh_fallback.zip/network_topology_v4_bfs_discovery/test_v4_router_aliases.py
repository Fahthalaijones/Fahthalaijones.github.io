from topology.device_identity import make_device_identity

r1_management = {
    "hostname": "R1",
    "query_ip": "192.168.56.125",
    "device_type": "router",
}
r1_transit = {
    "hostname": "R1",
    "query_ip": "192.168.0.1",
    "device_type": "router",
}
r1_lan = {
    "hostname": "R1",
    "query_ip": "192.168.10.1",
    "device_type": "router",
}

sw_ubon = {
    "hostname": "SW-Ubon",
    "query_ip": "192.168.10.2",
    "device_type": "switch",
    "bridge_address": "cc:cc:00:00:00:02",
}
sw_amnat = {
    "hostname": "SW-Amnat",
    "query_ip": "192.168.20.2",
    "device_type": "switch",
    "bridge_address": "cc:cc:00:00:00:02",
}

assert len({make_device_identity(r1_management), make_device_identity(r1_transit), make_device_identity(r1_lan)}) == 1
assert make_device_identity(sw_ubon) != make_device_identity(sw_amnat)
print("PASS: router interface IPs merge, cloned switches remain separate")
