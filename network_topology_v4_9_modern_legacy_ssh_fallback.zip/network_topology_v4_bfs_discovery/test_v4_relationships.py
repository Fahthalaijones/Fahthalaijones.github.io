"""Print only evidence-backed links for troubleshooting V4."""

from services.recursive_discovery_service import discover_recursive
from topology.recursive_graph_builder import build_recursive_topology

result = discover_recursive()
nodes, edges, metadata = build_recursive_topology(result)

print("=== NETWORK DEVICES ===")
for node in nodes:
    if node.get("device_type") in {"router", "switch"}:
        print(node.get("hostname"), node.get("ip"), node.get("device_type"), "level", node.get("level"))

print("\n=== EVIDENCE-BACKED EDGES ===")
for edge in edges:
    print(edge.get("relation"), edge.get("from"), "->", edge.get("to"), edge.get("label"), edge.get("evidence", ""))

print("\n=== SCAN SCOPE (NOT EDGES) ===")
for row in metadata.get("scan_scope", []):
    print(row)
