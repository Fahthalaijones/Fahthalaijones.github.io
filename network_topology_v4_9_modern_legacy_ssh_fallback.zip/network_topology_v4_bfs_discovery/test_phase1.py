from config import ROOT_DEVICE_IP
from scanner.cdp import get_cdp_neighbors
from scanner.device import get_device
from topology.graph_builder import build_phase1_topology


print("=== ROOT DEVICE ===")
print(get_device(ROOT_DEVICE_IP))

print("\n=== CDP NEIGHBORS ===")
for item in get_cdp_neighbors(ROOT_DEVICE_IP):
    print(item)

print("\n=== GRAPH ===")
nodes, edges, metadata = build_phase1_topology(ROOT_DEVICE_IP)
print("metadata:", metadata)
print("nodes:", nodes)
print("edges:", edges)
