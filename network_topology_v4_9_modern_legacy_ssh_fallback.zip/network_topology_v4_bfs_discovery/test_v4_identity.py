"""Offline regression test for cloned GNS3 switch identity handling.

This test deliberately has no SNMP dependency.
"""

from topology.device_identity import make_device_identity

COMMON_BRIDGE = "cc:cc:00:00:00:02"
COMMON_OBJECT = "1.3.6.1.4.1.9.1.1824"

profiles = [
    {"query_ip": "192.168.10.2", "hostname": "SW-Ubon", "bridge_address": COMMON_BRIDGE, "object_id": COMMON_OBJECT},
    {"query_ip": "192.168.20.2", "hostname": "SW-Amnat", "bridge_address": COMMON_BRIDGE, "object_id": COMMON_OBJECT},
    {"query_ip": "192.168.30.2", "hostname": "SW-Sisaket", "bridge_address": COMMON_BRIDGE, "object_id": COMMON_OBJECT},
]

identities = [make_device_identity(row) for row in profiles]
expected = ["ip:192.168.10.2", "ip:192.168.20.2", "ip:192.168.30.2"]
assert identities == expected, (identities, expected)
assert len(set(identities)) == 3

# CDP management IPs must resolve to distinct nodes.
ip_index = {row["query_ip"]: make_device_identity(row) for row in profiles}
assert ip_index["192.168.20.2"] == "ip:192.168.20.2"
assert ip_index["192.168.30.2"] == "ip:192.168.30.2"
assert ip_index["192.168.20.2"] != ip_index["192.168.10.2"]

print("PASS: SW-Ubon, SW-Amnat and SW-Sisaket remain separate despite identical bridge MAC/model")
