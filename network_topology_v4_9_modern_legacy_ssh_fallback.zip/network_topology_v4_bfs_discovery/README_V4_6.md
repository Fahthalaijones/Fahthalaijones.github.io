# V4.6 Cisco VLAN / Access Port Inventory

Adds SNMP support for:

- VLAN database via CISCO-VTP-MIB (`vtpVlanName`)
- Access VLAN per interface via CISCO-VLAN-MEMBERSHIP-MIB (`vmVlan`)
- Trunk operational state via CISCO-VTP-MIB
- Interface inventory showing mode, access VLAN, status and IP
- End-device VLAN attached to an exact FDB port when BRIDGE-MIB exposes the client MAC

## Accuracy rule

`Router ARP + Switch BRIDGE-MIB + vmVlan` gives exact:

`PC IP -> MAC -> switch port -> access VLAN`

When the switch does not expose the client MAC in BRIDGE-MIB, the fallback remains:

`Router ARP + router subinterface + CDP`

This identifies the managed switch and VLAN, but not the exact access port. The dashboard marks that port as unavailable rather than guessing.

## V4.1 - Import JSON + Persistent Topology Layout

เพิ่มความสามารถต่อยอดจาก V4 ดังนี้

- Import ไฟล์ JSON ที่ Export จากระบบกลับมาแสดงผลบน Web Dashboard ได้
- เพิ่ม `POST /api/import` สำหรับตรวจสอบและโหลด Topology จากไฟล์ JSON
- เพิ่มการบันทึกตำแหน่ง Node (`x`, `y`) ลง SQLite ตาราง `node_positions`
- เมื่อผู้ใช้ลาก Node ระบบจะ Auto-save layout หลังปล่อยเมาส์
- เมื่อเปิดระบบใหม่ Node เดิมจะกลับไปยังตำแหน่งที่บันทึกไว้ โดยอ้างอิงจาก `node_id`
- เพิ่มปุ่ม `Save Layout` สำหรับบันทึกตำแหน่งทั้งหมดด้วยตนเอง
- เพิ่มปุ่ม `Reset Layout` / `Auto Layout` สำหรับล้างตำแหน่งที่บันทึกและกลับไปใช้ Hierarchical Layout
- Export JSON จะรวมตำแหน่ง Node ที่บันทึกไว้ ทำให้ Import แล้วสามารถคืน layout เดิมได้

### API ที่เพิ่ม

- `GET /api/layout` อ่านตำแหน่งที่บันทึก
- `POST /api/layout` บันทึกตำแหน่ง Node
- `DELETE /api/layout` ล้างตำแหน่งทั้งหมด
- `POST /api/import` Import topology JSON

> หมายเหตุ: การคงตำแหน่งข้ามการสแกนต้องอาศัย `node_id` ของอุปกรณ์เดิมที่คงที่ หากอุปกรณ์ถูกสร้างด้วย ID ใหม่ ระบบจะถือว่าเป็น Node ใหม่และใช้ Auto Layout สำหรับ Node นั้น
