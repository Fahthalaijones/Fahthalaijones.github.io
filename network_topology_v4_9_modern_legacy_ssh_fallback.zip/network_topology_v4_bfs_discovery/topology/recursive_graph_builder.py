"""V4 topology builder: evidence-only network graph."""

from collections import defaultdict, deque
from typing import Dict, List, Set

from config import (
    INFER_UNMANAGED_SWITCHES,
    REQUIRE_RECIPROCAL_CDP,
    ROOT_DEVICE_IP,
    SNMP_COMMUNITY,
    UNMANAGED_SWITCH_MIN_DEVICES,
)
from topology.device_identity import make_device_identity
from topology.relationship_engine import (
    build_validated_cdp_links,
    map_direct_router_end_devices,
    map_end_devices_all_switches,
    map_end_devices_via_router_vlan_and_cdp,
    profile_ips,
)


def _type_name(value: str) -> str:
    return {
        "router": "Router",
        "switch": "Managed Switch",
        "unmanaged_switch": "Unmanaged Switch",
        "end_device": "PC / End Device",
    }.get(value, value.replace("_", " ").title())


def _node_id(identity: str) -> str:
    return "device:{}".format(identity)


def _calculate_levels(identities: Set[str], links: List[Dict[str, object]], root: str) -> Dict[str, int]:
    adjacency = defaultdict(set)
    for link in links:
        adjacency[link["source_identity"]].add(link["target_identity"])
        adjacency[link["target_identity"]].add(link["source_identity"])
    levels = {root: 0}
    queue = deque([root])
    while queue:
        current = queue.popleft()
        for neighbor in adjacency[current]:
            if neighbor not in levels:
                levels[neighbor] = levels[current] + 1
                queue.append(neighbor)
    fallback = max(levels.values(), default=0) + 1
    for identity in identities:
        levels.setdefault(identity, fallback)
    return levels


def build_recursive_topology(discovery: Dict[str, object], community: str = SNMP_COMMUNITY, include_end_devices: bool = True):
    profiles: Dict[str, Dict[str, object]] = {}
    ip_index: Dict[str, str] = {}

    for index, profile in enumerate(discovery.get("profiles") or []):
        identity = make_device_identity(profile, fallback=str(index))
        # Identity is management-IP first. This intentionally keeps cloned
        # switches separate even when bridge MAC and sysObjectID are equal.
        profiles[identity] = profile
        for ip_value in profile_ips(profile):
            ip_index[ip_value] = identity

    root_identity = ip_index.get(ROOT_DEVICE_IP)
    if root_identity is None:
        raise RuntimeError("Root device was not present in discovery results")

    cdp_links = build_validated_cdp_links(
        profiles,
        ip_index,
        require_reciprocal=REQUIRE_RECIPROCAL_CDP,
        root_identity=root_identity,
    )
    levels = _calculate_levels(set(profiles), cdp_links, root_identity)
    network_device_ips = set(ip_index)

    nodes: List[dict] = []
    edges: List[dict] = []
    for identity, profile in profiles.items():
        device_type = str(profile.get("device_type") or "network_device")
        query_ip = str(profile.get("query_ip") or "")
        nodes.append({
            "id": _node_id(identity),
            "label": "",
            "display_name": profile.get("hostname") or "Unknown",
            "display_ip": query_ip or "No IP",
            "display_type": _type_name(device_type),
            "hostname": profile.get("hostname") or "Unknown",
            "ip": query_ip,
            "management_ip": query_ip,
            "management_ips": sorted(profile_ips(profile)),
            "device_type": device_type,
            "group": "switch" if device_type == "switch" else device_type,
            "level": levels[identity],
            "vendor": "Cisco" if "cisco" in str(profile.get("description") or "").lower() else "Unknown",
            "model": str(profile.get("description") or "").split(",")[0],
            "description": profile.get("description") or "",
            "discovery": [str(profile.get("access_method") or "SNMP"), "CDP/LLDP"],
            "interfaces": sorted((profile.get("interface_details") or {}).values(), key=lambda row: int(str(row.get("ifindex") or "0")) if str(row.get("ifindex") or "0").isdigit() else 999999),
            "vlans": profile.get("vlan_database") or [],
            "interface_vlan_note": (
                "Access VLAN and trunk state are read through Cisco VLAN MIBs. "
                "A PC port is exact only when its MAC also appears in BRIDGE-MIB; "
                "otherwise the system shows the VLAN inferred from the router subinterface."
                if device_type == "switch" else ""
            ),
        })

    for sequence, link in enumerate(cdp_links, 1):
        edges.append({
            "id": "cdp:{}".format(sequence),
            "from": _node_id(str(link["source_identity"])),
            "to": _node_id(str(link["target_identity"])),
            "label": "{} ↔ {}".format(link["local_interface"], link["remote_interface"]),
            "relation": "cdp",
            "discovery": "CDP",
            "evidence": link["evidence"],
            "local_interface": link["local_interface"],
            "remote_interface": link["remote_interface"],
            "confidence": link["confidence"],
            "arrows": "",
        })

    if not include_end_devices:
        metadata = {
            "root_ip": discovery.get("root_ip") or ROOT_DEVICE_IP,
            "visited_networks": discovery.get("visited_networks") or [],
            "scan_scope": discovery.get("scan_scope") or [],
            "inferred_unmanaged_switches": 0,
            "vlan_cdp_fallback_end_devices": 0,
            "scan_level": discovery.get("scan_level", "topology"),
            "connection_mode": discovery.get("connection_mode", "auto"),
        }
        return nodes, edges, metadata

    end_devices = map_end_devices_all_switches(
        profiles=profiles,
        cdp_links=cdp_links,
        community=community,
        network_device_ips=network_device_ips,
    )
    # Fallback for IOSvL2 images that do not expose Q-BRIDGE-MIB or
    # VLAN-indexed FDB contexts. It can still prove which managed switch owns
    # the VLAN segment by combining Router ARP/subinterface evidence with CDP.
    fdb_mapped = {(row["ip"], row["mac"]) for row in end_devices}
    fallback_end_devices = map_end_devices_via_router_vlan_and_cdp(
        profiles=profiles,
        cdp_links=cdp_links,
        community=community,
        network_device_ips=network_device_ips,
        already_mapped=fdb_mapped,
    )
    end_devices.extend(fallback_end_devices)

    by_switch_port = defaultdict(list)
    for row in end_devices:
        by_switch_port[(row["switch_identity"], row.get("interface") or "Unknown")].append(row)

    inferred_count = 0
    existing_end = set()
    vlan_cdp_fallback_count = 0
    for (switch_identity, port), rows in sorted(by_switch_port.items()):
        switch_id = _node_id(switch_identity)
        switch_level = levels.get(switch_identity, 0)
        infer = (
            INFER_UNMANAGED_SWITCHES
            and port != "Unknown"
            and len(rows) >= UNMANAGED_SWITCH_MIN_DEVICES
        )
        parent_id = switch_id
        child_level = switch_level + 1
        if infer:
            inferred_count += 1
            inferred_id = "inferred:{}:{}".format(
                switch_identity,
                str(port).lower().replace("/", "-").replace(" ", ""),
            )
            nodes.append({
                "id": inferred_id,
                "label": "",
                "display_name": "Unmanaged Switch",
                "display_ip": "No management IP",
                "display_type": "Unmanaged Switch",
                "hostname": "Unmanaged Switch",
                "ip": "-",
                "device_type": "unmanaged_switch",
                "group": "switch",
                "level": child_level,
                "discovery": ["FDB inference"],
                "connected_to": profiles[switch_identity].get("hostname") or "Managed Switch",
                "uplink_port": port,
            })
            edges.append({
                "id": "inferred:{}".format(inferred_count),
                "from": switch_id,
                "to": inferred_id,
                "label": port,
                "relation": "inferred_unmanaged_switch",
                "discovery": "FDB inference",
                "confidence": 75,
                "arrows": "",
            })
            parent_id = inferred_id
            child_level += 1

        for row in rows:
            key = (row["ip"], row["mac"])
            if key in existing_end:
                continue
            existing_end.add(key)
            end_id = "end:{}".format(str(row["mac"]).replace(":", "").lower())
            nodes.append({
                "id": end_id,
                "label": "",
                "display_name": "Unknown",
                "display_ip": row["ip"],
                "display_type": "PC / End Device",
                "hostname": "Unknown",
                "ip": row["ip"],
                "mac": row["mac"],
                "device_type": "end_device",
                "group": "end_device",
                "level": child_level,
                "connected_to": profiles[switch_identity].get("hostname") or "Managed Switch",
                "switch_port": port,
                "vlan": row.get("vlan"),
                "port_known": row.get("port_known", True),
                "discovery": (["ARP", "FDB"] if row.get("relation") == "arp_fdb" else ["ARP", "CDP", "VLAN inference"]),
            })
            if row.get("relation") == "arp_vlan_cdp_fallback":
                vlan_cdp_fallback_count += 1
            edges.append({
                "id": "arp-fdb:{}:{}".format(switch_identity, end_id),
                "from": parent_id,
                "to": end_id,
                "label": port if not infer else "",
                "relation": ("unmanaged_downstream" if infer else row.get("relation", "arp_fdb")),
                "discovery": ("ARP + FDB" if row.get("relation") == "arp_fdb" else "Router ARP + VLAN + CDP"),
                "evidence": row["evidence"],
                "confidence": row["confidence"],
                "arrows": "",
            })

    # Discover PCs connected directly to router Layer-3 interfaces.
    # Entries already mapped through Switch FDB are excluded to prevent duplicates.
    direct_rows = map_direct_router_end_devices(
        profiles=profiles,
        cdp_links=cdp_links,
        community=community,
        network_device_ips=network_device_ips,
        already_mapped=set(existing_end),
    )
    by_router_interface = defaultdict(list)
    for row in direct_rows:
        by_router_interface[(row["router_identity"], row.get("interface") or "Unknown")].append(row)

    direct_count = 0
    for (router_identity, interface), rows in sorted(by_router_interface.items()):
        router_id = _node_id(router_identity)
        router_level = levels.get(router_identity, 0)
        shared = any(bool(row.get("shared_segment")) for row in rows)
        parent_id = router_id
        child_level = router_level + 1

        if shared and INFER_UNMANAGED_SWITCHES:
            inferred_count += 1
            inferred_id = "router-segment:{}:{}".format(
                router_identity,
                str(interface).lower().replace("/", "-").replace(" ", "").replace(".", "-"),
            )
            nodes.append({
                "id": inferred_id,
                "label": "",
                "display_name": "Unmanaged Switch",
                "display_ip": "No management IP",
                "display_type": "Unmanaged Switch",
                "hostname": "Unmanaged Switch",
                "ip": "-",
                "device_type": "unmanaged_switch",
                "group": "switch",
                "level": child_level,
                "discovery": ["Router ARP inference"],
                "connected_to": profiles[router_identity].get("hostname") or "Router",
                "uplink_port": interface,
            })
            edges.append({
                "id": "router-inferred:{}".format(inferred_count),
                "from": router_id,
                "to": inferred_id,
                "label": interface,
                "relation": "inferred_unmanaged_switch",
                "discovery": "Router ARP inference",
                "confidence": 70,
                "arrows": "",
            })
            parent_id = inferred_id
            child_level += 1

        for row in rows:
            key = (row["ip"], row["mac"])
            if key in existing_end:
                continue
            existing_end.add(key)
            direct_count += 1
            end_id = "end:{}".format(str(row["mac"]).replace(":", "").lower())
            nodes.append({
                "id": end_id,
                "label": "",
                "display_name": "Unknown",
                "display_ip": row["ip"],
                "display_type": "PC / End Device",
                "hostname": "Unknown",
                "ip": row["ip"],
                "mac": row["mac"],
                "device_type": "end_device",
                "group": "end_device",
                "level": child_level,
                "connected_to": profiles[router_identity].get("hostname") or "Router",
                "router_interface": interface,
                "discovery": ["ARP", "ifIndex"],
            })
            edges.append({
                "id": "router-arp:{}:{}".format(router_identity, end_id),
                "from": parent_id,
                "to": end_id,
                "label": "" if shared and INFER_UNMANAGED_SWITCHES else interface,
                "relation": "unmanaged_downstream" if shared and INFER_UNMANAGED_SWITCHES else "router_arp_direct",
                "discovery": "Router ARP + ifIndex",
                "evidence": row["evidence"],
                "confidence": row["confidence"],
                "arrows": "",
            })

    metadata = {
        "root_ip": ROOT_DEVICE_IP,
        "network_device_count": len(profiles),
        "end_device_count": len(existing_end),
        "direct_router_end_device_count": direct_count,
        "vlan_cdp_fallback_end_device_count": vlan_cdp_fallback_count,
        "inferred_switch_count": inferred_count,
        "cdp_link_count": len(cdp_links),
        "require_reciprocal_cdp": REQUIRE_RECIPROCAL_CDP,
        "scan_scope": discovery.get("scan_scope", []),
        "visited_networks": discovery.get("visited_networks", []),
    }
    return nodes, edges, metadata
