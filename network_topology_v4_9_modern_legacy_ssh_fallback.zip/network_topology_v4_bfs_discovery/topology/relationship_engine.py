"""Evidence-only relationship engine for V4.

Rules:
- Interface networks and route tables expand scan scope only.
- Network-device edges come only from CDP/LLDP observations.
- End-device edges come only from Router ARP + Switch FDB correlation.
- A CDP edge is accepted only when both endpoints report each other by default.
"""

from collections import defaultdict
from typing import Dict, Iterable, List, Optional, Set, Tuple

from scanner.arp import get_arp_table
from scanner.fdb import get_mac_port_table
from topology.end_device_mapper import normalize_interface_name, normalize_mac


def profile_ips(profile: Dict[str, object]) -> Set[str]:
    values: Set[str] = set()
    for value in profile.get("management_ips") or []:
        if value:
            values.add(str(value))
    if profile.get("query_ip"):
        values.add(str(profile["query_ip"]))
    for row in profile.get("ip_addresses") or []:
        if row.get("ip"):
            values.add(str(row["ip"]))
    return values


def find_neighbor_identity(
    profiles: Dict[str, Dict[str, object]],
    ip_index: Dict[str, str],
    neighbor: Dict[str, object],
) -> Optional[str]:
    management_ip = str(neighbor.get("management_ip") or "").strip()
    if management_ip and management_ip in ip_index:
        return ip_index[management_ip]

    remote_name = str(neighbor.get("remote_device") or "").strip().lower()
    if not remote_name:
        return None

    matches = [
        identity
        for identity, profile in profiles.items()
        if str(profile.get("hostname") or "").strip().lower() == remote_name
    ]
    return matches[0] if len(matches) == 1 else None


def build_cdp_observations(
    profiles: Dict[str, Dict[str, object]],
    ip_index: Dict[str, str],
) -> List[Dict[str, object]]:
    observations: List[Dict[str, object]] = []
    for source_identity, profile in profiles.items():
        for neighbor in profile.get("cdp_neighbors") or []:
            target_identity = find_neighbor_identity(profiles, ip_index, neighbor)
            if not target_identity or target_identity == source_identity:
                continue
            observations.append({
                "source_identity": source_identity,
                "target_identity": target_identity,
                "local_interface": str(neighbor.get("local_port") or "Unknown"),
                "remote_interface": str(neighbor.get("remote_port") or "Unknown"),
                "protocol": "cdp",
            })
    return observations


def build_validated_cdp_links(
    profiles: Dict[str, Dict[str, object]],
    ip_index: Dict[str, str],
    require_reciprocal: bool = True,
    root_identity: Optional[str] = None,
) -> List[Dict[str, object]]:
    """Return deduplicated physical links backed by CDP evidence.

    Reciprocal validation prevents a stale or mismatched one-sided CDP row from
    creating false links such as SW1--R2. Root one-sided links can optionally be
    retained only when reciprocal validation is disabled.
    """
    observations = build_cdp_observations(profiles, ip_index)
    directed: Dict[Tuple[str, str], Dict[str, object]] = {
        (row["source_identity"], row["target_identity"]): row
        for row in observations
    }

    links: List[Dict[str, object]] = []
    seen: Set[Tuple[str, str]] = set()
    for (source, target), forward in directed.items():
        pair = tuple(sorted((source, target)))
        if pair in seen:
            continue

        reverse = directed.get((target, source))
        if require_reciprocal and reverse is None:
            continue

        seen.add(pair)
        if reverse is not None:
            confidence = 100
            evidence = "reciprocal-cdp"
            remote_interface = str(reverse.get("local_interface") or forward.get("remote_interface") or "Unknown")
        else:
            confidence = 80
            evidence = "one-sided-cdp"
            remote_interface = str(forward.get("remote_interface") or "Unknown")

        links.append({
            "source_identity": source,
            "target_identity": target,
            "local_interface": str(forward.get("local_interface") or "Unknown"),
            "remote_interface": remote_interface,
            "relation": "cdp",
            "evidence": evidence,
            "confidence": confidence,
        })
    return links


def cdp_ports_by_device(links: Iterable[Dict[str, object]]) -> Dict[str, Set[str]]:
    result: Dict[str, Set[str]] = defaultdict(set)
    for link in links:
        a = str(link["source_identity"])
        b = str(link["target_identity"])
        result[a].add(normalize_interface_name(str(link.get("local_interface") or "")))
        result[b].add(normalize_interface_name(str(link.get("remote_interface") or "")))
    return result


def collect_router_arp(
    profiles: Dict[str, Dict[str, object]],
    community: str,
) -> Dict[str, List[Dict[str, object]]]:
    result: Dict[str, List[Dict[str, object]]] = {}
    for identity, profile in profiles.items():
        if profile.get("device_type") != "router":
            continue
        query_ip = str(profile.get("query_ip") or "")
        if not query_ip:
            continue
        try:
            result[identity] = get_arp_table(query_ip, community=community)
        except Exception:
            result[identity] = []
    return result


def map_end_devices_all_switches(
    profiles: Dict[str, Dict[str, object]],
    cdp_links: List[Dict[str, object]],
    community: str,
    network_device_ips: Set[str],
) -> List[Dict[str, object]]:
    """Correlate every router ARP table with every switch FDB.

    CDP-facing ports are excluded. Therefore a client MAC learned on an uplink
    is ignored on an upstream switch and attached only to its true access switch.
    """
    router_arp = collect_router_arp(profiles, community)
    cdp_ports = cdp_ports_by_device(cdp_links)

    arp_by_mac: Dict[str, List[Dict[str, object]]] = defaultdict(list)
    for router_identity, entries in router_arp.items():
        for entry in entries:
            ip_value = str(entry.get("ip") or "").strip()
            mac = normalize_mac(str(entry.get("mac") or ""))
            if not ip_value or not mac or ip_value in network_device_ips:
                continue
            arp_by_mac[mac].append({
                "ip": ip_value,
                "mac": mac,
                "router_identity": router_identity,
                "router_ifindex": entry.get("ifindex", ""),
            })

    results: List[Dict[str, object]] = []
    seen: Set[Tuple[str, str, str]] = set()
    for switch_identity, profile in profiles.items():
        if profile.get("device_type") != "switch":
            continue
        switch_ip = str(profile.get("query_ip") or "")
        if not switch_ip:
            continue
        try:
            fdb_rows = get_mac_port_table(switch_ip, community=community)
        except Exception:
            fdb_rows = []

        excluded_ports = cdp_ports.get(switch_identity, set())
        for fdb in fdb_rows:
            mac = normalize_mac(str(fdb.get("mac") or ""))
            interface = str(fdb.get("interface") or "Unknown")
            normalized_port = normalize_interface_name(interface)
            if not mac or normalized_port in excluded_ports:
                continue
            for arp in arp_by_mac.get(mac, []):
                key = (switch_identity, arp["ip"], normalized_port)
                if key in seen:
                    continue
                seen.add(key)
                results.append({
                    **arp,
                    "switch_identity": switch_identity,
                    "switch_ip": switch_ip,
                    "interface": interface,
                    "ifindex": fdb.get("ifindex", ""),
                    "bridge_port": fdb.get("bridge_port", ""),
                    "vlan": fdb.get("vlan"),
                    "vlan_name": fdb.get("vlan_name", ""),
                    "port_known": True,
                    "relation": "arp_fdb",
                    "confidence": 95,
                    "evidence": "Router ARP + Switch FDB; CDP uplinks excluded",
                })
    return results


def _base_interface_name(name: str) -> str:
    """Return normalized parent interface for subinterfaces.

    Example: FastEthernet2/1.10 -> fastethernet2/1. This prevents ARP entries
    learned through router-on-a-stick subinterfaces from being mistaken for
    directly connected PCs when the parent interface has a CDP neighbor.
    """
    normalized = normalize_interface_name(str(name or ""))
    if "." in normalized:
        normalized = normalized.split(".", 1)[0]
    return normalized



def _subinterface_vlan(name: str) -> Optional[int]:
    """Extract a VLAN ID from common router subinterface names.

    Examples:
    - FastEthernet2/1.10 -> 10
    - GigabitEthernet0/0.99 -> 99

    This is an evidence fallback for IOS images that expose router ARP and
    CDP but do not expose per-VLAN FDB through Q-BRIDGE-MIB.
    """
    normalized = normalize_interface_name(str(name or ""))
    if "." not in normalized:
        return None
    suffix = normalized.rsplit(".", 1)[-1]
    try:
        vlan = int(suffix)
    except ValueError:
        return None
    return vlan if 1 <= vlan <= 4094 else None


def _router_switch_trunks(
    profiles: Dict[str, Dict[str, object]],
    cdp_links: List[Dict[str, object]],
) -> Dict[Tuple[str, str], Dict[str, str]]:
    """Return {(router_identity, normalized_parent_if): switch information}."""
    result: Dict[Tuple[str, str], Dict[str, str]] = {}
    for link in cdp_links:
        source = str(link.get("source_identity") or "")
        target = str(link.get("target_identity") or "")
        source_type = str((profiles.get(source) or {}).get("device_type") or "")
        target_type = str((profiles.get(target) or {}).get("device_type") or "")

        if source_type == "router" and target_type == "switch":
            router_identity = source
            switch_identity = target
            router_port = str(link.get("local_interface") or "Unknown")
            switch_port = str(link.get("remote_interface") or "Unknown")
        elif source_type == "switch" and target_type == "router":
            router_identity = target
            switch_identity = source
            router_port = str(link.get("remote_interface") or "Unknown")
            switch_port = str(link.get("local_interface") or "Unknown")
        else:
            continue

        result[(router_identity, _base_interface_name(router_port))] = {
            "switch_identity": switch_identity,
            "router_port": router_port,
            "switch_uplink_port": switch_port,
        }
    return result


def map_end_devices_via_router_vlan_and_cdp(
    profiles: Dict[str, Dict[str, object]],
    cdp_links: List[Dict[str, object]],
    community: str,
    network_device_ips: Set[str],
    already_mapped: Optional[Set[Tuple[str, str]]] = None,
) -> List[Dict[str, object]]:
    """Attach router ARP clients to a directly connected managed switch.

    Used when the switch SNMP agent does not expose a usable per-VLAN FDB.
    Router ARP identifies IP/MAC/ifIndex, the ifIndex identifies a router
    subinterface, and CDP identifies the managed switch connected to the
    subinterface's parent physical interface.

    The exact switch access port cannot be proven without FDB/VLAN membership,
    so the result deliberately reports ``port_known=False``.
    """
    mapped = already_mapped or set()
    trunks = _router_switch_trunks(profiles, cdp_links)
    router_arp = collect_router_arp(profiles, community)
    results: List[Dict[str, object]] = []
    seen: Set[Tuple[str, str, str]] = set()

    for router_identity, entries in router_arp.items():
        profile = profiles.get(router_identity) or {}
        interfaces = profile.get("interfaces") or {}

        for entry in entries:
            ip_value = str(entry.get("ip") or "").strip()
            mac = normalize_mac(str(entry.get("mac") or ""))
            ifindex = str(entry.get("ifindex") or "").strip()
            interface = str(interfaces.get(ifindex) or "ifIndex {}".format(ifindex))
            vlan = _subinterface_vlan(interface)
            trunk = trunks.get((router_identity, _base_interface_name(interface)))

            if not ip_value or not mac or ip_value in network_device_ips:
                continue
            if (ip_value, mac) in mapped:
                continue
            if vlan is None or trunk is None:
                continue

            switch_identity = trunk["switch_identity"]
            key = (switch_identity, ip_value, mac)
            if key in seen:
                continue
            seen.add(key)
            results.append({
                "ip": ip_value,
                "mac": mac,
                "router_identity": router_identity,
                "router_ifindex": ifindex,
                "router_interface": interface,
                "vlan": vlan,
                "switch_identity": switch_identity,
                "switch_ip": str((profiles.get(switch_identity) or {}).get("query_ip") or ""),
                "switch_uplink_port": trunk["switch_uplink_port"],
                "interface": "VLAN {} (port unavailable)".format(vlan),
                "port_known": False,
                "relation": "arp_vlan_cdp_fallback",
                "confidence": 82,
                "evidence": (
                    "Router ARP + router subinterface VLAN + Router/Switch CDP; "
                    "switch per-VLAN FDB unavailable via SNMP"
                ),
            })
    return results

def map_direct_router_end_devices(
    profiles: Dict[str, Dict[str, object]],
    cdp_links: List[Dict[str, object]],
    community: str,
    network_device_ips: Set[str],
    already_mapped: Optional[Set[Tuple[str, str]]] = None,
) -> List[Dict[str, object]]:
    """Find end devices connected directly to router interfaces.

    Evidence used:
    - Router ARP gives IP, MAC and ifIndex.
    - Router ifTable maps ifIndex to an interface name.
    - Interfaces used by CDP links are excluded, including parent interfaces
      of subinterfaces, so clients behind managed switches are not attached
      directly to the router.
    - Devices already correlated through Switch FDB are excluded.

    A single remaining ARP entry on an interface is considered a direct end
    device. Multiple entries are returned as an inferred shared/unmanaged
    segment and can be grouped by the graph builder.
    """
    mapped = already_mapped or set()
    router_arp = collect_router_arp(profiles, community)
    cdp_ports = cdp_ports_by_device(cdp_links)
    results: List[Dict[str, object]] = []

    for router_identity, entries in router_arp.items():
        profile = profiles.get(router_identity) or {}
        interfaces = profile.get("interfaces") or {}
        excluded_exact = cdp_ports.get(router_identity, set())
        excluded_base = {_base_interface_name(port) for port in excluded_exact}

        candidates_by_interface: Dict[str, List[Dict[str, object]]] = defaultdict(list)
        for entry in entries:
            ip_value = str(entry.get("ip") or "").strip()
            mac = normalize_mac(str(entry.get("mac") or ""))
            ifindex = str(entry.get("ifindex") or "").strip()
            interface = str(interfaces.get(ifindex) or "ifIndex {}".format(ifindex))
            normalized = normalize_interface_name(interface)
            base = _base_interface_name(interface)

            if not ip_value or not mac or ip_value in network_device_ips:
                continue
            if (ip_value, mac) in mapped:
                continue
            if normalized in excluded_exact or base in excluded_base:
                continue

            candidates_by_interface[interface].append({
                "ip": ip_value,
                "mac": mac,
                "router_identity": router_identity,
                "router_ifindex": ifindex,
                "interface": interface,
            })

        for interface, rows in candidates_by_interface.items():
            shared_segment = len(rows) > 1
            for row in rows:
                results.append({
                    **row,
                    "relation": "router_arp_direct" if not shared_segment else "router_arp_shared_segment",
                    "confidence": 90 if not shared_segment else 70,
                    "shared_segment": shared_segment,
                    "evidence": (
                        "Router ARP ifIndex mapped to a non-CDP interface"
                        if not shared_segment
                        else "Multiple Router ARP entries on one non-CDP interface; inferred unmanaged/shared segment"
                    ),
                })

    return results
