# V4 BFS Discovery Core

## Topology target

```
Cloud
  |
 R1
 |-- Switch2
 |-- SW-Ubon
 |    |-- Switch1
 |    |    |-- PC3
 |    |    |-- PC4
 |    |    `-- PC6
 |    `-- PC7
 `-- R2
      |-- IOU2 -- PC2
      `-- IOU3 -- PC5
```

## Core rules

1. Only `ROOT_DEVICE_IP` is configured.
2. BFS queue contains routers and managed switches only.
3. CDP recursively seeds direct network-device neighbors.
4. Interface networks and route tables expand scan scope only.
5. Nmap/SNMP is fallback discovery and never creates topology links.
6. Network-device links require reciprocal CDP by default.
7. End-device links require Router ARP + Switch FDB.
8. Every CDP-facing switch port is excluded from end-device attachment, so a
   MAC learned through an uplink is not drawn under the upstream switch.

## Test

```bash
python3 test_v4_relationships.py
python3 test_recursive_discovery.py
python3 app.py
```

Open `http://<ubuntu-ip>:5000` and press Scan.

If a real direct link is missing because only one endpoint exposes CDP, set:

```python
REQUIRE_RECIPROCAL_CDP = False
```

For the supplied GNS3 design, keep it `True` while CDP is enabled on all router
and switch links.

## V4.1 identity correction for cloned GNS3 switches

The identity engine now uses the SNMP query/management IP as its primary key.
`sysObjectID` and `dot1dBaseBridgeAddress` remain display and diagnostic values
only. This prevents cloned IOSvL2 nodes such as SW-Ubon, SW-Amnat and
SW-Sisaket from being merged when all three report the same model and bridge
MAC.

Run the offline regression test:

```bash
python3 test_v4_identity.py
```

Expected result:

```text
PASS: cloned switches remain separate and CDP links resolve by management IP
```
