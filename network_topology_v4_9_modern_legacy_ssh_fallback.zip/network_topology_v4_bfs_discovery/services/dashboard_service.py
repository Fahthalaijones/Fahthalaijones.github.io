from collections import Counter
from datetime import datetime
from time import perf_counter
from typing import Dict, List, Optional

from config import SNMP_COMMUNITY
from services.recursive_discovery_service import discover_recursive
from topology.recursive_graph_builder import build_recursive_topology


def _device_rows(nodes: List[dict]) -> List[dict]:
    rows = []
    for node in nodes:
        rows.append({
            "id": node.get("id", ""),
            "ip": node.get("ip") or node.get("management_ip") or "-",
            "hostname": node.get("hostname") or "Unknown",
            "mac": node.get("mac") or "-",
            "device_type": node.get("device_type") or "unknown",
            "vendor": node.get("vendor") or "Unknown",
            "connected_to": node.get("connected_to") or "-",
            "port": node.get("switch_port") or node.get("uplink_port") or "-",
            "discovery": " + ".join(node.get("discovery") or []),
        })
    return rows


def run_discovery(options: Optional[Dict[str, object]] = None) -> Dict[str, object]:
    options = dict(options or {})
    scan_level = str(options.get("scan_level") or "full").strip().lower()
    if scan_level not in {"topology", "end_devices", "full"}:
        scan_level = "full"

    connection_mode = str(options.get("connection_mode") or "auto").strip().lower()
    if connection_mode not in {"auto", "snmp", "ssh"}:
        connection_mode = "auto"

    supplied_community = options.get("snmp_community")
    community = str(SNMP_COMMUNITY if supplied_community is None else supplied_community).strip()
    ssh = dict(options.get("ssh") or {})
    root_ips = list(options.get("root_ips") or [])

    started = perf_counter()
    discovery = discover_recursive(
        scan_level=scan_level,
        community=community,
        connection_mode=connection_mode,
        ssh=ssh,
        root_ips=root_ips,
    )
    nodes, edges, metadata = build_recursive_topology(
        discovery,
        community=community,
        include_end_devices=(scan_level != "topology"),
    )
    duration = round(perf_counter() - started, 2)
    scanned_at = datetime.now().astimezone().isoformat(timespec="seconds")

    counts = Counter(node.get("device_type", "unknown") for node in nodes)
    relation_counts = Counter(edge.get("relation", "unknown") for edge in edges)

    summary = {
        "total_devices": len(nodes),
        "router_count": counts.get("router", 0),
        "switch_count": counts.get("switch", 0) + counts.get("unmanaged_switch", 0),
        "managed_switch_count": counts.get("switch", 0),
        "unmanaged_switch_count": counts.get("unmanaged_switch", 0),
        "end_device_count": counts.get("end_device", 0),
        "link_count": len(edges),
        "cdp_links": relation_counts.get("cdp", 0),
        "arp_fdb_links": relation_counts.get("arp_fdb", 0)
        + relation_counts.get("unmanaged_downstream", 0),
        "inferred_switch_links": relation_counts.get("inferred_unmanaged_switch", 0),
        "scan_time": scanned_at,
        "scan_duration_seconds": duration,
        "scan_level": scan_level,
        "connection_mode": connection_mode,
        "target_network": ", ".join(discovery.get("visited_networks", [])),
        "management_network": discovery.get("visited_networks", [""])[0]
        if discovery.get("visited_networks")
        else "",
        "gateway_ip": ", ".join(discovery.get("root_ips") or [metadata.get("root_ip", "")]).strip(", "),
        "switch_management_ips": [
            node.get("ip")
            for node in nodes
            if node.get("device_type") == "switch"
        ],
    }

    return {
        "nodes": nodes,
        "edges": edges,
        "metadata": metadata,
        "summary": summary,
        "devices": _device_rows(nodes),
        "services": [],
    }
