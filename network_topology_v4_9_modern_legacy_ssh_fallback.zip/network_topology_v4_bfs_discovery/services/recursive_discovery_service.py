"""V4 BFS discovery core.

The queue contains only SNMP network devices. CDP recursively discovers direct
neighbors. Router interfaces/routes only expand scan scope; they never create
edges. Nmap/SNMP scanning is a fallback to find network devices not exposed by
CDP.
"""

import ipaddress
from collections import deque
from typing import Dict, Set

from config import (
    MAX_DISCOVERED_NETWORKS,
    MAX_DISCOVERY_DEPTH,
    MAX_HOSTS_PER_NETWORK,
    PRIVATE_NETWORKS_ONLY,
    ROOT_DEVICE_IP,
    SNMP_COMMUNITY,
    SNMP_PROBE_WORKERS,
)
from scanner.device_profiler import build_device_profile
from scanner.host_discovery import discover_alive_hosts
from scanner.network_expander import networks_from_profile
from scanner.snmp_probe import find_snmp_hosts, responds_to_snmp
from scanner.ssh_collector import build_ssh_device_profile, can_connect_ssh
from topology.device_identity import make_device_identity


def _identity(profile: Dict[str, object]) -> str:
    """Use management IP as the primary identity.

    Cloned GNS3 IOSvL2 nodes can share sysObjectID and bridge MAC, so neither
    value may be used alone for deduplication.
    """
    return make_device_identity(profile)


def _safe_network(text: str) -> bool:
    try:
        network = ipaddress.ip_network(text, strict=False)
    except ValueError:
        return False
    if network.version != 4:
        return False
    if PRIVATE_NETWORKS_ONLY and not network.is_private:
        return False
    return network.num_addresses <= MAX_HOSTS_PER_NETWORK


def _merge_profile(existing: Dict[str, object], new: Dict[str, object]) -> None:
    """Merge observations that belong to the same logical device.

    This is especially important for routers: the same router may be probed
    through several interface IP addresses discovered from route/network scans.
    """
    ips = set(existing.get("management_ips") or [])
    ips.update(new.get("management_ips") or [])
    for profile in (existing, new):
        if profile.get("query_ip"):
            ips.add(str(profile["query_ip"]))
        for row in profile.get("ip_addresses") or []:
            if row.get("ip"):
                ips.add(str(row["ip"]))
    existing["management_ips"] = sorted(ips)

    def merge_rows(field: str, key_fields):
        merged = {}
        for row in list(existing.get(field) or []) + list(new.get(field) or []):
            key = tuple(str(row.get(name) or "") for name in key_fields)
            merged[key] = row
        existing[field] = list(merged.values())

    merge_rows("cdp_neighbors", ("local_ifindex", "remote_device", "management_ip"))
    merge_rows("ip_addresses", ("ip", "netmask", "ifindex"))
    merge_rows("route_networks", ("network", "next_hop", "ifindex"))
    merge_rows("arp_entries", ("ip", "mac", "ifindex"))

    # Preserve the configured/root query IP as the preferred display address.
    if existing.get("discovered_by") != "configured-root" and new.get("discovered_by") == "configured-root":
        existing["query_ip"] = new.get("query_ip")
        existing["discovered_by"] = "configured-root"


def discover_recursive(
    scan_level: str = "full",
    community: str = SNMP_COMMUNITY,
    connection_mode: str = "auto",
    ssh: Dict[str, object] = None,
    root_ips=None,
) -> Dict[str, object]:
    """Discover network devices using SNMP first with optional SSH fallback.

    scan_level:
      topology    - fastest; follows CDP/LLDP neighbor relationships and avoids
                    broad subnet host sweeps plus end-device enrichment.
      end_devices - includes subnet discovery and endpoint mapping.
      full        - current full discovery behavior.
    """
    scan_level = str(scan_level or "full").strip().lower()
    if scan_level not in {"topology", "end_devices", "full"}:
        scan_level = "full"
    connection_mode = str(connection_mode or "auto").strip().lower()
    if connection_mode not in {"auto", "snmp", "ssh"}:
        connection_mode = "auto"
    ssh = dict(ssh or {})
    ssh_enabled = bool(ssh.get("enabled") and ssh.get("username"))

    def collect_profile(ip: str):
        snmp_ok = False
        if connection_mode in {"auto", "snmp"} and community:
            try:
                snmp_ok = responds_to_snmp(ip, community)
            except Exception:
                snmp_ok = False
            if snmp_ok:
                profile = build_device_profile(ip, community, scan_level=scan_level)
                profile["access_method"] = "SNMP"
                return profile

        if connection_mode in {"auto", "ssh"} and ssh_enabled:
            try:
                profile = build_ssh_device_profile(ip, ssh, scan_level=scan_level)
                profile["access_method"] = "SSH"
                return profile
            except Exception:
                if connection_mode == "ssh":
                    raise
        return None

    requested_roots = []
    for value in list(root_ips or []):
        value = str(value or "").strip()
        if value and value not in requested_roots:
            requested_roots.append(value)
    if not requested_roots:
        requested_roots = [ROOT_DEVICE_IP]

    root_entries = []
    root_errors = []
    for root_ip in requested_roots:
        try:
            root_profile = collect_profile(root_ip)
        except Exception as exc:
            root_profile = None
            root_errors.append("{}: {}".format(root_ip, exc))
        if root_profile is not None:
            root_entries.append((root_ip, 0, "configured-root", root_profile))
        else:
            root_errors.append("{}: inaccessible".format(root_ip))

    if not root_entries:
        detail = "; ".join(root_errors) if root_errors else "no reachable root device"
        if connection_mode == "snmp":
            raise RuntimeError("None of the Root IPs answer SNMP with the supplied community ({})".format(detail))
        if connection_mode == "ssh":
            raise RuntimeError("None of the Root IPs could be accessed by SSH ({})".format(detail))
        raise RuntimeError("None of the Root IPs are accessible by SNMP or the supplied SSH credentials ({})".format(detail))

    active_root_ips = [entry[0] for entry in root_entries]
    device_queue = deque(root_entries)
    network_queue = deque()
    queued_device_ips: Set[str] = set(active_root_ips)
    visited_query_ips: Set[str] = set()
    queued_networks: Set[str] = set()
    visited_networks: Set[str] = set()
    profiles_by_identity: Dict[str, Dict[str, object]] = {}
    identity_by_ip: Dict[str, str] = {}
    scan_scope: Dict[str, Dict[str, object]] = {}
    discovered_hosts: Dict[str, Dict[str, str]] = {}

    def queue_device(ip: str, depth: int, evidence: str, prefetched=None) -> None:
        ip = str(ip or "").strip()
        if not ip or ip in visited_query_ips or ip in queued_device_ips:
            return
        if depth > MAX_DISCOVERY_DEPTH:
            return
        device_queue.append((ip, depth, evidence, prefetched))
        queued_device_ips.add(ip)

    def queue_network(network: str, depth: int, source: str, evidence: str) -> None:
        if scan_level == "topology":
            return
        if not _safe_network(network):
            return
        if network in visited_networks or network in queued_networks:
            return
        if len(visited_networks) + len(queued_networks) >= MAX_DISCOVERED_NETWORKS:
            return
        network_queue.append((network, depth, source, evidence))
        queued_networks.add(network)
        scan_scope[network] = {
            "network": network,
            "source_device": source,
            "scope_evidence": evidence,
        }

    while device_queue or network_queue:
        if device_queue:
            query_ip, depth, discovered_by, prefetched = device_queue.popleft()
            queued_device_ips.discard(query_ip)
            if query_ip in visited_query_ips or depth > MAX_DISCOVERY_DEPTH:
                continue
            visited_query_ips.add(query_ip)

            try:
                profile = prefetched or collect_profile(query_ip)
            except Exception:
                profile = None
            if not profile:
                continue

            if profile.get("device_type") not in {"router", "switch"}:
                continue

            profile["discovered_by"] = discovered_by
            profile["management_ips"] = sorted({
                query_ip,
                *[
                    str(row.get("ip"))
                    for row in profile.get("ip_addresses") or []
                    if row.get("ip")
                ],
            })
            identity = _identity(profile)
            if identity in profiles_by_identity:
                _merge_profile(profiles_by_identity[identity], profile)
                profile = profiles_by_identity[identity]
            else:
                profiles_by_identity[identity] = profile

            for ip_value in profile.get("management_ips") or []:
                identity_by_ip[str(ip_value)] = identity

            source_name = str(profile.get("hostname") or query_ip)
            for network in networks_from_profile(
                profile,
                private_only=PRIVATE_NETWORKS_ONLY,
                max_hosts=MAX_HOSTS_PER_NETWORK,
            ):
                queue_network(network, depth + 1, source_name, "interface-network")

            for route in profile.get("route_networks") or []:
                if route.get("network"):
                    queue_network(str(route["network"]), depth + 1, source_name, "route-table")

            for neighbor in profile.get("cdp_neighbors") or []:
                queue_device(str(neighbor.get("management_ip") or ""), depth + 1, str(neighbor.get("protocol") or "CDP").lower() + "-neighbor")
            continue

        # In endpoint/full modes, subnet scanning is the fallback for network
        # devices not exposed by CDP/LLDP.
        network, depth, source, evidence = network_queue.popleft()
        queued_networks.discard(network)
        if network in visited_networks or depth > MAX_DISCOVERY_DEPTH:
            continue
        visited_networks.add(network)

        hosts = discover_alive_hosts(network)
        for host in hosts:
            discovered_hosts[host["ip"]] = host

        candidate_ips = [row["ip"] for row in hosts]
        if connection_mode in {"auto", "snmp"} and community:
            snmp_ips = find_snmp_hosts(
                candidate_ips,
                community=community,
                max_workers=SNMP_PROBE_WORKERS,
            )
            for ip_value in snmp_ips:
                queue_device(ip_value, depth, "network-scan:{}".format(network))

        # SSH fallback is intentionally tried only for addresses already found
        # alive.  This prevents SSH connection attempts against every address
        # in a subnet.
        if connection_mode in {"auto", "ssh"} and ssh_enabled:
            for ip_value in candidate_ips:
                if ip_value in visited_query_ips or ip_value in queued_device_ips:
                    continue
                if can_connect_ssh(ip_value, ssh):
                    queue_device(ip_value, depth, "ssh-network-scan:{}".format(network))

    return {
        "root_ip": active_root_ips[0],
        "root_ips": active_root_ips,
        "requested_root_ips": requested_roots,
        "profiles": list(profiles_by_identity.values()),
        "identity_by_ip": identity_by_ip,
        "visited_networks": sorted(visited_networks),
        "scan_scope": [scan_scope[key] for key in sorted(scan_scope)],
        "discovered_hosts": list(discovered_hosts.values()),
        "routes": [],
        "scan_level": scan_level,
        "connection_mode": connection_mode,
    }
