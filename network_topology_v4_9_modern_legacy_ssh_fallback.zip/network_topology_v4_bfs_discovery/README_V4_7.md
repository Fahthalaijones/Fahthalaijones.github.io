# V4.7 - Scan Levels, Discovery Settings, SSH Fallback, Responsive Sidebars

## New UI
- Scan Level buttons: Topology / End Devices / Full Scan
- Settings modal: Auto / SNMP / SSH
- Custom SNMP v2c community per scan
- SSH fallback credentials per scan (not persisted in SQLite)
- Scrollable left/right sidebars so panels remain usable at browser zoom or shorter viewport heights
- Router icon arrows: left/right inward; top/bottom outward

## Scan behavior
- Topology: quickest mode, follows CDP/LLDP neighbor relationships and skips broad subnet host sweeps/end-device mapping.
- End Devices: adds subnet discovery and ARP/FDB end-device mapping.
- Full Scan: current complete discovery path.

## SSH fallback
Requires Netmiko. Install/update dependencies:

    pip3 install -r requirements.txt

In Auto mode, SNMP is attempted first. If SNMP is unavailable and SSH fallback is enabled, the server uses SSH CLI collection for core topology data.
