"""Focused Phase 2 diagnostics for ARP and FDB."""
from pprint import pprint

from config import ROOT_DEVICE_IP, SWITCH_DEVICE_IPS, SNMP_COMMUNITY
from scanner.arp import get_arp_table
from scanner.fdb import get_mac_port_table
from scanner.snmp import snmp_walk

ARP_OID = "1.3.6.1.2.1.4.22.1.2"
FDB_OID = "1.3.6.1.2.1.17.4.3.1.2"

print("=== RAW/FORMATTED ROUTER ARP OID ===")
pprint(snmp_walk(ROOT_DEVICE_IP, ARP_OID, SNMP_COMMUNITY))
print("\n=== PARSED ROUTER ARP ===")
pprint(get_arp_table(ROOT_DEVICE_IP, SNMP_COMMUNITY))

for switch_ip in SWITCH_DEVICE_IPS:
    print(f"\n=== RAW FDB PORT OID {switch_ip} ===")
    pprint(snmp_walk(switch_ip, FDB_OID, SNMP_COMMUNITY))
    print(f"\n=== PARSED FDB {switch_ip} ===")
    pprint(get_mac_port_table(switch_ip, SNMP_COMMUNITY))
