# V4.9 - Modern SSH + Legacy Cisco IOS fallback

SSH discovery now tries normal Netmiko/Paramiko negotiation first. If the connection fails specifically because of KEX/host-key/cipher negotiation, the collector retries only that device with a legacy Cisco IOS profile.

Legacy fallback candidates:
- KEX: diffie-hellman-group14-sha1, diffie-hellman-group-exchange-sha1, diffie-hellman-group1-sha1
- Host key: ssh-rsa
- Cipher: aes256-cbc, aes128-cbc, aes192-cbc, 3des-cbc

Modern devices continue to use Netmiko defaults; legacy algorithms are not enabled globally and are only relaxed per failed legacy connection.
