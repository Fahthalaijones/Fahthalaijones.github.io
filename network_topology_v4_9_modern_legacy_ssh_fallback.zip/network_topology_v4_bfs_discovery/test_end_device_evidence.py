from pprint import pprint

from config import ROOT_DEVICE_IP, SNMP_COMMUNITY, SWITCH_DEVICE_IPS
from scanner.arp import get_arp_table, normalize_mac
from scanner.cdp import get_cdp_neighbors
from scanner.fdb import get_mac_port_table
from scanner.device import get_device
from topology.end_device_mapper import map_end_devices

arp_rows = get_arp_table(ROOT_DEVICE_IP, SNMP_COMMUNITY)
cdp_rows = get_cdp_neighbors(ROOT_DEVICE_IP, SNMP_COMMUNITY)

for switch_ip in SWITCH_DEVICE_IPS:
    switch_name = get_device(switch_ip, SNMP_COMMUNITY).get("hostname") or switch_ip
    cdp = next(
        (
            row for row in cdp_rows
            if row.get("management_ip") == switch_ip
            or row.get("remote_device", "").lower() == switch_name.lower()
        ),
        None,
    )
    uplink = cdp.get("remote_port") if cdp else None
    fdb_rows = get_mac_port_table(switch_ip, SNMP_COMMUNITY)
    fdb_macs = {normalize_mac(row.get("mac", "")) for row in fdb_rows}

    print(f"=== SWITCH {switch_ip} ===")
    print("CDP switch-side uplink:", uplink)
    print("\nARP entries with FDB evidence:")
    for arp in arp_rows:
        status = "MATCH" if normalize_mac(arp.get("mac", "")) in fdb_macs else "NO FDB ENTRY"
        print(f'{arp.get("ip"):15} {arp.get("mac"):17} {status}')

    print("\nEnd devices after uplink filtering:")
    pprint(
        map_end_devices(
            ROOT_DEVICE_IP,
            switch_ip,
            SNMP_COMMUNITY,
            excluded_ips={ROOT_DEVICE_IP, switch_ip},
            excluded_interfaces={uplink} if uplink else set(),
        )
    )
