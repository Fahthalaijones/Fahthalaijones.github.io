from pprint import pprint

from config import ROOT_DEVICE_IP, SNMP_COMMUNITY, SWITCH_DEVICE_IPS
from scanner.arp import get_arp_table
from scanner.fdb import get_mac_port_table
from scanner.ip_address import get_interface_ipv4_addresses, get_management_ipv4
from topology.end_device_mapper import map_end_devices
from topology.graph_builder import build_phase2_topology


print("=== ROUTER ARP ===")
pprint(get_arp_table(ROOT_DEVICE_IP, SNMP_COMMUNITY))

for switch_ip in SWITCH_DEVICE_IPS:
    print(f"\n=== SWITCH {switch_ip} IP ADDRESSES ===")
    pprint(get_interface_ipv4_addresses(switch_ip, SNMP_COMMUNITY))
    print("Selected management/SVI:")
    pprint(get_management_ipv4(switch_ip, SNMP_COMMUNITY, ("vlan1",)))

    print(f"\n=== SWITCH {switch_ip} FDB ===")
    pprint(get_mac_port_table(switch_ip, SNMP_COMMUNITY))

    print(f"\n=== MATCHED END DEVICES ON {switch_ip} ===")
    pprint(
        map_end_devices(
            ROOT_DEVICE_IP,
            switch_ip,
            SNMP_COMMUNITY,
            excluded_ips={ROOT_DEVICE_IP, switch_ip},
        )
    )

print("\n=== PHASE 2 GRAPH ===")
nodes, edges, metadata = build_phase2_topology(
    ROOT_DEVICE_IP,
    SWITCH_DEVICE_IPS,
    SNMP_COMMUNITY,
)
pprint(metadata)
pprint(nodes)
pprint(edges)
