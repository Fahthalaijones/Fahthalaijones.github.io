"""SSH/CLI fallback collector for network discovery.

This module is intentionally optional.  The project keeps SNMP as the primary
collector, but when an operator supplies SSH credentials the discovery engine
can obtain the core topology evidence through CLI commands instead.
"""

import ipaddress
import re
import socket
import time
from typing import Dict, List, Optional


def _netmiko():
    try:
        from netmiko import ConnectHandler, SSHDetect
    except ImportError:
        raise RuntimeError(
            "SSH fallback requires Netmiko. Install it with: pip3 install netmiko"
        )
    return ConnectHandler, SSHDetect


def _device_type_name(value: str) -> str:
    value = (value or "auto").strip().lower()
    return {
        "cisco_ios": "cisco_ios",
        "cisco": "cisco_ios",
        "mikrotik_routeros": "mikrotik_routeros",
        "mikrotik": "mikrotik_routeros",
    }.get(value, "auto")


LEGACY_KEX = (
    "diffie-hellman-group14-sha1",
    "diffie-hellman-group-exchange-sha1",
    "diffie-hellman-group1-sha1",
)
LEGACY_CIPHERS = ("aes256-cbc", "aes128-cbc", "aes192-cbc", "3des-cbc")
LEGACY_HOST_KEYS = ("ssh-rsa",)


def _prepend_supported(preferred, current):
    """Prepend legacy algorithms only when Paramiko itself supports them."""
    result = []
    for item in tuple(preferred) + tuple(current):
        if item in current and item not in result:
            result.append(item)
    return tuple(result)


class _LegacyCiscoConnection:
    """Small Paramiko shell wrapper for old Cisco IOS SSH stacks.

    It is used only after a normal Netmiko connection fails because of SSH
    algorithm negotiation.  This keeps modern SSH defaults unchanged for new
    equipment while allowing legacy C7200/old IOS images as a fallback.
    """

    def __init__(self, ip, username, password, port=22, timeout=8):
        try:
            import paramiko
        except ImportError:
            raise RuntimeError("Legacy SSH fallback requires Paramiko (installed with Netmiko)")

        self._paramiko = paramiko
        self._sock = socket.create_connection((ip, int(port)), timeout=timeout)
        self._transport = paramiko.Transport(self._sock)
        self._transport.banner_timeout = timeout
        self._transport.auth_timeout = timeout

        # Paramiko still contains support for these older algorithms on many
        # installations, but they are intentionally not preferred.  Restrict
        # the relaxation to THIS connection only; system/global SSH policy is
        # never changed.
        sec = self._transport.get_security_options()
        sec.kex = _prepend_supported(LEGACY_KEX, sec.kex)
        sec.ciphers = _prepend_supported(LEGACY_CIPHERS, sec.ciphers)
        sec.key_types = _prepend_supported(LEGACY_HOST_KEYS, sec.key_types)

        self._transport.start_client(timeout=timeout)
        self._transport.auth_password(username=username, password=password)
        self._channel = self._transport.open_session(timeout=timeout)
        self._channel.get_pty(term="vt100", width=200, height=1000)
        self._channel.invoke_shell()
        self._channel.settimeout(0.5)
        time.sleep(0.35)
        self._drain()

        # Avoid --More-- during discovery commands on Cisco IOS.
        self._channel.send("terminal length 0\n")
        time.sleep(0.2)
        self._drain()

    def _drain(self):
        chunks = []
        while self._channel.recv_ready():
            chunks.append(self._channel.recv(65535).decode("utf-8", errors="ignore"))
        return "".join(chunks)

    def _read_command(self, command, timeout=12):
        deadline = time.time() + timeout
        chunks = []
        last_data = time.time()
        while time.time() < deadline:
            if self._channel.recv_ready():
                data = self._channel.recv(65535).decode("utf-8", errors="ignore")
                chunks.append(data)
                last_data = time.time()
                text = "".join(chunks)
                # Cisco prompt normally ends in > or #.  Wait a little after
                # seeing it so wrapped output has time to arrive.
                if re.search(r"[>#]\s*$", text) and time.time() - last_data >= 0.08:
                    break
            else:
                if chunks and time.time() - last_data > 0.35:
                    text = "".join(chunks)
                    if re.search(r"[>#]\s*$", text):
                        break
                time.sleep(0.05)
        return "".join(chunks)

    def send_command(self, command, read_timeout=12):
        self._drain()
        self._channel.send(str(command).rstrip() + "\n")
        output = self._read_command(command, timeout=read_timeout)
        # Remove command echo and trailing prompt where practical.
        lines = output.replace("\r", "").splitlines()
        if lines and lines[0].strip() == str(command).strip():
            lines = lines[1:]
        if lines and re.match(r"^\S+[>#]\s*$", lines[-1].strip()):
            lines = lines[:-1]
        return "\n".join(lines)

    def find_prompt(self):
        self._drain()
        self._channel.send("\n")
        output = self._read_command("", timeout=3).replace("\r", "")
        lines = [line.strip() for line in output.splitlines() if line.strip()]
        for line in reversed(lines):
            if re.match(r"^\S+[>#]$", line):
                return line
        return lines[-1] if lines else "Unknown#"

    def disconnect(self):
        try:
            self._channel.close()
        except Exception:
            pass
        try:
            self._transport.close()
        except Exception:
            pass
        try:
            self._sock.close()
        except Exception:
            pass


def _is_algorithm_negotiation_error(exc):
    text = str(exc).lower()
    return any(token in text for token in (
        "no acceptable kex",
        "no matching key exchange",
        "incompatible ssh peer",
        "no matching host key",
        "no matching cipher",
        "incompatiblepeer",
        "key exchange method",
    ))


def _connect_legacy(ip: str, ssh: Dict[str, object]):
    username = str(ssh.get("username") or "").strip()
    password = str(ssh.get("password") or "")
    port = int(ssh.get("port") or 22)
    conn = _LegacyCiscoConnection(ip, username, password, port=port)
    return conn, "cisco_ios_legacy"


def _connect(ip: str, ssh: Dict[str, object]):
    ConnectHandler, SSHDetect = _netmiko()
    username = str(ssh.get("username") or "").strip()
    password = str(ssh.get("password") or "")
    port = int(ssh.get("port") or 22)
    requested = _device_type_name(str(ssh.get("device_type") or "auto"))
    if not username:
        raise RuntimeError("SSH username is required")

    base = {
        "host": ip,
        "username": username,
        "password": password,
        "port": port,
        "conn_timeout": 5,
        "banner_timeout": 6,
        "auth_timeout": 6,
        "fast_cli": True,
    }

    # 1) Always try normal modern Netmiko/Paramiko defaults first.
    try:
        if requested == "auto":
            detector = SSHDetect(device_type="autodetect", **base)
            detected = detector.autodetect()
            if not detected:
                detected = "cisco_ios"
            base["device_type"] = detected
        else:
            base["device_type"] = requested
        return ConnectHandler(**base), base["device_type"]
    except Exception as exc:
        # 2) Only relax algorithms when negotiation itself failed.  Bad
        # username/password, timeout, routing errors, etc. are NOT retried as
        # legacy SSH.  This preserves normal behavior for modern devices.
        if not _is_algorithm_negotiation_error(exc):
            raise
        return _connect_legacy(ip, ssh)


def can_connect_ssh(ip: str, ssh: Dict[str, object]) -> bool:
    conn = None
    try:
        conn, _ = _connect(ip, ssh)
        return True
    except Exception:
        return False
    finally:
        if conn is not None:
            try:
                conn.disconnect()
            except Exception:
                pass


def _safe_command(conn, command: str) -> str:
    try:
        return conn.send_command(command, read_timeout=12) or ""
    except Exception:
        return ""


def _hostname_from_prompt(prompt: str) -> str:
    return re.sub(r"[>#\s]+$", "", str(prompt or "").strip()) or "Unknown"


def _parse_interfaces(text: str):
    interface_map: Dict[str, str] = {}
    details: Dict[str, dict] = {}
    addresses: List[dict] = []
    idx = 1
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line or line.lower().startswith("interface"):
            continue
        parts = re.split(r"\s+", line)
        if len(parts) < 5:
            continue
        name, ip_value = parts[0], parts[1]
        status = parts[-2]
        protocol = parts[-1]
        if not re.match(r"^[A-Za-z]", name):
            continue
        key = str(idx)
        interface_map[key] = name
        details[key] = {
            "ifindex": key,
            "name": name,
            "description": "",
            "admin_status": "up" if status.lower() not in {"administratively", "disabled"} else "down",
            "status": protocol,
            "speed": "",
            "mtu": "",
            "mac": "",
            "ip_addresses": [],
            "interface_kind": "SVI" if name.lower().startswith("vlan") else "Physical/Logical",
        }
        try:
            ipaddress.ip_address(ip_value)
            row = {"ip": ip_value, "netmask": "", "ifindex": key}
            addresses.append(row)
            details[key]["ip_addresses"].append({"ip": ip_value, "netmask": ""})
        except ValueError:
            pass
        idx += 1
    return interface_map, details, addresses


def _parse_neighbors(text: str, source: str = "CDP") -> List[dict]:
    neighbors = []
    blocks = re.split(r"(?=Device ID:|Local Intf:|Chassis id:)", text or "", flags=re.I)
    for block in blocks:
        device = re.search(r"(?:Device ID|System Name)\s*:\s*([^\r\n]+)", block, re.I)
        mgmt = re.search(r"(?:IP address|Management Address|Management address)\s*:\s*([0-9.]+)", block, re.I)
        local = re.search(r"(?:Interface|Local Intf)\s*:\s*([^,\r\n]+)", block, re.I)
        remote = re.search(r"(?:Port ID \(outgoing port\)|Port id|Port ID)\s*:\s*([^\r\n]+)", block, re.I)
        if not device and not mgmt:
            continue
        neighbors.append({
            "remote_device": (device.group(1).strip() if device else "Unknown"),
            "management_ip": (mgmt.group(1).strip() if mgmt else ""),
            "local_interface": (local.group(1).strip() if local else "Unknown"),
            "remote_interface": (remote.group(1).strip() if remote else "Unknown"),
            "local_ifindex": "",
            "protocol": source,
        })
    return neighbors


def _parse_routes(text: str) -> List[dict]:
    results = []
    seen = set()
    for line in (text or "").splitlines():
        # Match route prefixes such as 192.168.10.0/24. Host /32 routes are ignored.
        for match in re.finditer(r"\b((?:\d{1,3}\.){3}\d{1,3})/(\d{1,2})\b", line):
            cidr = match.group(0)
            if cidr in seen:
                continue
            try:
                network = ipaddress.ip_network(cidr, strict=False)
            except ValueError:
                continue
            if network.prefixlen >= 31:
                continue
            seen.add(str(network))
            next_hop = ""
            via = re.search(r"via\s+((?:\d{1,3}\.){3}\d{1,3})", line, re.I)
            if via:
                next_hop = via.group(1)
            results.append({"network": str(network), "next_hop": next_hop, "ifindex": ""})
    return results


def build_ssh_device_profile(ip: str, ssh: Dict[str, object], scan_level: str = "topology") -> Dict[str, object]:
    conn = None
    try:
        conn, platform = _connect(ip, ssh)
        prompt = conn.find_prompt()
        hostname = _hostname_from_prompt(prompt)
        version = _safe_command(conn, "show version")
        int_brief = _safe_command(conn, "show ip interface brief")
        interfaces, interface_details, addresses = _parse_interfaces(int_brief)

        cdp_text = _safe_command(conn, "show cdp neighbors detail")
        neighbors = _parse_neighbors(cdp_text, "CDP")
        if not neighbors:
            lldp_text = _safe_command(conn, "show lldp neighbors detail")
            neighbors = _parse_neighbors(lldp_text, "LLDP")

        description = (version.splitlines()[0].strip() if version.strip() else platform)
        lower = version.lower()
        is_switch = any(token in lower for token in ("iosvl2", "linux_l2", "l2 image", "ethernet switch"))
        if not is_switch:
            # Presence of 'show ip route' output is strong evidence for a router/L3 node.
            route_text = _safe_command(conn, "show ip route")
        else:
            route_text = ""
        routes = _parse_routes(route_text)
        device_type = "switch" if is_switch else "router"

        return {
            "hostname": hostname,
            "description": description,
            "object_id": "",
            "query_ip": ip,
            "interfaces": interfaces,
            "interface_details": interface_details,
            "ip_addresses": addresses,
            "ip_forwarding": "1" if device_type == "router" else "2",
            "bridge_address": "ssh-detected" if device_type == "switch" else "",
            "cdp_neighbors": neighbors,
            "route_networks": routes,
            "vlan_database": [],
            "device_type": device_type,
            "access_method": "SSH-Legacy" if "legacy" in str(platform).lower() else "SSH",
            "ssh_platform": platform,
        }
    finally:
        if conn is not None:
            try:
                conn.disconnect()
            except Exception:
                pass
