"""Read basic system information from a network device."""

from typing import Dict, Optional

from config import SNMP_COMMUNITY
from scanner.snmp import snmp_get

SYS_NAME = "1.3.6.1.2.1.1.5.0"
SYS_DESCR = "1.3.6.1.2.1.1.1.0"
SYS_OBJECT_ID = "1.3.6.1.2.1.1.2.0"
SYS_UPTIME = "1.3.6.1.2.1.1.3.0"
SYS_LOCATION = "1.3.6.1.2.1.1.6.0"
SYS_CONTACT = "1.3.6.1.2.1.1.4.0"


def get_device(ip: str, community: str = SNMP_COMMUNITY) -> Dict[str, Optional[str]]:
    """Return basic SNMP system information for one device."""
    hostname = snmp_get(ip, SYS_NAME, community)

    return {
        "ip": ip,
        "hostname": hostname or ip,
        "description": snmp_get(ip, SYS_DESCR, community),
        "object_id": snmp_get(ip, SYS_OBJECT_ID, community),
        "uptime": snmp_get(ip, SYS_UPTIME, community),
        "location": snmp_get(ip, SYS_LOCATION, community),
        "contact": snmp_get(ip, SYS_CONTACT, community),
    }
