"""Cisco VLAN and switch-port inventory through SNMP.

This module intentionally avoids Q-BRIDGE-MIB because some IOSvL2 images do
not implement it. VLAN names come from CISCO-VTP-MIB and access VLANs come
from CISCO-VLAN-MEMBERSHIP-MIB.
"""

from typing import Dict

from config import SNMP_COMMUNITY
from scanner.snmp import snmp_walk

VTP_VLAN_NAME = "1.3.6.1.4.1.9.9.46.1.3.1.1.4"
VM_VLAN = "1.3.6.1.4.1.9.9.68.1.2.2.1.2"
VLAN_TRUNK_PORT_DYNAMIC_STATUS = "1.3.6.1.4.1.9.9.46.1.6.1.1.14"


def get_vlan_database(ip: str, community: str = SNMP_COMMUNITY) -> Dict[int, str]:
    """Return {vlan_id: vlan_name}."""
    result: Dict[int, str] = {}
    for oid, value in snmp_walk(ip, VTP_VLAN_NAME, community):
        try:
            vlan_id = int(oid.split(".")[-1])
        except (TypeError, ValueError):
            continue
        if 1 <= vlan_id <= 4094:
            result[vlan_id] = str(value or "VLAN{}".format(vlan_id))
    return result


def get_access_vlan_by_ifindex(ip: str, community: str = SNMP_COMMUNITY) -> Dict[str, int]:
    """Return access VLAN membership keyed by ifIndex."""
    result: Dict[str, int] = {}
    for oid, value in snmp_walk(ip, VM_VLAN, community):
        ifindex = oid.split(".")[-1]
        try:
            vlan_id = int(str(value))
        except (TypeError, ValueError):
            continue
        if 1 <= vlan_id <= 4094:
            result[ifindex] = vlan_id
    return result


def get_trunk_status_by_ifindex(ip: str, community: str = SNMP_COMMUNITY) -> Dict[str, bool]:
    """Return {ifIndex: is_trunking} when CISCO-VTP-MIB exposes the status.

    Cisco enum: 1=trunking, 2=notTrunking. Unknown values are ignored.
    """
    result: Dict[str, bool] = {}
    for oid, value in snmp_walk(ip, VLAN_TRUNK_PORT_DYNAMIC_STATUS, community):
        ifindex = oid.split(".")[-1]
        raw = str(value).strip()
        if raw == "1":
            result[ifindex] = True
        elif raw == "2":
            result[ifindex] = False
    return result


def get_switch_vlan_inventory(ip: str, community: str = SNMP_COMMUNITY) -> Dict[str, object]:
    return {
        "vlans": get_vlan_database(ip, community),
        "access_vlan_by_ifindex": get_access_vlan_by_ifindex(ip, community),
        "trunk_by_ifindex": get_trunk_status_by_ifindex(ip, community),
    }
