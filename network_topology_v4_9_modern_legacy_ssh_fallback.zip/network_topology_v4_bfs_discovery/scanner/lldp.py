from scanner.snmp import snmp_walk

LLDP_CHASSIS = "1.0.8802.1.1.2.1.4.1.1.5"
LLDP_PORT = "1.0.8802.1.1.2.1.4.1.1.7"
LLDP_SYSTEM = "1.0.8802.1.1.2.1.4.1.1.9"


def get_lldp_neighbors(ip):

    chassis = snmp_walk(ip, LLDP_CHASSIS)
    ports = snmp_walk(ip, LLDP_PORT)
    systems = snmp_walk(ip, LLDP_SYSTEM)

    neighbors = []

    total = min(len(chassis), len(ports), len(systems))

    for i in range(total):

        neighbors.append({

            "chassis": chassis[i],

            "remote_port": ports[i],

            "system_name": systems[i]

        })

    return neighbors