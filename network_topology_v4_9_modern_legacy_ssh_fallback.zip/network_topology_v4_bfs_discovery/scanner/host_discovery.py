"""Fast host discovery using Nmap XML output."""

import subprocess
import xml.etree.ElementTree as ET
from typing import Dict, List


def discover_alive_hosts(network: str, timeout: int = 180) -> List[Dict[str, str]]:
    command = ["nmap", "-sn", "-n", "-oX", "-", network]
    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return []

    if result.returncode != 0 or not result.stdout.strip():
        return []

    try:
        root = ET.fromstring(result.stdout)
    except ET.ParseError:
        return []

    hosts: List[Dict[str, str]] = []
    for host in root.findall("host"):
        status = host.find("status")
        if status is None or status.get("state") != "up":
            continue

        row = {"ip": "", "mac": "", "vendor": "", "hostname": ""}
        for address in host.findall("address"):
            if address.get("addrtype") == "ipv4":
                row["ip"] = address.get("addr", "")
            elif address.get("addrtype") == "mac":
                row["mac"] = address.get("addr", "")
                row["vendor"] = address.get("vendor", "")

        hostname = host.find("hostnames/hostname")
        if hostname is not None:
            row["hostname"] = hostname.get("name", "")

        if row["ip"]:
            hosts.append(row)

    return hosts
