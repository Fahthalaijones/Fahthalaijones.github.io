"""Collect a reusable SNMP profile for a network device."""

from typing import Dict

from config import MAX_HOSTS_PER_NETWORK, PRIVATE_NETWORKS_ONLY
from scanner.cdp import get_cdp_neighbors
from scanner.device import get_device
from scanner.interface import get_interface_map, get_interfaces
from scanner.ip_address import get_interface_ipv4_addresses
from scanner.route_table import get_ipv4_routes
from scanner.snmp import snmp_get
from scanner.vlan import get_switch_vlan_inventory

IP_FORWARDING = "1.3.6.1.2.1.4.1.0"
DOT1D_BASE_BRIDGE_ADDRESS = "1.3.6.1.2.1.17.1.1.0"


def _classify(profile: Dict[str, object]) -> str:
    description = str(profile.get("description") or "").lower()
    forwarding = str(profile.get("ip_forwarding") or "").strip()
    interfaces = profile.get("interfaces") or {}
    bridge_address = str(profile.get("bridge_address") or "").strip()

    if forwarding == "1":
        return "router"
    if (
        bridge_address
        or "iosvl2" in description
        or "linux_l2" in description
        or "switch" in description
    ) and len(interfaces) >= 2:
        return "switch"
    return "network_device"


def build_device_profile(ip: str, community: str, scan_level: str = "full") -> Dict[str, object]:
    basic = get_device(ip, community)
    interfaces = get_interface_map(ip, community)
    interface_details = get_interfaces(ip, community)
    addresses = get_interface_ipv4_addresses(ip, community)

    addresses_by_index = {}
    for row in addresses:
        addresses_by_index.setdefault(str(row.get("ifindex") or ""), []).append({
            "ip": row.get("ip") or "",
            "netmask": row.get("netmask") or "",
        })
    for ifindex, detail in interface_details.items():
        detail["ifindex"] = str(ifindex)
        detail["ip_addresses"] = addresses_by_index.get(str(ifindex), [])
        name = str(detail.get("name") or "")
        detail["interface_kind"] = "SVI" if name.lower().startswith("vlan") else "Physical/Logical"

    try:
        neighbors = get_cdp_neighbors(ip, community)
    except Exception:
        neighbors = []

    forwarding = snmp_get(ip, IP_FORWARDING, community) or ""
    profile: Dict[str, object] = {
        **basic,
        "query_ip": ip,
        "interfaces": interfaces,
        "interface_details": interface_details,
        "ip_addresses": addresses,
        "ip_forwarding": forwarding,
        "bridge_address": snmp_get(
            ip, DOT1D_BASE_BRIDGE_ADDRESS, community
        ) or "",
        "cdp_neighbors": neighbors,
        "route_networks": [],
    }
    profile["device_type"] = _classify(profile)

    # Enrich Layer-2 switch interfaces with VLAN inventory. This works on
    # Cisco IOSvL2 images that expose CISCO-VTP-MIB and
    # CISCO-VLAN-MEMBERSHIP-MIB even when Q-BRIDGE-MIB is unavailable.
    profile["vlan_database"] = {}
    profile["access_method"] = "SNMP"
    if profile["device_type"] == "switch" and scan_level != "topology":
        try:
            vlan_inventory = get_switch_vlan_inventory(ip, community)
        except Exception:
            vlan_inventory = {"vlans": {}, "access_vlan_by_ifindex": {}, "trunk_by_ifindex": {}}

        vlan_database = vlan_inventory.get("vlans") or {}
        access_vlans = vlan_inventory.get("access_vlan_by_ifindex") or {}
        trunk_status = vlan_inventory.get("trunk_by_ifindex") or {}
        profile["vlan_database"] = [
            {"vlan_id": vlan_id, "name": vlan_database[vlan_id]}
            for vlan_id in sorted(vlan_database)
        ]

        for ifindex, detail in interface_details.items():
            vlan_id = access_vlans.get(str(ifindex))
            is_trunk = trunk_status.get(str(ifindex))
            if is_trunk is True:
                detail["switchport_mode"] = "trunk"
                detail["access_vlan"] = None
            elif vlan_id is not None:
                detail["switchport_mode"] = "access"
                detail["access_vlan"] = vlan_id
                detail["access_vlan_name"] = vlan_database.get(vlan_id, "VLAN{}".format(vlan_id))
            elif is_trunk is False:
                detail["switchport_mode"] = "not-trunking"
            else:
                detail["switchport_mode"] = "unknown"

    # Read routes only from Layer-3 forwarding devices. These routes expand
    # scan scope but never create topology links by themselves.
    if profile["device_type"] == "router":
        profile["route_networks"] = get_ipv4_routes(
            ip,
            community=community,
            private_only=PRIVATE_NETWORKS_ONLY,
            max_hosts=MAX_HOSTS_PER_NETWORK,
        )

    return profile
