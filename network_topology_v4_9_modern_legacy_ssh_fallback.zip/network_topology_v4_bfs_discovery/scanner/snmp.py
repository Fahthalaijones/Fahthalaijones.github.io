"""Small SNMP helper functions used by the discovery modules."""

from typing import List, Optional, Tuple

from pysnmp.hlapi import (
    CommunityData,
    ContextData,
    ObjectIdentity,
    ObjectType,
    SnmpEngine,
    UdpTransportTarget,
    getCmd,
    nextCmd,
)
from pysnmp.proto.rfc1902 import OctetString

from config import SNMP_PORT, SNMP_RETRIES, SNMP_TIMEOUT

SnmpRow = Tuple[str, str]


def _format_snmp_value(value) -> str:
    """Convert SNMP values without destroying binary MAC/mask octets."""
    if isinstance(value, OctetString):
        raw = bytes(value.asOctets())

        # MAC address stored as six binary octets.
        if len(raw) == 6:
            return ":".join(f"{byte:02X}" for byte in raw)

        # IPv4 address/netmask stored as four binary octets.
        if len(raw) == 4:
            return ".".join(str(byte) for byte in raw)

        # Normal text values such as sysName/sysDescr/interface names.
        try:
            return raw.decode("utf-8").strip("\x00").strip()
        except UnicodeDecodeError:
            return "0x" + raw.hex().upper()

    # Integer, Gauge, Counter, IpAddress and other normal SNMP types.
    try:
        return value.prettyPrint().strip('"')
    except Exception:
        return str(value).strip('"')


def snmp_get(ip: str, oid: str, community: str = "public") -> Optional[str]:
    """Read one SNMP OID. Return None when the device does not answer."""
    try:
        iterator = getCmd(
            SnmpEngine(),
            CommunityData(community, mpModel=1),
            UdpTransportTarget(
                (ip, SNMP_PORT),
                timeout=SNMP_TIMEOUT,
                retries=SNMP_RETRIES,
            ),
            ContextData(),
            ObjectType(ObjectIdentity(oid)),
        )

        error_indication, error_status, _, var_binds = next(iterator)
        if error_indication or error_status or not var_binds:
            return None

        return _format_snmp_value(var_binds[0][1])

    except Exception:
        return None


def snmp_walk(ip: str, oid: str, community: str = "public") -> List[SnmpRow]:
    """Walk an SNMP subtree and return [(full_oid, formatted_value), ...]."""
    rows: List[SnmpRow] = []

    try:
        iterator = nextCmd(
            SnmpEngine(),
            CommunityData(community, mpModel=1),
            UdpTransportTarget(
                (ip, SNMP_PORT),
                timeout=SNMP_TIMEOUT,
                retries=SNMP_RETRIES,
            ),
            ContextData(),
            ObjectType(ObjectIdentity(oid)),
            lexicographicMode=False,
        )

        for error_indication, error_status, _, var_binds in iterator:
            if error_indication or error_status:
                break

            for var_bind in var_binds:
                rows.append((str(var_bind[0]), _format_snmp_value(var_bind[1])))

    except Exception:
        return []

    return rows
