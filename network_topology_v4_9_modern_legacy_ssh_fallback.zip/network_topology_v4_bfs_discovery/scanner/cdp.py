"""Cisco Discovery Protocol (CDP) neighbor discovery."""

import ipaddress
from typing import Dict, List

from config import SNMP_COMMUNITY
from scanner.interface import get_interface_map
from scanner.snmp import snmp_walk

# CISCO-CDP-MIB
CDP_CACHE_ADDRESS = "1.3.6.1.4.1.9.9.23.1.2.1.1.4"
CDP_CACHE_DEVICE_ID = "1.3.6.1.4.1.9.9.23.1.2.1.1.6"
CDP_CACHE_DEVICE_PORT = "1.3.6.1.4.1.9.9.23.1.2.1.1.7"
CDP_CACHE_PLATFORM = "1.3.6.1.4.1.9.9.23.1.2.1.1.8"


def _suffix_map(rows, base_oid: str) -> Dict[str, str]:
    """Map the table suffix (localIfIndex.deviceIndex) to its value."""
    prefix = base_oid.rstrip(".") + "."
    result: Dict[str, str] = {}

    for full_oid, value in rows:
        if full_oid.startswith(prefix):
            result[full_oid[len(prefix):]] = value

    return result


def _decode_cdp_address(value: str) -> str:
    """Decode common PySNMP CDP address formats into an IPv4 string."""
    text = value.strip().replace("0x", "").replace(":", " ").replace("-", " ")

    # Already returned as an IPv4 address.
    try:
        return str(ipaddress.ip_address(text))
    except ValueError:
        pass

    # Hex bytes such as "C0 A8 38 0B" or "c0a8380b".
    compact = "".join(text.split())
    if len(compact) == 8:
        try:
            raw = bytes.fromhex(compact)
            return str(ipaddress.ip_address(raw))
        except ValueError:
            pass

    # Decimal bytes such as "192 168 56 11".
    parts = text.split()
    if len(parts) == 4:
        try:
            return ".".join(str(int(part)) for part in parts)
        except ValueError:
            pass

    return ""


def get_cdp_neighbors(ip: str, community: str = SNMP_COMMUNITY) -> List[dict]:
    """Return CDP neighbors from one Cisco device.

    Each CDP cache row is joined using the same OID suffix instead of relying
    on array positions. This avoids mismatched device, port and address data.
    """
    interface_map = get_interface_map(ip, community)

    device_ids = _suffix_map(
        snmp_walk(ip, CDP_CACHE_DEVICE_ID, community),
        CDP_CACHE_DEVICE_ID,
    )
    remote_ports = _suffix_map(
        snmp_walk(ip, CDP_CACHE_DEVICE_PORT, community),
        CDP_CACHE_DEVICE_PORT,
    )
    remote_addresses = _suffix_map(
        snmp_walk(ip, CDP_CACHE_ADDRESS, community),
        CDP_CACHE_ADDRESS,
    )
    platforms = _suffix_map(
        snmp_walk(ip, CDP_CACHE_PLATFORM, community),
        CDP_CACHE_PLATFORM,
    )

    neighbors: List[dict] = []

    for suffix, remote_device in sorted(device_ids.items()):
        local_ifindex = suffix.split(".")[0]

        neighbors.append(
            {
                "source_ip": ip,
                "local_ifindex": local_ifindex,
                "local_port": interface_map.get(
                    local_ifindex,
                    f"ifIndex {local_ifindex}",
                ),
                "remote_device": remote_device or "Unknown",
                "remote_port": remote_ports.get(suffix, "Unknown"),
                "management_ip": _decode_cdp_address(
                    remote_addresses.get(suffix, "")
                ),
                "platform": platforms.get(suffix, ""),
                "protocol": "CDP",
            }
        )

    return neighbors


if __name__ == "__main__":
    from config import ROOT_DEVICE_IP

    for neighbor in get_cdp_neighbors(ROOT_DEVICE_IP):
        print(neighbor)
