"""Read IPv4 addresses assigned to SNMP interfaces."""

from typing import Dict, List

from config import SNMP_COMMUNITY
from scanner.interface import get_interface_map
from scanner.snmp import snmp_walk

# Legacy IP-MIB ipAddrTable. Supported by the Cisco IOS images used in this lab.
IP_AD_ENT_IF_INDEX = "1.3.6.1.2.1.4.20.1.2"
IP_AD_ENT_NET_MASK = "1.3.6.1.2.1.4.20.1.3"


def _ip_suffix_map(ip: str, oid: str, community: str) -> Dict[str, str]:
    prefix = oid.rstrip(".") + "."
    result: Dict[str, str] = {}
    for full_oid, value in snmp_walk(ip, oid, community):
        if full_oid.startswith(prefix):
            address = full_oid[len(prefix):]
            result[address] = value
    return result


def get_interface_ipv4_addresses(
    ip: str,
    community: str = SNMP_COMMUNITY,
) -> List[dict]:
    """Return IP addresses with their ifIndex and interface name."""
    interface_map = get_interface_map(ip, community)
    if_indexes = _ip_suffix_map(ip, IP_AD_ENT_IF_INDEX, community)
    masks = _ip_suffix_map(ip, IP_AD_ENT_NET_MASK, community)

    rows: List[dict] = []
    for address, ifindex in sorted(if_indexes.items()):
        rows.append(
            {
                "ip": address,
                "netmask": masks.get(address, ""),
                "ifindex": str(ifindex),
                "interface": interface_map.get(str(ifindex), f"ifIndex {ifindex}"),
            }
        )
    return rows


def get_management_ipv4(
    ip: str,
    community: str = SNMP_COMMUNITY,
    preferred_interfaces=("vlan1", "vl1"),
) -> dict:
    """Select the management IP, preferring an SVI such as Vlan1."""
    addresses = get_interface_ipv4_addresses(ip, community)
    preferred = {name.lower() for name in preferred_interfaces}

    for row in addresses:
        if row["interface"].lower() in preferred:
            return row

    for row in addresses:
        if not row["ip"].startswith("127."):
            return row

    return {
        "ip": ip,
        "netmask": "",
        "ifindex": "",
        "interface": "Unknown",
    }
