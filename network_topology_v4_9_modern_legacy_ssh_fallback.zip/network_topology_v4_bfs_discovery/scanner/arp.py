"""Read the router ARP table (IP -> MAC)."""

import re
from typing import List

from config import SNMP_COMMUNITY
from scanner.snmp import snmp_walk

ARP_PHYS_ADDRESS = "1.3.6.1.2.1.4.22.1.2"


def normalize_mac(value: str) -> str:
    """Convert common SNMP MAC formats to AA:BB:CC:DD:EE:FF."""
    text = str(value).strip().replace("0x", "")
    pairs = re.findall(r"[0-9A-Fa-f]{2}", text)

    if len(pairs) == 6:
        return ":".join(part.upper() for part in pairs)

    compact = re.sub(r"[^0-9A-Fa-f]", "", text)
    if len(compact) == 12:
        return ":".join(compact[i:i + 2].upper() for i in range(0, 12, 2))

    return ""


def get_arp_table(ip: str, community: str = SNMP_COMMUNITY) -> List[dict]:
    """Return [{ip, mac, ifindex}] from ipNetToMediaPhysAddress."""
    entries: List[dict] = []
    prefix = ARP_PHYS_ADDRESS + "."

    for full_oid, value in snmp_walk(ip, ARP_PHYS_ADDRESS, community):
        if not full_oid.startswith(prefix):
            continue

        suffix = full_oid[len(prefix):].split(".")
        if len(suffix) < 5:
            continue

        ifindex = suffix[0]
        ip_address = ".".join(suffix[-4:])
        mac = normalize_mac(value)

        if not mac or mac == "00:00:00:00:00:00":
            continue

        entries.append({"ip": ip_address, "mac": mac, "ifindex": ifindex})

    return entries
