# V4.3 Direct Router End Device Discovery

This version adds discovery of PCs connected directly to a router interface.

Evidence chain:

1. Read the router ARP table through SNMP.
2. Use `ipNetToMediaIfIndex` to identify the router interface.
3. Map ifIndex to ifName/ifDescr.
4. Exclude interfaces participating in CDP links, including parent interfaces of dot1Q subinterfaces.
5. Exclude PCs already mapped through Switch FDB.
6. Create `Router -> PC` edges for the remaining entries.

If multiple ARP entries remain on one non-CDP router interface, the graph can infer an unmanaged/shared segment rather than claiming that all PCs are physically connected to one router port.

Test:

```bash
python3 test_router_direct_pc.py
```
