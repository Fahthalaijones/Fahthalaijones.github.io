import csv
import io
import json
from copy import deepcopy
from threading import Lock

from flask import Flask, Response, jsonify, render_template, request

from config import FLASK_DEBUG, FLASK_HOST, FLASK_PORT
from database.database import (
    clear_node_positions,
    create_tables,
    get_node_positions,
    save_node_positions,
)
from services.dashboard_service import run_discovery

app = Flask(__name__)
_scan_lock = Lock()
_cache = None

create_tables()


def _apply_saved_layout(payload):
    """Attach saved x/y positions to nodes without changing discovery data."""
    result = deepcopy(payload)
    nodes = result.get("nodes", [])
    positions = get_node_positions(node.get("id") for node in nodes if node.get("id") is not None)
    for node in nodes:
        saved = positions.get(str(node.get("id")))
        if saved:
            node["x"] = saved["x"]
            node["y"] = saved["y"]
            node["layout_saved"] = True
    result["layout"] = {
        "saved_positions": positions,
        "has_saved_layout": bool(positions),
    }
    return result


def _empty_dashboard_data():
    return {
        "nodes": [],
        "edges": [],
        "metadata": {"source": "idle", "message": "Waiting for user to start discovery"},
        "summary": {
            "total_devices": 0,
            "router_count": 0,
            "switch_count": 0,
            "managed_switch_count": 0,
            "unmanaged_switch_count": 0,
            "end_device_count": 0,
            "link_count": 0,
            "cdp_links": 0,
            "arp_fdb_links": 0,
            "inferred_switch_links": 0,
            "scan_time": "",
            "scan_duration_seconds": 0,
            "target_network": "",
            "management_network": "",
            "gateway_ip": "",
            "switch_management_ips": [],
        },
        "devices": [],
        "services": [],
    }


def get_dashboard_data(force=False, scan_options=None):
    global _cache
    with _scan_lock:
        if force:
            _cache = run_discovery(scan_options)
        if _cache is None:
            return _apply_saved_layout(_empty_dashboard_data())
        return _apply_saved_layout(_cache)


def _normalise_import_payload(data):
    """Accept this project's exported JSON and a topology-wrapped variant."""
    if not isinstance(data, dict):
        raise ValueError("JSON root must be an object")

    if isinstance(data.get("topology"), dict):
        topology = data["topology"]
        merged = dict(data)
        merged["nodes"] = topology.get("nodes", [])
        merged["edges"] = topology.get("edges", [])
        data = merged

    nodes = data.get("nodes")
    edges = data.get("edges")
    if not isinstance(nodes, list) or not isinstance(edges, list):
        raise ValueError("JSON must contain 'nodes' and 'edges' arrays")

    for node in nodes:
        if not isinstance(node, dict) or node.get("id") is None:
            raise ValueError("Every node must be an object with an 'id'")
    for edge in edges:
        if not isinstance(edge, dict) or edge.get("from") is None or edge.get("to") is None:
            raise ValueError("Every edge must contain 'from' and 'to'")

    payload = deepcopy(data)
    payload.setdefault("metadata", {"source": "import"})
    payload.setdefault("services", [])

    # Older export files may not contain these convenience sections.
    if not isinstance(payload.get("devices"), list):
        payload["devices"] = [
            {
                "id": node.get("id", ""),
                "ip": node.get("ip") or node.get("management_ip") or "-",
                "hostname": node.get("hostname") or node.get("display_name") or "Unknown",
                "mac": node.get("mac") or "-",
                "device_type": node.get("device_type") or node.get("group") or "unknown",
                "vendor": node.get("vendor") or "Unknown",
                "connected_to": node.get("connected_to") or "-",
                "port": node.get("switch_port") or node.get("uplink_port") or "-",
                "discovery": " + ".join(node.get("discovery") or []),
            }
            for node in nodes
        ]

    if not isinstance(payload.get("summary"), dict):
        types = [node.get("device_type") or node.get("group") or "unknown" for node in nodes]
        payload["summary"] = {
            "total_devices": len(nodes),
            "router_count": types.count("router"),
            "switch_count": types.count("switch") + types.count("unmanaged_switch"),
            "managed_switch_count": types.count("switch"),
            "unmanaged_switch_count": types.count("unmanaged_switch"),
            "end_device_count": types.count("end_device"),
            "link_count": len(edges),
            "cdp_links": sum(1 for edge in edges if edge.get("relation") == "cdp"),
            "arp_fdb_links": sum(1 for edge in edges if edge.get("relation") in {"arp_fdb", "unmanaged_downstream"}),
            "inferred_switch_links": sum(1 for edge in edges if edge.get("relation") == "inferred_unmanaged_switch"),
            "scan_time": data.get("exported_at") or "",
            "scan_duration_seconds": 0,
            "target_network": "Imported topology",
            "management_network": "Imported topology",
            "gateway_ip": "",
            "switch_management_ips": [node.get("ip") for node in nodes if node.get("device_type") == "switch" and node.get("ip")],
        }

    return payload


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/dashboard")
def dashboard():
    try:
        return jsonify(success=True, **get_dashboard_data(force=False))
    except Exception as exc:
        app.logger.exception("Could not build dashboard")
        return jsonify(success=False, error=str(exc)), 500


@app.route("/api/scan", methods=["POST"])
def scan():
    try:
        body = request.get_json(silent=True) or {}
        scan_level = str(body.get("scan_level") or "full").strip().lower()
        connection_mode = str(body.get("connection_mode") or "auto").strip().lower()
        snmp = body.get("snmp") if isinstance(body.get("snmp"), dict) else {}
        ssh = body.get("ssh") if isinstance(body.get("ssh"), dict) else {}
        root_ips = body.get("root_ips") if isinstance(body.get("root_ips"), list) else []
        root_ips = [str(ip).strip() for ip in root_ips if str(ip).strip()]

        if scan_level not in {"topology", "end_devices", "full"}:
            return jsonify(success=False, error="Invalid scan_level"), 400
        if connection_mode not in {"auto", "snmp", "ssh"}:
            return jsonify(success=False, error="Invalid connection_mode"), 400

        # Credentials are used only for this scan request and are not written
        # to SQLite or returned to the browser.
        scan_options = {
            "scan_level": scan_level,
            "connection_mode": connection_mode,
            "root_ips": root_ips,
            "snmp_community": str(snmp.get("community") or "").strip() if "community" in snmp else None,
            "ssh": {
                "enabled": bool(ssh.get("enabled")),
                "username": str(ssh.get("username") or "").strip(),
                "password": str(ssh.get("password") or ""),
                "port": int(ssh.get("port") or 22),
                "device_type": str(ssh.get("device_type") or "auto"),
            },
        }
        return jsonify(success=True, **get_dashboard_data(force=True, scan_options=scan_options))
    except ValueError as exc:
        return jsonify(success=False, error=str(exc)), 400
    except Exception as exc:
        app.logger.exception("Could not scan network")
        return jsonify(success=False, error=str(exc)), 500


@app.route("/api/topology")
def topology():
    try:
        data = get_dashboard_data(force=False)
        return jsonify(
            success=True,
            nodes=data["nodes"],
            edges=data["edges"],
            metadata=data["metadata"],
            layout=data.get("layout", {}),
        )
    except Exception as exc:
        app.logger.exception("Could not build topology")
        return jsonify(success=False, nodes=[], edges=[], error=str(exc)), 500


@app.route("/api/layout", methods=["GET", "POST", "DELETE"])
def layout():
    try:
        if request.method == "GET":
            positions = get_node_positions()
            return jsonify(success=True, positions=positions)

        if request.method == "DELETE":
            deleted = clear_node_positions()
            return jsonify(success=True, deleted=deleted)

        body = request.get_json(silent=True) or {}
        positions = body.get("positions", {})
        if not isinstance(positions, dict):
            return jsonify(success=False, error="positions must be an object"), 400
        saved = save_node_positions(positions)
        return jsonify(success=True, saved=saved)
    except Exception as exc:
        app.logger.exception("Could not update topology layout")
        return jsonify(success=False, error=str(exc)), 500


@app.route("/api/import", methods=["POST"])
def import_topology():
    global _cache
    try:
        if "file" not in request.files:
            return jsonify(success=False, error="Please choose a JSON file"), 400
        upload = request.files["file"]
        if not upload.filename:
            return jsonify(success=False, error="Please choose a JSON file"), 400
        if not upload.filename.lower().endswith(".json"):
            return jsonify(success=False, error="Only .json files are supported"), 400

        raw = upload.read()
        if len(raw) > 10 * 1024 * 1024:
            return jsonify(success=False, error="JSON file is too large (max 10 MB)"), 413
        data = json.loads(raw.decode("utf-8-sig"))
        imported = _normalise_import_payload(data)

        # If the exported file contains node coordinates, persist them so the
        # same arrangement survives browser/server restarts.
        imported_positions = {}
        for node in imported["nodes"]:
            if node.get("x") is not None and node.get("y") is not None:
                imported_positions[str(node["id"])] = {"x": node["x"], "y": node["y"]}
        if imported_positions:
            save_node_positions(imported_positions)

        with _scan_lock:
            _cache = imported

        payload = _apply_saved_layout(imported)
        return jsonify(success=True, imported=True, filename=upload.filename, **payload)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        return jsonify(success=False, error=f"Invalid JSON file: {exc}"), 400
    except ValueError as exc:
        return jsonify(success=False, error=str(exc)), 400
    except Exception as exc:
        app.logger.exception("Could not import topology")
        return jsonify(success=False, error=str(exc)), 500


@app.route("/api/export/json")
def export_json():
    payload = get_dashboard_data(force=False)
    export_payload = deepcopy(payload)
    export_payload["export_version"] = "4.1"
    # x/y are already attached by _apply_saved_layout for positions saved in DB.
    body = json.dumps(export_payload, ensure_ascii=False, indent=2)
    return Response(
        body,
        mimetype="application/json",
        headers={"Content-Disposition": "attachment; filename=network_topology.json"},
    )


@app.route("/api/export/csv")
def export_csv():
    payload = get_dashboard_data(force=False)
    output = io.StringIO()
    fieldnames = [
        "ip", "hostname", "mac", "device_type", "vendor",
        "connected_to", "port", "discovery",
    ]
    writer = csv.DictWriter(output, fieldnames=fieldnames)
    writer.writeheader()
    for row in payload["devices"]:
        writer.writerow({key: row.get(key, "") for key in fieldnames})

    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=discovered_devices.csv"},
    )


@app.route("/api/health")
def health():
    return jsonify(success=True, version="4.8-user-scan-root-ip-network-summary")


if __name__ == "__main__":
    app.run(host=FLASK_HOST, port=FLASK_PORT, debug=FLASK_DEBUG)
