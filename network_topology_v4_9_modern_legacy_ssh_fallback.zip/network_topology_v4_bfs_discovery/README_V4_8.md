# V4.8

- Scan Options moved to the top bar and opens as a popup.
- Web page no longer starts a discovery scan automatically on first load.
- Settings supports one or more Root / Seed IP addresses.
- Discovery can start from multiple root devices.
- Network Information summarizes long network/IP lists to keep the dashboard compact; full values remain available as a tooltip.
- Existing Topology / PC-End Devices / Full scan levels and SNMP/SSH settings remain available.
