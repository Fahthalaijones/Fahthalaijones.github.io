# V4.5 VLAN-by-Router and Interface Inventory

- End devices behind an L2 switch are assigned to a VLAN from the router ARP entry and router subinterface/IP network.
- Exact access port/VLAN membership is intentionally not claimed when the switch SNMP agent does not expose Q-BRIDGE-MIB or VLAN contexts.
- Router and switch nodes now include a complete IF-MIB interface inventory: ifIndex, interface name, admin status, operational status, and IPv4 address/netmask when available.
- The dashboard shows PC VLAN even when the access port is unavailable.
